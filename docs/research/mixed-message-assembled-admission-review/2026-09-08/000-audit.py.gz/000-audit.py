"""Bounded archive/source/runtime reads only; imports no Zeta module."""
import ast
import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import subprocess
import tarfile

ROOT = Path('/Users/acehack/.zeta/agents/codex/Zeta-projection-publication-20260908')
OWNER = Path(__file__).resolve().parent
PACKET = 'd61ee6a994b154c8df3b0627e9b23b5cd9db13c6'
SOURCE = '3c3a76ad6674bb40b2e1309021735950c282d8d5'
BASE = Path('docs/research/mixed-message-epoch-implementation/2026-09-08')
FROZEN = BASE / 'implementation-source'
EXPECTED_MANIFEST = 'F92041F0DBC344DA877DFA970B3C5C7AD6817C8285AAA28E164872F2CE6D56F1'
EXPECTED_ARCHIVE = 'E51A00FC29FA2A13B09F152AB0F55908B7E03982036E5084F54A221815149445'
MIB = 1024 * 1024
commands = []

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def read(path, cap=128*MIB):
    observed = path.lstat()
    require(stat.S_ISREG(observed.st_mode) and 0 <= observed.st_size <= cap, 'regular bounded file: '+str(path))
    raw = path.read_bytes()
    require(len(raw) == observed.st_size, 'read size changed: '+str(path))
    return raw

def git(revision, path):
    argv = ['git', '-C', str(ROOT), 'show', revision+':'+str(path)]
    result = subprocess.run(argv, capture_output=True)
    commands.append(dict(Argv=argv, ExitCode=result.returncode, StdoutBytes=len(result.stdout), StdoutSha256=sha(result.stdout), StderrHex=result.stderr.hex()))
    require(result.returncode == 0, 'git observation failed')
    return result.stdout

def packet(path, cap=128*MIB):
    raw = read(ROOT/path, cap)
    committed = git(PACKET, path)
    require(raw == committed, 'packet differs from committed cut: '+str(path))
    return raw

def unpack(raw, expected_rows):
    require(len(expected_rows) <= 1024, 'archive record cap')
    require(len({row['Path'] for row in expected_rows}) == len(expected_rows), 'duplicate expected member')
    total = sum(row['Bytes'] for row in expected_rows)
    require(total <= 200*MIB, 'archive total cap')
    originals = {}
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        entries = archive.getmembers()
        require([x.name for x in entries] == [x['Path'] for x in expected_rows], 'archive complete ordered roster')
        for entry, row in zip(entries, expected_rows, strict=True):
            require(entry.isfile() and entry.size == row['Bytes'] and entry.size <= 128*MIB, 'member type/size')
            stream = archive.extractfile(entry)
            require(stream is not None, 'missing member stream')
            value = stream.read(row['Bytes']+1)
            require(len(value) == row['Bytes'] and sha(value) == row['Sha256'], 'member identity: '+entry.name)
            originals[entry.name] = value
    return originals

manifest_raw = packet(FROZEN/'service-manifest.json', 64*1024)
require(len(manifest_raw) == 22381 and sha(manifest_raw) == EXPECTED_MANIFEST, 'independent service bytes')
manifest = json.loads(manifest_raw)
require(set(manifest) == {'Schema','ExpectedBindings','SourceFiles','DirectFiles'} and manifest['Schema'] == 'zeta.mixed-epoch.service.v1', 'service shape')
archive_manifest = json.loads(packet(FROZEN/'archive-manifest.json', MIB))
archive_raw = packet(FROZEN/'custody.tar.gz', 64*MIB)
require(len(archive_raw) == 39770169 and sha(archive_raw) == EXPECTED_ARCHIVE, 'independent capsule bytes')
require(archive_manifest['Archive'] == {'Path':'custody.tar.gz','Bytes':len(archive_raw),'Sha256':EXPECTED_ARCHIVE}, 'archive descriptor')
require(archive_manifest['SourceCommit'] == SOURCE and archive_manifest['ManifestSha256'] == EXPECTED_MANIFEST, 'source/manifest association')
require(len(archive_manifest['Members']) == 298, '298 members')
members = unpack(archive_raw, archive_manifest['Members'])
require(members['service-manifest.json'] == manifest_raw, 'archived service original')
custody_raw = packet(FROZEN/'source-custody.json', MIB)
require(members['source-custody.json'] == custody_raw, 'custody original')
custody = json.loads(custody_raw)
require(custody['SourceCommit'] == SOURCE and custody['ManifestSha256'] == EXPECTED_MANIFEST, 'custody associations')
require(custody['NamedControlsEntered'] is False and custody['PassiveManifestAdmissionReturned'] == 'ServiceManifest', 'recorded freeze scope')

sources = manifest['SourceFiles']
require(len(sources) == 65 and [x['Path'] for x in sources] == sorted({x['Path'] for x in sources}), '65 ordered sources')
require(sum(x['Bytes'] for x in sources) <= 64*MIB, 'source aggregate')
source_bytes = {}
for index, row in enumerate(sources):
    path = row['Path']
    require(set(row) == {'Path','Bytes','Sha256'} and type(row['Bytes']) is int and 0 < row['Bytes'] <= 8*MIB, 'source row')
    require(len(path) <= 256 and all(32 <= ord(c) < 127 for c in path) and not Path(path).is_absolute() and '..' not in Path(path).parts, 'source path')
    raw = read(ROOT/path, 8*MIB)
    committed = git(SOURCE, path)
    require(raw == committed == members['sources/'+path] and len(raw) == row['Bytes'] and sha(raw) == row['Sha256'], 'source/git/archive mismatch: '+path)
    source_bytes[path] = raw
    require(members[f'git-source/{index}-stdout'] == raw and members[f'git-source/{index}-stderr'] == b'', 'retained Git source original')
    completion = json.loads(members[f'git-source/{index}-completion.json'])
    require(completion['Argv'] == ['git','show',SOURCE+':'+path] and completion['ExitCode'] == 0, 'retained Git command association')

bridge_path = 'src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py'
tree = ast.parse(source_bytes[bridge_path])
literal = {}
for node in tree.body:
    if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
        if node.targets[0].id in {'FIXED_SOURCE_PINS','DLL_PATHS','MODULE_STEMS'}:
            literal[node.targets[0].id] = ast.literal_eval(node.value)
fixed = literal['FIXED_SOURCE_PINS']
require(len(fixed) == 6, 'six registered fixed documents')
for path, value in fixed.items():
    require(path in source_bytes and sha(source_bytes[path]) == value, 'fixed document: '+path)
required = set(fixed) | {f'src/Interp.Python/zeta_interp/{x}.py' for x in literal['MODULE_STEMS']} | {
    'src/Interp.Python/zeta_interp/mixed_message_epoch_controls.py',
    'src/Interp.Python/tests/test_mixed_message_epoch_bridge.py',
    'src/Interp.Python/pyproject.toml','src/Interp.Python/uv.lock',
    'Directory.Build.props','Directory.Packages.props','global.json',
    'src/Bayesian/Bayesian.fsproj','src/Core/Core.fsproj',
    'src/Bayesian/PrecisionGateProjection.fs','src/Bayesian/PrecisionGateKernels.fs',
    'src/Bayesian/BoundedModuleLearner.fs','src/Bayesian/MixedMessageEpoch.fs',
    'src/Research.FSharp/MixedMessageEpochReplay.fsx','src/Research.FSharp/PrecisionGateProjectionReplay.fsx',
    'docs/DECISIONS/2026-09-08-checked-mixed-message-module-epochs.md',
    'docs/research/2026-09-08-mixed-message-frozen-nested-query-register.md',
    'docs/research/mixed-message-epoch-implementation/2026-09-08/registered-source/invoke.py',
}
require(required <= set(source_bytes), 'required source/convention/caller roster')
roles = ['@python','@host','src/Research.FSharp/MixedMessageEpochReplay.fsx','src/Research.FSharp/PrecisionGateProjectionReplay.fsx',*literal['DLL_PATHS']]
require([x['Role'] for x in manifest['DirectFiles']] == roles, 'seven ordered direct roles')
require([x['Role'] for x in custody['DirectArchive']] == roles, 'direct archive roles')
bindings = {row['Path']:row['Sha256'] for row in sources}
direct = []
for row, location in zip(manifest['DirectFiles'], custody['DirectArchive'], strict=True):
    require(set(row) == {'Role','Bytes','Sha256'} and type(row['Bytes']) is int and 0 < row['Bytes'] <= 128*MIB, 'direct row')
    path = Path(location['OriginalPath'])
    require(path == path.resolve(), 'canonical direct path')
    if not row['Role'].startswith('@'):
        require(path == ROOT/row['Role'], 'direct source role location')
        bindings[row['Role']] = row['Sha256']
    raw = read(path)
    require(len(raw) == row['Bytes'] == location['Bytes'] and sha(raw) == row['Sha256'] == location['Sha256'], 'live direct identity')
    require(raw == members[location['ArchivePath']] == members['direct-observation/'+row['Role'].replace('/','_')], 'direct original bytes')
    require(raw == members['direct-after-raw/'+row['Role'].replace('/','_')], 'direct after original bytes')
    after = json.loads(members['direct-after/'+row['Role'].replace('/','_')+'.json'])
    require(after == {'Role':row['Role'],'Bytes':len(raw),'Sha256':sha(raw),'Matches':True}, 'direct after identity')
    direct.append(dict(**row,ActualPath=str(path),CurrentEqualsArchived=True))

ref_tree = ast.parse(source_bytes['src/Interp.Python/zeta_interp/precision_gate_projection_reference.py'])
protocol = None
for node in ref_tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(x,ast.Name) and x.id == 'PROTOCOL_SHA256' for x in node.targets):
        protocol = ast.literal_eval(node.value)
require(protocol is not None, 'scalar protocol literal')
bindings['ProtocolSha256'] = protocol
require(len(bindings) == 69 and manifest['ExpectedBindings'] == dict(sorted(bindings.items())), 'complete flat bindings')
require(len(json.dumps(bindings,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()) <= 64*1024, 'binding wire cap')
for path in roles[2:4]:
    refs = [line for line in source_bytes[path].decode().splitlines() if line.startswith('#r ')]
    expected = ['#r "../Core/bin/Release/net10.0/Zeta.Core.dll"','#r "../Core.Abstractions/bin/Release/net10.0/Zeta.Core.Abstractions.dll"','#r "../Bayesian/bin/Release/net10.0/Zeta.Bayesian.dll"']
    require(refs == expected, 'exact three direct references: '+path)

known = {
    bridge_path:'2A6154EB842116837843E8E100AB08CF4A4C735C635ED693E8C3F58E11B4961B',
    'src/Interp.Python/zeta_interp/mixed_message_epoch_controls.py':'03ED13D4D860D1E3B61B73AF265B7C65A8251B258623C16B1B1ED28EC6C51711',
    'src/Interp.Python/tests/test_mixed_message_epoch_bridge.py':'4C8ECC4B2CBF514265D93C138847039B3CEFA5EB50FBEF1AA1D7A75C78CC74A8',
    'src/Research.FSharp/MixedMessageEpochReplay.fsx':'5D0DD505F3849D7F989982DCAE5EBAB2898B8140AE74489540EC016B15AD7795',
    'docs/research/mixed-message-epoch-implementation/2026-09-08/registered-source/invoke.py':'CC7FBF89E681909374591516B4227F3D93373E9B5F089C039994B0CA46055E69',
}
for path, value in known.items():
    require(sha(source_bytes[path]) == value, 'independently reviewed source: '+path)
require(sha(members['freeze-source.py']) == '0DBFF44E506F9EF175318F10018C340A0CDEB2B2F70602518DCFE47B92DD2970', 'accepted freeze')
require(sha(members['run-registered.py']) == 'FBD0DF785D5AECAE47591D73EA3062050825F33241880B67668B462ADDAC2462', 'accepted capture')
for index in (0,1):
    invocation = json.loads(members[f'environment/{index}-invocation.json'])
    completion = json.loads(members[f'environment/{index}-completion.json'])
    require(completion['ExitCode'] == 0 and completion['Argv'] == invocation['Argv'], 'metadata command closure')
    require(members[f'environment/{index}-stderr'] == b'', 'metadata stderr')
    if index == 0:
        require(invocation['Argv'] == [direct[1]['ActualPath'],'--info'], 'dotnet metadata command')
    else:
        require(invocation['Argv'][1] == '-c' and 'platform' in invocation['Argv'][2], 'Python metadata command')

scalar_and_dll = sum(row['Bytes'] for row in manifest['DirectFiles'][3:])
reservation = 2*(scalar_and_dll + 2*(64*1024+64*1024+2*MIB))
require(reservation == 31206246, 'M4 reservation arithmetic')
require(256*MIB-reservation > 10*MIB and 4096-(4+3*2) >= 3, 'M4 inner store room')
result = dict(PacketCommit=PACKET,SourceCommit=SOURCE,ServiceManifest=dict(Bytes=len(manifest_raw),Sha256=EXPECTED_MANIFEST),Archive=dict(Bytes=len(archive_raw),Sha256=EXPECTED_ARCHIVE,Members=len(members),OriginalBytes=sum(x['Bytes'] for x in archive_manifest['Members'])),SelectedSources=len(sources),SourceBytes=sum(x['Bytes'] for x in sources),RequiredPathsChecked=len(required),FixedDocuments=fixed,Bindings=len(bindings),DirectFiles=direct,KnownSourcePins=known,M4=dict(PlannedProjections=2,ExternalReservedBytes=reservation,InnerCombinedBytes=256*MIB-reservation,ExternalArtifactSlots=10,InnerArtifactSlots=4086),M5AndNested=dict(PlannedProjections=0,ExternalReservedBytes=0,OuterLedgers='M5 four sessions; frozen query separate'),Scope='Read-only archive/source/direct-file admission; no project imports, plan builders, numerical services, named invocation, source-to-machine or transitive runtime proof')
(OWNER/'git-observations.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps(result,indent=2))
