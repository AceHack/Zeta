"""Read committed validation artifacts and counters; execute no test or helper."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile
import xml.etree.ElementTree as ET

ROOT = Path('/Users/acehack/.zeta/agents/codex/Zeta-projection-publication-20260908')
OWNER = Path(__file__).resolve().parent
PACKET = 'd61ee6a994b154c8df3b0627e9b23b5cd9db13c6'
SOURCE = '3c3a76ad6674bb40b2e1309021735950c282d8d5'
BASE = Path('docs/research/mixed-message-epoch-implementation/2026-09-08')
commands = []

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

def require(value, message):
    if not value:
        raise RuntimeError(message)

def git(revision, path):
    argv = ['git','-C',str(ROOT),'show',revision+':'+str(path)]
    result = subprocess.run(argv,capture_output=True)
    commands.append(dict(Argv=argv,ExitCode=result.returncode,StdoutBytes=len(result.stdout),StdoutSha256=sha(result.stdout),StderrHex=result.stderr.hex()))
    require(result.returncode == 0,'Git observation')
    return result.stdout

def packet(path):
    observed = (ROOT/path).read_bytes()
    committed = git(PACKET,path)
    require(observed == committed,'packet differs: '+str(path))
    return observed

def gzip_records(section):
    raw = packet(section/'manifest.json')
    manifest = json.loads(raw)
    originals = {}
    require(len(manifest['Records']) <= 128,'gzip roster cap')
    for row in manifest['Records']:
        compressed = packet(section/row['File'])
        require(len(compressed) == row['StoredBytes'] and sha(compressed) == row['StoredSha256'],'stored identity')
        original = gzip.decompress(compressed)
        require(len(original) == row['Bytes'] and sha(original) == row['Sha256'],'raw identity')
        path = row['OriginalPath']
        require(path not in originals and original == (ROOT/path).read_bytes(),'original file identity')
        originals[path] = original
    return originals

first = BASE/'assembled-validation-1'
manifest = json.loads(packet(first/'manifest.json'))
require(manifest['OriginalCount'] == len(manifest['Records']) == 86 and manifest['ObjectCount'] == 69,'86 originals/69 objects')
compressed = packet(first/'custody.tar.gz')
require(len(compressed) == manifest['Archive']['Bytes'] == 6147915 and sha(compressed) == manifest['Archive']['Sha256'] == '7685B51BECB144499A1621DD048A234CA7F64C17E6DCC1C23D9CF1B8C4C945C2','validation archive pin')
objects = {}
with tarfile.open(fileobj=io.BytesIO(compressed),mode='r:gz') as archive:
    for member in archive:
        require(member.isfile() and member.name not in objects and member.size <= 128*1024*1024,'object member')
        stream = archive.extractfile(member)
        require(stream is not None,'object stream')
        value = stream.read(member.size+1)
        require(len(value) == member.size,'object exact bytes')
        objects[member.name] = value
require(len(objects) == 69 and set(objects) == {r['Object'] for r in manifest['Records']},'object inventory')
require(sum(len(x) for x in objects.values()) == manifest['ObjectBytes'] == 66533406,'object sum')
originals = {}
for row in manifest['Records']:
    value = objects[row['Object']]
    require(len(value) == row['Bytes'] and sha(value) == row['Sha256'],'original manifest identity')
    path = row['OriginalPath']
    require(path not in originals and value == (ROOT/path).read_bytes(),'actual original file')
    originals[path] = value
require(sum(len(x) for x in originals.values()) == manifest['OriginalBytes'] == 66539151,'original sum')

gate = '.git/mixed-assembled-gate-1/'
gate_returns = [json.loads(originals[gate+f'call-{i}/completion.json']) for i in range(4)]
require([x['ExitCode'] for x in gate_returns] == [1,0,1,0],'original gate/format/pytest/mypy outcomes')
gate_stdout = originals[gate+'call-0/stdout'].decode()
require('139' in gate_stdout and 'FAILURES (1)' in gate_stdout and 'dotnet test' in gate_stdout,'original failed test gate')
require('110 passed' in originals[gate+'call-2/stdout'].decode() and '1 failed' in originals[gate+'call-2/stdout'].decode(),'original fixture failure')
require('supports only C# and Visual Basic' in originals[gate+'call-1/stderr'].decode(),'formatter scope')
recovery = '.git/mixed-assembled-recovery-1/'
recovery_return = json.loads(originals[recovery+'completion.json'])
recovery_argv = json.loads(originals[recovery+'invocation.json'])
require(recovery_return['ExitCode'] == 0 and '--no-build' in recovery_argv['Argv'],'separate diagnostic recovery')
before = json.loads(originals[recovery+'before.json'])
after = json.loads(originals[recovery+'after.json'])
require(before == after and len(before) == 12,'12 unchanged recovery pins')
for row in before:
    raw = (ROOT/row['Path']).read_bytes()
    require(len(raw) == row['Bytes'] and sha(raw) == row['Sha256'],'recovery current source/runtime identity')
trx_rows = []
for path,value in originals.items():
    if path.endswith('.trx'):
        doc = ET.fromstring(value)
        counter = doc.find('.//{*}ResultSummary/{*}Counters')
        require(counter is not None,'TRX counters')
        counters = {key:int(v) for key,v in counter.attrib.items()}
        outcomes = {}
        for test in doc.findall('.//{*}Results/{*}UnitTestResult'):
            outcome = test.attrib['outcome']
            outcomes[outcome] = outcomes.get(outcome,0)+1
        trx_rows.append(dict(Path=path,Counters=counters,ObservedRowOutcomes=outcomes))
require(len(trx_rows) == 7,'seven project returns')
require(sum(x['Counters']['passed'] for x in trx_rows) == 7835,'7835 passed')
require(sum(x['Counters']['failed'] for x in trx_rows) == 0,'zero failed')
require(sum(x['ObservedRowOutcomes'].get('NotExecuted',0) for x in trx_rows) == 6,'six actual skipped rows')
require(sum(x['Counters']['total']-x['Counters']['executed'] for x in trx_rows) == 6,'six total-minus-executed')

final = gzip_records(BASE/'final-source-recheck-1')
require(len(final) == 47,'47 final recheck originals')
stem = '.git/mixed-assembled-portability-recheck-1/'
final_returns = [json.loads(final[stem+f'{i}/completion.json']) for i in (0,1)]
require([x['ExitCode'] for x in final_returns] == [0,0],'final pytest/mypy outcomes')
require('111 passed in 4.86s' in final[stem+'0/stdout'].decode(),'final default-temp suite')
require('--basetemp' not in final_returns[0]['Argv'] and '--strict' in final_returns[1]['Argv'],'actual invocation modes')
final_sources = json.loads(final[stem+'sources.json'])
require(len(final_sources) == 3 and all(x['Unchanged'] is True for x in json.loads(final[stem+'source-after.json'])),'final source closure')
for i,row in enumerate(final_sources):
    raw = git(SOURCE,row['Path'])
    require(raw == final[stem+f'source-{i}'] and len(raw) == row['Bytes'] and sha(raw) == row['Sha256'],'final executed source association')

freeze = gzip_records(BASE/'implementation-source/freeze-observation')
require(len(freeze) == 5,'five freeze observation originals')
stem = '.git/mixed-source-freeze-observation-1/'
freeze_return = json.loads(freeze[stem+'completion.json'])
freeze_invocation = json.loads(freeze[stem+'invocation.json'])
freeze_stdout = json.loads(freeze[stem+'stdout'])
require(freeze_return['ExitCode'] == 0 and freeze[stem+'stderr'] == b'','actual freeze return')
require(freeze_invocation['Cwd'] == str(ROOT) and freeze_invocation['PythonPath'] == str(ROOT/'src/Interp.Python'),'actual freeze environment')
require(sha(freeze[stem+'freeze-source.py']) == '0DBFF44E506F9EF175318F10018C340A0CDEB2B2F70602518DCFE47B92DD2970','actual executed freeze source')
require(freeze_stdout['SourceCommit'] == SOURCE and freeze_stdout['ManifestSha256'] == 'F92041F0DBC344DA877DFA970B3C5C7AD6817C8285AAA28E164872F2CE6D56F1' and freeze_stdout['ArchiveSha256'] == 'E51A00FC29FA2A13B09F152AB0F55908B7E03982036E5084F54A221815149445','actual freeze result association')
require(freeze_stdout['Members'] == 298 and freeze_stdout['SelectedSources'] == 65 and freeze_stdout['Bindings'] == 69 and len(freeze_stdout['DirectFiles']) == 7,'actual freeze counts')

core_pins = []
for path in ['src/Bayesian/BoundedModuleLearner.fs','src/Bayesian/MixedMessageEpoch.fs','src/Bayesian/Bayesian.fsproj','tests/Bayesian.Tests/BoundedModuleLearner.Tests.fs','tests/Bayesian.Tests/MixedMessageEpoch.Tests.fs','tests/Bayesian.Tests/Bayesian.Tests.fsproj']:
    raw = git('d7e8e3806afaecdaed8a4a1ff5244c899201c870',path)
    assembled = git(SOURCE,path)
    require(raw == assembled,'accepted core source equivalence: '+path)
    core_pins.append(dict(Path=path,Bytes=len(raw),Sha256=sha(raw)))
(OWNER/'validation-git-observations.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps(dict(PacketCommit=PACKET,OriginalValidation=dict(Records=86,Objects=69,OriginalBytes=66539151,ObjectBytes=66533406,OriginalExitCodes=[x['ExitCode'] for x in gate_returns]),Recovery=dict(Exit=recovery_return,UnchangedPins=before,Trx=trx_rows,Passed=7835,Failed=0,SkippedRows=6),FinalRecheck=dict(Originals=47,Returns=final_returns,SourcePins=final_sources),FreezeObservation=dict(Originals=5,Return=freeze_return,ManifestSha256=freeze_stdout['ManifestSha256'],ArchiveSha256=freeze_stdout['ArchiveSha256']),CoreSourceEquivalence=core_pins,Scope='Read-only byte/counter/source association; no test, numerical service or freeze invocation'),indent=2))
