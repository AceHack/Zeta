import gzip
import hashlib
import json
from pathlib import Path
import subprocess

root = Path.cwd()
source = 'bf2da44b94e770d21add73ce53dacb8fb34259bf'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == source
archive = root / 'docs/research/precision-gate-projection/2026-09-08/native-preparation-1'
archive.mkdir(parents=True, exist_ok=False)
folders = ['precision-projection-native-preparation-1', 'precision-projection-native-build-1',
           'precision-projection-native-build-2', 'precision-projection-native-tests-1',
           'precision-projection-native-tests-2', 'precision-projection-native-tests-3',
           'precision-projection-native-tests-4', 'precision-projection-replay-startup-1',
           'precision-projection-replay-startup-2', 'precision-projection-native-preservation-1']
files = sorted(p for name in folders for p in (root / '.git' / name).iterdir() if p.is_file())
files += [root / '.git/precision-projection-build-graph-1.stdout', root / '.git/precision-projection-build-graph-1.stderr']
rows = []
for i, path in enumerate(files, 1):
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    name = f'{i:03d}-{path.parent.name}-{path.name}.gz'
    (archive / name).write_bytes(stored)
    assert gzip.decompress(stored) == raw
    rows.append({'Index': i, 'OriginalPath': str(path), 'File': name, 'Bytes': len(raw),
                 'Sha256': hashlib.sha256(raw).hexdigest(), 'StoredBytes': len(stored),
                 'StoredSha256': hashlib.sha256(stored).hexdigest()})
paths = ['src/Bayesian/PrecisionGateProjection.fs', 'src/Research.FSharp/PrecisionGateProjectionReplay.fsx',
         'tests/Bayesian.Tests/PrecisionGateProjection.Tests.fs', 'src/Bayesian/Bayesian.fsproj',
         'tests/Bayesian.Tests/Bayesian.Tests.fsproj', 'src/Bayesian/PrecisionGateKernels.fs', 'src/Core/Result.fs',
         'Directory.Build.props', 'Directory.Build.targets', 'Directory.Packages.props', 'global.json',
         'docs/research/2026-09-08-precision-gate-projection-proposed-contract.md',
         'docs/research/2026-09-08-precision-gate-projection-decimal-admission-clarification.md',
         'docs/research/2026-09-08-precision-gate-projection-rendered-zero-clarification.md',
         'docs/research/2026-09-08-precision-gate-projection-native-implementation.md']
pins = []
for path in paths:
    raw = (root / path).read_bytes()
    assert raw == subprocess.check_output(['git', 'show', source + ':' + path])
    pins.append({'Path': path, 'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest()})
manifest = {'Schema': 'zeta.precision-projection.native-preparation.v1', 'SourceCommit': source,
            'Scope': 'preparation, native builds, focused fixtures and no-argument script startup only',
            'FinalRegisteredComparisonRun': False, 'ReferenceOutputsRead': False,
            'Records': rows, 'Sources': pins}
(archive / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'Records': len(rows), 'OriginalBytes': sum(r['Bytes'] for r in rows),
                  'StoredBytes': sum(r['StoredBytes'] for r in rows), 'Sources': len(pins)}))
