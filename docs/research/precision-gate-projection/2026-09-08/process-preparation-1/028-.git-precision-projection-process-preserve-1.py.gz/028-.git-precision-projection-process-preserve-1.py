from pathlib import Path
import gzip, hashlib, json, subprocess
root = Path.cwd()
source = "b575e34bd5cda05176ee14f89aedb2fa10edbb96"
out = root / "docs/research/precision-gate-projection/2026-09-08/process-preparation-1"
paths = []
for p in sorted((root / ".git").glob("precision-projection-process-*")):
    if p.is_file():
        paths.append(p)
    elif p.is_dir():
        paths.extend(sorted(p.rglob("*")))
paths = [p for p in paths if p.is_file()]
assert len(paths) <= 150
out.mkdir(exist_ok=False)
records = []
for i, p in enumerate(paths, 1):
    raw = p.read_bytes()
    assert len(raw) <= 2 * 1024 * 1024
    stored = gzip.compress(raw, mtime=0)
    name = f"{i:03d}-{p.parent.name}-{p.name}.gz"
    with (out / name).open("xb") as stream:
        stream.write(stored)
    records.append({"OriginalPath": str(p), "File": name, "Bytes": len(raw), "Sha256": hashlib.sha256(raw).hexdigest(), "StoredBytes": len(stored), "StoredSha256": hashlib.sha256(stored).hexdigest()})
names = [
    "src/Interp.Python/zeta_interp/precision_gate_projection_process.py",
    "src/Interp.Python/tests/test_precision_gate_projection_process.py",
    "src/Bayesian/PrecisionGateProjection.fs",
    "src/Research.FSharp/PrecisionGateProjectionReplay.fsx",
    "src/Bayesian/PrecisionGateKernels.fs",
    "src/Bayesian/Bayesian.fsproj",
    "tests/Bayesian.Tests/PrecisionGateProjection.Tests.fs",
    "tests/Bayesian.Tests/Bayesian.Tests.fsproj",
    "docs/claims/task-distributional-learning-20260908.md",
    "docs/research/2026-09-08-precision-gate-projection-proposed-contract.md",
    "docs/research/2026-09-08-precision-gate-projection-decimal-admission-clarification.md",
    "docs/research/2026-09-08-precision-gate-projection-rendered-zero-clarification.md",
    "docs/research/2026-09-08-precision-gate-projection-process-source.md",
    "src/Interp.Python/pyproject.toml",
]
sources = []
for name in names:
    raw = subprocess.run(["git", "show", source + ":" + name], check=True, capture_output=True).stdout
    assert raw == (root / name).read_bytes()
    sources.append({"Path": name, "Bytes": len(raw), "Sha256": hashlib.sha256(raw).hexdigest()})
manifest = {"Schema": "zeta.precision-projection.process-preparation.v1", "SourceCommit": source, "FinalComparisonRun": False, "ReferenceResultsRead": False, "Validation": {"InitialTestsPassed": 13, "IntermediateTestsPassed": 17, "FinalTestsPassed": 20, "FinalRuffExitCode": 0, "FinalStrictMypyExitCode": 0}, "Scope": "transport-only owned Python subprocesses and explicit constructed command fixtures; no final native/reference subjects", "Records": records, "Sources": sources}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
for row in records:
    stored = (out / row["File"]).read_bytes()
    assert len(stored) == row["StoredBytes"] and hashlib.sha256(stored).hexdigest() == row["StoredSha256"]
    raw = gzip.decompress(stored)
    assert len(raw) == row["Bytes"] and hashlib.sha256(raw).hexdigest() == row["Sha256"]
    assert raw == Path(row["OriginalPath"]).read_bytes()
print(json.dumps({"Records": len(records), "RawBytes": sum(r["Bytes"] for r in records), "StoredBytes": sum(r["StoredBytes"] for r in records), "Sources": len(sources)}))
