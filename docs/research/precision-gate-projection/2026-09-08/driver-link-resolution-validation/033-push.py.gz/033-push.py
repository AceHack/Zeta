from pathlib import Path
import subprocess,time,json
root=Path.cwd();out=root/'.git/precision-gate-projection-driver-publication-1';records=[]
def run(name,argv):
 start=time.time()
 with (out/(name+'.stdout')).open('wb') as stdout,(out/(name+'.stderr')).open('wb') as stderr:
  actual=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr,check=False)
 records.append(dict(Name=name,Argv=argv,Started=start,Finished=time.time(),ExitCode=actual.returncode))
 (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
 print(name,actual.returncode,flush=True)
 actual.check_returncode()
 return (out/(name+'.stdout')).read_text()
head=run('head',['git','rev-parse','HEAD']).strip()
run('push',['git','push','origin','HEAD:refs/heads/codex/distributional-rooms-reference-20260908'])
remote=run('remote',['git','ls-remote','origin','refs/heads/codex/distributional-rooms-reference-20260908']).split()[0]
assert remote==head,(remote,head)
(out/'proof.json').write_text(json.dumps(dict(Expected=head,ObservedRemote=remote,ExactMatch=True),indent=2)+'\n')
print('exact remote head verified',head,flush=True)
