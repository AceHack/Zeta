# Projection driver source and admission plan

Date: 2026-09-08
Author: Vera, OpenAI Codex using GPT-6 Astra
Operational status: research-grade source implementation plan
Status: approved finite adapter design; implementation/review in progress

The coordinator approved a minimal actual driver over the unchanged fixed
40-case/88-call plan. No case or operation selection flag exists. This source
work does not open the final evaluation; complete source review and an
independent immutable implementation archive remain prerequisites.

## Public boundary and exact manifest

The driver accepts independently supplied raw manifest bytes and their expected
uppercase SHA256, a canonical source root, an existing canonical output parent,
one fresh attempt name and an absolute dotnet host path. The CLI exposes these
through --source-root, --manifest, --manifest-sha256, --output-parent, --attempt
and --dotnet. It never derives the expected manifest hash from the manifest.

The strict UTF-8/JSON manifest is at most 64 KiB, with exactly Schema,
ProtocolSha256, SourceFiles and NativeFiles. SourceFiles has the exact ordered
47-path roster: the earlier 44-path census plus this driver, its dedicated test
and the process test. Rows are exactly Path, Bytes and Sha256. Each file is at
most 8 MiB and their total is at most 64 MiB. NativeFiles has exactly five
ordered Role, Bytes and Sha256 rows: @host, the replay script and its three
canonical repository-relative DLL paths. Script identity must agree with its
source row. Every hash is uppercase hexadecimal; integer lengths exclude bool.
Flat Bindings comes only from this independently hash-admitted manifest.

Two complete live descriptor-relative source scans compare exact bytes to that
expectation: before native preparation, and immediately before the single
runner invocation. Actual loaded local module file/origin paths must point to
the admitted source root, including the ordinary package initialization files.
These are current-file/path observations, not source-to-bytecode equivalence or
future immutability. The same admitted expectations reach every service.

## One shared reservation

The approved raw-plus-stored driver reservation is
D = 2 * [C + M + 27 * (64 KiB + 64 KiB + 2 MiB) + 4 * 1 MiB], where C is the
independently declared total copied script/three DLL bytes and M is the raw
manifest length. The host and source archive files are read, not copied.
Exactly 90 file slots are reserved: four direct copies, one manifest, 81 native
call input/bindings/receipt files, and four bounded metadata files (two source
snapshots, preparation and final outer envelope). Directories are ownership
surfaces, not extra scientific result artifacts.

All reservations are charged before writes, including potentially unused or
failed paths. There is no refund or retry. The inner store receives
Limits(256 MiB - D, 8 MiB, 512 - 90). Setup refuses unless that remainder can
cover the 8-MiB journal, 2-MiB combined runner terminal reservation and nonzero
ordinary room. Its exact remaining byte allowance is retained. This tightens
the shared registered ceiling rather than adding an independent outer budget.

Native stdout/stderr and observations are memory values subsequently retained
by the inner recorder, whose writes consume its own remainder. The approved
native process writes only its reserved fixed files. Reservation bounds are
not a hostile-child OS disk quota or a peak-memory guarantee. Original source
archives already preserved in git are not copied again into the run directory.

## Outcome retention and source tests

DriverResult retains all actual source/read/preparation/store/run outcomes and
first plus secondary failures in memory before any later fallible publication.
The actual RunResult is never recursively serialized into outer JSON: its store
helper snapshots repeat previous values. A once-only at-most-1-MiB outer
reference envelope links inner terminal/final journal, source/preparation
metadata, fixed native call files, counts and failures. It explicitly identifies
memory-only actual outcomes. Publication failure does not erase RunResult or
become scientific success. Existing paths and partial files remain untouched.

Tests use owned small file fixtures and controlled runner/process seams.
Required discriminators include manifest hash/key/roster/type mutations,
changed source bytes and origins, canonical path/overlap refusal, exact shared
reservation and exhausted setup, exclusive outputs, original returned RunResult
before encoding/write/read failure, setup/child failures, unchanged service
bindings, one runner invocation, and CLI invalid arguments with no work.
No final case, solver, registered stream or native numerical output is used.

Dependency source imports preserve original root commits 2ba65308e, 459df9111,
2e051e8d0, c124a621d and process 36cb21d57 (the root import of b575).
Eight current adapter/helper modules were compared byte-for-byte with root.
Only local documentation-context conflicts occurred during imports; both
existing clarification/ownership text and incoming source records were retained.
The root's smaller-budget runner admission is a pending dependency for actual
driver integration; this lane does not edit the runner or numerical criteria.

Signed: Vera, OpenAI Codex using GPT-6 Astra.
