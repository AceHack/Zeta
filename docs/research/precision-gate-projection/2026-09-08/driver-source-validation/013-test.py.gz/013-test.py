"""Owned file fixtures and controlled callbacks, never final numerical cases."""

from __future__ import annotations

import hashlib
import json
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import pytest

from zeta_interp import precision_gate_projection_driver as d


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest().upper()


def raw_manifest(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":")).encode()


@pytest.fixture
def owned(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> tuple[Path, Path, Path, dict[str, Any]]:
    source = tmp_path / "source"
    source.mkdir()
    output = tmp_path / "output"
    output.mkdir()
    host = tmp_path / "dotnet-owned-fixture"
    host.write_bytes(b"owned nonexecuted host")
    actual_root = Path(__file__).resolve().parents[3]
    rows = []
    for name in d.SOURCE_PATHS:
        data = ("owned fixture file: " + name).encode()
        if name.endswith("projection-proposed-contract.md") or name.endswith("admission-clarification.md") or name.endswith("rendered-zero-clarification.md"):
            data = (actual_root / name).read_bytes()
        if name == d.process.SCRIPT:
            data = b'\n'.join((b'#if INTERACTIVE', b'#r "../Core/bin/Release/net10.0/Zeta.Core.dll"', b'#r "../Core.Abstractions/bin/Release/net10.0/Zeta.Core.Abstractions.dll"', b'#r "../Bayesian/bin/Release/net10.0/Zeta.Bayesian.dll"', b'#endif', b'// Never executed owned source fixture.'))
        path = source / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        rows.append({"Path": name, "Bytes": len(data), "Sha256": sha(data)})
    native = []
    for role in d.NATIVE_ROLES:
        path = host if role == "@host" else source / role
        if role not in ("@host", d.process.SCRIPT):
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(("owned nonexecuted DLL " + role).encode())
        data = path.read_bytes()
        native.append({"Role": role, "Bytes": len(data), "Sha256": sha(data)})
    # These are declared owned fake source files, not imported task code.
    monkeypatch.setattr(d, "_loaded", lambda root: ((), None))
    manifest = {"Schema": d.SCHEMA, "ProtocolSha256": d.criteria.PROTOCOL_SHA256, "SourceFiles": rows, "NativeFiles": native}
    return source, output, host, manifest


def invoke(owned: tuple[Path, Path, Path, dict[str, Any]], name: str = "attempt") -> d.DriverResult:
    source, output, host, value = owned
    raw = raw_manifest(value)
    return d.drive(raw, sha(raw), source, output, name, host)


def fake_run(target: d.store.Store, bindings: object, services: d.runner.Services) -> d.runner.RunResult:
    # Actual exclusive Store calls, but zero service, case, policy or solver calls.
    terminal = d.store.append_bytes(target, "owned-terminal", b'{"OwnedFixture":true}')
    assert isinstance(terminal, d.store.Stored)
    final = d.store.finalize(target)
    assert isinstance(final, d.store.Finalized)
    return d.runner.RunResult((), (), None, (), (), (None, terminal), final, {"Planned": 88, "Entered": 0, "Returned": 0}, (), True, True, True, None, "owned-controlled-runner-fixture")


def test_real_source_reads_prepare_copies_and_one_controlled_runner(owned: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    calls = []
    def run(target: d.store.Store, bindings: object, services: d.runner.Services) -> d.runner.RunResult:
        calls.append(bindings)
        return fake_run(target, bindings, services)
    monkeypatch.setattr(d.runner, "run_comparison", run)
    actual = invoke(owned)
    assert actual.Complete, actual.Failure
    assert len(calls) == 1
    assert calls[0] == dict(actual.Admission.Returned.value.Bindings)
    assert len(actual.Sources) == 2
    assert all(len(c.Returned.Reads) == 47 for c in actual.Sources)
    assert actual.Preparation.Returned.Complete
    assert len(actual.Preparation.Returned.CreatedFiles) == 4
    assert len(actual.Publications) == 5
    assert actual.Run.Returned.Scope == "owned-controlled-runner-fixture"
    assert actual.Reservation.DriverSlots == 90
    assert actual.Reservation.Inner.CombinedBytes + actual.Reservation.DriverCombinedBytes == d.TOTAL_BYTES
    assert actual.Reservation.Inner.Artifacts == 422
    assert actual.Reservation.UnusedReservationsReclaimed is False
    outer = (Path(actual.AttemptRoot) / "outer-final.json").read_bytes()
    assert b'"FullRunResult":"memory-only;' in outer
    assert b'"Entries"' not in outer
    assert not (Path(actual.AttemptRoot) / "native-call-000").exists()


@pytest.mark.parametrize("mutation", ["hash", "missing", "extra", "reorder", "duplicate", "bool-length", "negative", "lower-sha", "source-total", "native-role", "script-identity", "protocol", "schema", "native-extra"])
def test_manifest_refusals_before_file_or_runner_entry(owned: Any, monkeypatch: pytest.MonkeyPatch, mutation: str) -> None:
    source, output, host, value = owned
    if mutation == "missing": value["SourceFiles"].pop()
    elif mutation == "extra": value["Unexpected"] = 1
    elif mutation == "reorder": value["SourceFiles"][0],value["SourceFiles"][1] = value["SourceFiles"][1],value["SourceFiles"][0]
    elif mutation == "duplicate": value["SourceFiles"][1] = dict(value["SourceFiles"][0])
    elif mutation == "bool-length": value["SourceFiles"][0]["Bytes"] = True
    elif mutation == "negative": value["SourceFiles"][0]["Bytes"] = -1
    elif mutation == "lower-sha": value["SourceFiles"][0]["Sha256"] = "a" * 64
    elif mutation == "source-total":
        for row in value["SourceFiles"]: row["Bytes"] = d.SOURCE_CAP
    elif mutation == "native-role": value["NativeFiles"][0]["Role"] = "@claimed-host"
    elif mutation == "script-identity": value["NativeFiles"][1]["Bytes"] += 1
    elif mutation == "protocol": value["ProtocolSha256"] = "0" * 64
    elif mutation == "schema": value["Schema"] = "producer-chosen"
    elif mutation == "native-extra": value["NativeFiles"].append(dict(value["NativeFiles"][0]))
    raw = raw_manifest(value)
    def forbidden(*args: object, **kwargs: object) -> Any: pytest.fail("admission must precede all I/O")
    monkeypatch.setattr(d.storage, "create_directory", forbidden)
    monkeypatch.setattr(d.runner, "run_comparison", forbidden)
    actual = d.drive(raw, "0"*64 if mutation == "hash" else sha(raw), source, output, "attempt", host)
    assert actual.Failure is not None
    assert actual.Run is None and actual.Preparation is None
    assert not actual.AttemptOwned


@pytest.mark.parametrize("raw", [b'{"Schema":1,"Schema":2}', b'{"a":NaN}', b'{"a":Infinity}', b'\xff'])
def test_strict_json_refusals(raw: bytes) -> None:
    assert isinstance(d.admit_manifest(raw, sha(raw)), d.a.Refused)


def test_oversize_manifest_refuses_before_hash(monkeypatch: pytest.MonkeyPatch) -> None:
    def forbidden(*args: object, **kwargs: object) -> Any: pytest.fail("oversize hash")
    monkeypatch.setattr(d.hashlib, "sha256", forbidden)
    assert isinstance(d.admit_manifest(b"x"*(d.MANIFEST_CAP+1), "A"*64), d.a.Refused)


@pytest.mark.parametrize("stage", [1, 2])
def test_changed_source_retains_read_prefix_and_no_runner(owned: Any, monkeypatch: pytest.MonkeyPatch, stage: int) -> None:
    source, _, _, manifest = owned
    selected = source / d.SOURCE_PATHS[5]
    if stage == 1:
        selected.write_bytes(b"changed")
    else:
        prepare = d.process.prepare_native
        def changed(*args: Any, **kwargs: Any) -> d.process.PreparedNative:
            actual = prepare(*args, **kwargs)
            selected.write_bytes(b"changed")
            return actual
        monkeypatch.setattr(d.process, "prepare_native", changed)
    def forbidden(*args: object, **kwargs: object) -> Any: pytest.fail("changed source must prevent run")
    monkeypatch.setattr(d.runner, "run_comparison", forbidden)
    actual = invoke(owned)
    assert not actual.Complete and actual.Failure is not None
    assert len(actual.Sources) == stage
    assert len(actual.Sources[-1].Returned.Reads) == 6
    assert not actual.Sources[-1].Returned.Reads[-1].Matched
    assert actual.Run is None
    assert (actual.SetupFinalization is not None) == (stage == 2)


@pytest.mark.parametrize("mutation", ["fifo", "symlink", "same-length"])
def test_actual_source_file_substitutions(owned: Any, monkeypatch: pytest.MonkeyPatch, mutation: str) -> None:
    import os
    source, _, _, _ = owned
    path = source / d.SOURCE_PATHS[0]
    original = path.read_bytes()
    path.unlink()
    if mutation == "fifo": os.mkfifo(path)
    elif mutation == "symlink":
        other = source / "other"
        other.write_bytes(original)
        path.symlink_to(other)
    else: path.write_bytes(b"x"*len(original))
    monkeypatch.setattr(d.runner, "run_comparison", lambda *a, **k: pytest.fail("forbidden runner"))
    actual = invoke(owned)
    assert actual.Failure is not None and actual.Run is None
    assert len(actual.Sources[0].Returned.Reads) == 1


def test_exclusive_attempt_preserves_existing_file(owned: Any) -> None:
    _, output, _, _ = owned
    attempt = output / "attempt"
    attempt.mkdir()
    marker = attempt / "keep"
    marker.write_bytes(b"unchanged")
    actual = invoke(owned)
    assert not actual.AttemptOwned and actual.Run is None
    assert marker.read_bytes() == b"unchanged"
    assert list(attempt.iterdir()) == [marker]


@pytest.mark.parametrize("kind", ["noncanonical", "nul", "overlap"])
def test_path_refusal_before_attempt(owned: Any, kind: str) -> None:
    source, output, host, value = owned
    raw = raw_manifest(value)
    if kind == "noncanonical": source = source / ".." / "source"
    elif kind == "nul": source = Path(str(source)+"\x00")
    else: output = source; name = "src"
    actual = d.drive(raw, sha(raw), source, output, "src" if kind == "overlap" else "attempt", host)
    assert actual.Failure is not None and not actual.AttemptOwned


def test_budget_refusal_precedes_all_writes(owned: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    source, output, host, value = owned
    for row in value["NativeFiles"][2:]: row["Bytes"] = d.process.FILE_CAP
    raw = raw_manifest(value)
    monkeypatch.setattr(d.storage, "create_directory", lambda *a: pytest.fail("reservation before write"))
    actual = d.drive(raw, sha(raw), source, output, "attempt", host)
    assert actual.Failure.code == "reservation"
    assert not actual.AttemptOwned and actual.Run is None


def test_exact_reservation_has_two_copy_charge_and_terminal_room(owned: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    raw = raw_manifest(owned[3]); manifest = d.admit_manifest(raw, sha(raw))
    assert isinstance(manifest, d.a.Admitted)
    actual = d.reserve(manifest.value, len(raw))
    assert isinstance(actual, d.a.Admitted)
    copies = sum(row.Bytes for row in manifest.value.Native[1:])
    expected = 2*(copies+len(raw)+27*(2*d.MANIFEST_CAP+d.process.RECEIPT_CAP)+4*d.METADATA_CAP)
    assert actual.value.DriverCombinedBytes == expected
    monkeypatch.setattr(d, "TOTAL_BYTES", expected+d.JOURNAL_BYTES+d.TERMINAL_RESERVE)
    assert isinstance(d.reserve(manifest.value, len(raw)), d.a.Refused)
    monkeypatch.setattr(d, "TOTAL_BYTES", expected+d.JOURNAL_BYTES+d.TERMINAL_RESERVE+2)
    assert isinstance(d.reserve(manifest.value, len(raw)), d.a.Admitted)


@pytest.mark.parametrize("failure", ["encode", "write", "read"])
def test_actual_run_return_retained_before_outer_publication_failure(owned: Any, monkeypatch: pytest.MonkeyPatch, failure: str) -> None:
    returned = []
    def run(target: d.store.Store, bindings: object, services: d.runner.Services) -> d.runner.RunResult:
        actual = fake_run(target, bindings, services); returned.append(actual); return actual
    monkeypatch.setattr(d.runner, "run_comparison", run)
    if failure == "encode":
        encode = d.encoding.encode_public_result
        def broken(value: object, **kwargs: Any) -> Any:
            if isinstance(value, dict) and value.get("Schema") == "zeta.precision-projection.driver.v1":
                return d.a.Refused("owned-encoding", "Outer", "original encoder refusal")
            return encode(value, **kwargs)
        monkeypatch.setattr(d.encoding, "encode_public_result", broken)
    elif failure == "write":
        write = d.storage.write_exclusive
        def broken_write(root: Path, relative: str, raw: bytes) -> Any:
            if relative == "outer-final.json":
                (root/relative).write_bytes(raw[:7])
                return d.a.Refused("owned-partial", relative, "original partial write refusal")
            return write(root,relative,raw)
        monkeypatch.setattr(d.storage,"write_exclusive",broken_write)
    else:
        read = d.storage.read_exact
        def broken_read(root: Path, relative: str, **kwargs: Any) -> Any:
            if relative == "outer-final.json": return d.a.Refused("owned-read",relative,"original read refusal")
            return read(root,relative,**kwargs)
        monkeypatch.setattr(d.storage,"read_exact",broken_read)
    actual = invoke(owned)
    assert actual.Run.Returned is returned[0]
    assert not actual.Complete
    assert actual.Failure is not None
    assert sum(p.File == "outer-final.json" for p in actual.Publications) == 1
    assert actual.Run.Returned.Finalization is not None
    if failure == "write": assert (Path(actual.AttemptRoot)/"outer-final.json").stat().st_size == 7


def test_failed_run_primary_survives_outer_failure(owned: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    original = d.a.Refused("owned-run", "call/0", "original returned failure")
    def run(target: d.store.Store, bindings: object, services: d.runner.Services) -> d.runner.RunResult:
        return replace(fake_run(target,bindings,services), PrimaryFailure=original, CollectionAndCriteriaPassed=False)
    monkeypatch.setattr(d.runner,"run_comparison",run)
    encode=d.encoding.encode_public_result
    def broken(value: object, **kwargs: Any) -> Any:
        if isinstance(value,dict) and value.get("Schema") == "zeta.precision-projection.driver.v1": return d.a.Refused("late-encode","Outer","later")
        return encode(value,**kwargs)
    monkeypatch.setattr(d.encoding,"encode_public_result",broken)
    actual=invoke(owned)
    assert actual.Failure is original
    assert len(actual.SecondaryFailures)==1
    assert actual.Run.Returned.PrimaryFailure is original


@pytest.mark.parametrize("kind", ["returned", "raised", "store"])
def test_setup_failure_retains_actual_observation(owned: Any, monkeypatch: pytest.MonkeyPatch, kind: str) -> None:
    original=[]
    if kind == "returned":
        def prepare(*args: Any) -> d.process.PreparedNative:
            actual=d.process.PreparedNative(False,str(args[1]),None,None,(),(),(),d.process.ProcessFailure("prepare","Owned","actual refusal"),())
            original.append(actual);return actual
        monkeypatch.setattr(d.process,"prepare_native",prepare)
    elif kind == "raised":
        def raises(*args: Any) -> Any: raise OSError("owned preparation exception")
        monkeypatch.setattr(d.process,"prepare_native",raises)
    else:
        def opening(*args: Any) -> d.store.OpenFailed:
            actual=d.store.OpenFailed(d.a.Refused("owned-store","Store","actual refusal"),str(args[0]),str(args[1]),str(args[0]/args[1]),None)
            original.append(actual);return actual
        monkeypatch.setattr(d.store,"open_store",opening)
    actual=invoke(owned)
    assert actual.Run is None and not actual.Complete
    assert actual.Failure is not None
    if kind == "returned": assert actual.Preparation.Returned is original[0]
    elif kind == "raised": assert actual.Preparation.Raised.Message == "owned preparation exception"
    else: assert actual.StoreOpen.Returned is original[0]


def test_actual_local_module_origin_observation_and_foreign_root(tmp_path: Path) -> None:
    root=Path(__file__).resolve().parents[3]
    modules,failure=d._loaded(root)
    assert failure is None
    assert len(modules)==14
    assert any(row.Name==d.DRIVER_NAME for row in modules)
    modules,failure=d._loaded(tmp_path)
    assert failure is not None and failure.code=="module-root"
    assert len(modules)==1


@pytest.mark.parametrize("kind", ["missing", "changed-origin", "duplicate-entry"])
def test_loaded_module_substitution_is_refused(monkeypatch: pytest.MonkeyPatch, kind: str) -> None:
    root=Path(__file__).resolve().parents[3]
    name="zeta_interp.precision_gate_projection_run"
    if kind=="missing": monkeypatch.delitem(d.sys.modules,name)
    elif kind=="changed-origin":
        module=d.sys.modules[name]
        monkeypatch.setattr(module,"__spec__",SimpleNamespace(origin="/other/clone/run.py"))
    else:
        from types import ModuleType
        main=ModuleType("__main__")
        main.__spec__=SimpleNamespace(name=d.DRIVER_NAME)  # type: ignore[assignment]
        monkeypatch.setitem(d.sys.modules,"__main__",main)
    _,failure=d._loaded(root)
    assert failure is not None


@pytest.mark.parametrize("argv", [None, [], ["--case","chosen"], ["x"]*12, [True]*12])
def test_invalid_cli_never_enters_driver(argv: object, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(d,"drive",lambda *a: pytest.fail("invalid CLI"))
    assert isinstance(d.cli(argv),d.a.Refused)


def test_cli_reads_exact_independent_manifest_and_forwards(owned: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    source,output,host,value=owned
    raw=raw_manifest(value);path=output/"expected.json";path.write_bytes(raw)
    called=[]
    def supplied(*args: Any) -> Any: called.append(args);return "owned driver return"
    monkeypatch.setattr(d,"drive",supplied)
    result=d.cli(["--source-root",str(source),"--manifest",str(path),"--manifest-sha256",sha(raw),"--output-parent",str(output),"--attempt","attempt","--dotnet",str(host)])
    assert result=="owned driver return"
    assert called==[(raw,sha(raw),source,output,"attempt",host)]


def test_returned_source_read_survives_hash_exception(owned: Any, monkeypatch: pytest.MonkeyPatch) -> None:
    source,_,_,value=owned
    raw=raw_manifest(value);manifest=d.admit_manifest(raw,sha(raw));assert isinstance(manifest,d.a.Admitted)
    expected=(source/d.SOURCE_PATHS[0]).read_bytes()
    def fails(*args: Any) -> Any: raise OSError("owned hash after read")
    monkeypatch.setattr(d.hashlib,"sha256",fails)
    actual=d.source_snapshot(source,manifest.value)
    assert not actual.Complete
    assert len(actual.Reads)==1
    assert actual.Reads[0].Read.Returned.value==expected
