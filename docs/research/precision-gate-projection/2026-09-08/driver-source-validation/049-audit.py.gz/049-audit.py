from pathlib import Path
import ast,gzip,hashlib,json
root=Path.cwd();out=root/'docs/research/precision-gate-projection/2026-09-08/driver-source-validation';m=json.loads((out/'manifest.json').read_text())
def sha(raw):return hashlib.sha256(raw).hexdigest().upper()
for row in m['Records']:
 stored=(out/row['Stored']).read_bytes();raw=gzip.decompress(stored)
 assert (len(stored),sha(stored))==(row['StoredBytes'],row['StoredSha256']),row['Stored']
 assert (len(raw),sha(raw))==(row['Bytes'],row['Sha256']),row['Stored']
 assert raw==(root/row['Original']).read_bytes(),row['Original']
for row in m['CurrentOwnedFiles']:
 raw=(root/row['Path']).read_bytes();assert (len(raw),sha(raw))==(row['Bytes'],row['Sha256'])
source=root/'src/Interp.Python/zeta_interp/precision_gate_projection_driver.py'
tree=ast.parse(source.read_text());paths=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SOURCE_PATHS' for t in n.targets))
assert list(paths)==json.loads((out/'source-roster.json').read_text())['SourceFiles']
assert len(paths)==len(set(paths))==47
obs=json.loads((root/'.git/precision-gate-projection-driver-source-observations/stdout.json').read_text())
for row in obs['LocalModules']:
 raw=Path(row['File']).read_bytes();assert (len(raw),sha(raw))==(row['Bytes'],row['Sha256'])
print(json.dumps(dict(VerifiedRecords=len(m['Records']),StoredAndRawAndOriginalMatch=True,OwnedSourceFiles=len(m['CurrentOwnedFiles']),ExactRosterPaths=len(paths),CurrentLocalModuleObservations=len(obs['LocalModules']),NumericalServicesEntered=0),indent=2))
