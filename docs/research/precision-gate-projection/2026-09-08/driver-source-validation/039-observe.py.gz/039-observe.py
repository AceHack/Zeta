from pathlib import Path
import hashlib, importlib.metadata, json, sys
from zeta_interp import precision_gate_projection_driver as driver
root=Path.cwd().parents[1]
modules,failure=driver._loaded(root)
assert failure is None, failure
observations=[]
for row in modules:
    raw=Path(row.File).read_bytes()
    observations.append(dict(Name=row.Name,Key=row.Key,File=row.File,Origin=row.Origin,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
external=[]
for name in ('torch','transformer_lens'):
    module=sys.modules.get(name)
    external.append(dict(Name=name,File=getattr(module,'__file__',None),Origin=getattr(getattr(module,'__spec__',None),'origin',None)))
print(json.dumps(dict(Schema='zeta.projection-driver.ordinary-import-observations.v1',SourceRoot=str(root),Python=dict(Executable=sys.executable,Version=sys.version,CacheTag=sys.implementation.cache_tag),LocalModules=observations,ExternalPackageOrigins=external,InstalledDistributions={name:importlib.metadata.version(name) for name in ('torch','transformer-lens','pytest','mypy','ruff')},NumericalServicesEntered=0,SourceToBytecodeAdmitted=False,TransitiveRuntimeClosureAdmitted=False),indent=2))
