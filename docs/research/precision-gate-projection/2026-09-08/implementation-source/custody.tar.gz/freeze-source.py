from pathlib import Path
import hashlib, io, json, subprocess, tarfile, gzip, time
root=Path.cwd();out=root/'docs/research/precision-gate-projection/2026-09-08/implementation-source';out.mkdir()
source_head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'])
roster=json.loads(Path('docs/research/precision-gate-projection/2026-09-08/driver-source-validation/source-roster.json').read_text())['SourceFiles'];assert len(roster)==47 and len(set(roster))==47
sha=lambda data:hashlib.sha256(data).hexdigest().upper();items={};source_rows=[]
for name in roster:
 data=subprocess.check_output(['git','show',source_head+':'+name]);assert data==Path(name).read_bytes();assert len(data)<=8*1024*1024;items['sources/'+name]=data;source_rows.append({'Path':name,'Bytes':len(data),'Sha256':sha(data)})
assert sum(x['Bytes'] for x in source_rows)<=64*1024*1024
host=Path('/Users/acehack/.local/share/mise/dotnet-root/dotnet').resolve();script='src/Research.FSharp/PrecisionGateProjectionReplay.fsx';roles=['@host',script,'src/Core/bin/Release/net10.0/Zeta.Core.dll','src/Core.Abstractions/bin/Release/net10.0/Zeta.Core.Abstractions.dll','src/Bayesian/bin/Release/net10.0/Zeta.Bayesian.dll'];native_rows=[];native_archive=[]
for role in roles:
 path=host if role=='@host' else root/role;data=path.read_bytes();assert path.is_file() and len(data)<=128*1024*1024;row={'Role':role,'Bytes':len(data),'Sha256':sha(data)};native_rows.append(row);member='native/host/dotnet' if role=='@host' else 'sources/'+role if role==script else 'native/'+role
 if member in items:assert items[member]==data
 else:items[member]=data
 native_archive.append({'Role':role,'OriginalPath':str(path),'ArchivePath':member,'Bytes':len(data),'Sha256':sha(data)})
protocol=next(x['Sha256'] for x in source_rows if x['Path']=='docs/research/2026-09-08-precision-gate-projection-proposed-contract.md');assert protocol=='537054779BF9E0BFA9271B5CC56116FBC80B16C4A2BE9F1B5E3C022FE95A0F8E'
manifest={'Schema':'zeta.precision-projection.source-manifest.v1','ProtocolSha256':protocol,'SourceFiles':source_rows,'NativeFiles':native_rows};raw_manifest=(json.dumps(manifest,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode();assert len(raw_manifest)<=64*1024
(out/'implementation-manifest.json').write_bytes(raw_manifest);(out/'implementation-manifest.sha256').write_text(sha(raw_manifest)+'\n');items['implementation-manifest.json']=raw_manifest
copied=sum(x['Bytes'] for x in native_rows if x['Role']!='@host');driver=2*(copied+len(raw_manifest)+27*(64*1024+64*1024+2*1024*1024)+4*1024*1024);inner=256*1024*1024-driver;assert inner>10*1024*1024
commands=[['/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906/src/Interp.Python/.venv/bin/python','-c','import sys,platform,json,importlib.metadata as m; print(json.dumps({"Executable":sys.executable,"Version":sys.version,"CacheTag":sys.implementation.cache_tag,"Prefix":sys.prefix,"BasePrefix":sys.base_prefix,"Platform":platform.platform(),"Machine":platform.machine(),"InstalledDistributions":{n:m.version(n) for n in ["torch","transformer-lens","pytest","mypy"]}},indent=2))'],[str(host),'--info']]
observations=[]
for n,cmd in enumerate(commands):
 start=time.time();result=subprocess.run(cmd,capture_output=True);assert result.returncode==0,(cmd,result.stderr);items[f'environment/{n}-stdout']=result.stdout;items[f'environment/{n}-stderr']=result.stderr;observations.append({'Argv':cmd,'StartedUnix':start,'FinishedUnix':time.time(),'Exit':result.returncode})
items['environment/invocations.json']=(json.dumps(observations,indent=2)+'\n').encode()
for row in native_archive:assert sha(Path(row['OriginalPath']).read_bytes())==row['Sha256']
changed=subprocess.check_output(['git','diff','--name-only','096b09126b1f489fc7720b69780263ef01485445',source_head,'--',*roster],text=True).splitlines();assert changed==['src/Interp.Python/tests/test_precision_gate_projection_driver.py'],changed
metadata={'Schema':'zeta.precision-projection.source-custody.v1','SourceCommit':source_head,'NativeBuildGateCommit':'096b09126b1f489fc7720b69780263ef01485445','SourceChangesSinceFullGate':changed,'ManifestSha256':sha(raw_manifest),'NativeArchive':native_archive,'Reservation':{'CopiedBytes':copied,'ManifestBytes':len(raw_manifest),'DriverCombinedBytes':driver,'DriverSlots':90,'InnerCombinedBytes':inner,'InnerJournalBytes':8*1024*1024,'InnerSlots':422,'UnusedReservationsReclaimed':False},'Scope':'47 committed source files, direct native files, installed-distribution metadata and dotnet info; not complete runtime closure or source-to-machine proof; no numerical service executed.'};items['source-custody.json']=(json.dumps(metadata,indent=2)+'\n').encode();items['freeze-source.py']=Path('.git/freeze-projection-source-1.py').read_bytes();buf=io.BytesIO();members=[]
with tarfile.open(fileobj=buf,mode='w') as tar:
 for name,data in items.items():
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o755 if name=='native/host/dotnet' else 0o644;tar.addfile(info,io.BytesIO(data));members.append({'Path':name,'Bytes':len(data),'Sha256':sha(data)})
packed=gzip.compress(buf.getvalue(),mtime=0);(out/'custody.tar.gz').write_bytes(packed);archive={'Schema':'zeta.precision-projection.source-archive.v1','SourceCommit':source_head,'ManifestSha256':sha(raw_manifest),'Archive':{'Path':'custody.tar.gz','Bytes':len(packed),'Sha256':sha(packed)},'Members':members};(out/'archive-manifest.json').write_text(json.dumps(archive,indent=2)+'\n');(out/'source-custody.json').write_text(json.dumps(metadata,indent=2)+'\n')
with tarfile.open(fileobj=io.BytesIO(gzip.decompress(packed))) as tar:
 assert len(tar.getmembers())==len(members)
 for row in members:
  data=tar.extractfile(row['Path']).read();assert len(data)==row['Bytes'] and sha(data)==row['Sha256']
print(json.dumps({'SourceCommit':source_head,'ManifestSha256':sha(raw_manifest),'ArchiveBytes':len(packed),'Members':len(members),'Reservation':metadata['Reservation']},indent=2))
