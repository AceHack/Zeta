from pathlib import Path
import ast,hashlib,json,os,subprocess,time,tomllib
root=Path.cwd().resolve();out=root/'.git/projection-lint-cwd-correction-1';out.mkdir(exist_ok=False)
python='/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906/src/Interp.Python/.venv/bin/python'
env=dict(os.environ,PYTHONPATH=str(root/'src/Interp.Python'))
manifest=json.loads((root/'docs/research/precision-gate-projection/2026-09-08/implementation-source/implementation-manifest.json').read_bytes())
files=[root/r['Path'] for r in manifest['SourceFiles']]
before={str(p.relative_to(root)):p.read_bytes() for p in files}
for name,b in before.items():
 p=out/'before'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def call(label,argv,cwd=root):
 start=time.time()
 (out/(label+'.invocation.json')).write_text(json.dumps({'Argv':argv,'Cwd':str(cwd),'EnvironmentOverride':{'PYTHONPATH':env['PYTHONPATH']},'StartedUnix':start},indent=2)+'\n')
 r=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,check=False)
 (out/(label+'.stdout.txt')).write_bytes(r.stdout);(out/(label+'.stderr.txt')).write_bytes(r.stderr)
 (out/(label+'.completion.json')).write_text(json.dumps({'ExitCode':r.returncode,'FinishedUnix':time.time()},indent=2)+'\n')
 print(label,r.returncode,flush=True);return r
r=call('package-before',[python,'-m','ruff','check','.'],root/'src/Interp.Python');assert r.returncode==1
project=root/'src/Interp.Python/pyproject.toml';old_toml=tomllib.loads(project.read_text())
project.write_text(project.read_text()+'\n# Keep import grouping identical from the repo root and this package directory.\n[tool.ruff.lint.isort]\nknown-first-party = ["zeta_interp"]\n')
tests=[p for p in files if p.suffix=='.py' and 'tests' in p.parts and p.name.startswith('test_precision_gate_projection_')]
r=call('fix-import-separators',[python,'-m','ruff','check','--select','I001','--fix',*[str(p) for p in tests]]);assert r.returncode==0
changed=[]
for p in files:
 name=str(p.relative_to(root));b=p.read_bytes();q=out/'after'/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
 if b!=before[name]:
  row={'Path':name,'BeforeBytes':len(before[name]),'AfterBytes':len(b),'BeforeSha256':hashlib.sha256(before[name]).hexdigest().upper(),'AfterSha256':hashlib.sha256(b).hexdigest().upper()}
  if p.suffix=='.py':
   assert ast.dump(ast.parse(before[name]))==ast.dump(ast.parse(b));assert before[name].replace(b'\n',b'')==b.replace(b'\n',b'');row['AstIdentical']=True;row['OnlyNewlinesChanged']=True
  else:assert p==project
  changed.append(row)
assert len(changed)==8 and len([r for r in changed if r.get('AstIdentical')])==7
new_toml=tomllib.loads(project.read_text());assert new_toml['tool'].pop('ruff')=={'lint':{'isort':{'known-first-party':['zeta_interp']}}};assert new_toml==old_toml
(out/'changed-identities.json').write_text(json.dumps({'Head':subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(),'ChangedFiles':changed,'FrozenSourceFilesCompared':len(files),'UnchangedFiles':len(files)-len(changed),'RuntimeSourceChanged':False,'ProjectChange':'Only explicit Ruff first-party package classification'},indent=2)+'\n')
results=[]
for label,argv,cwd in [
 ('root-lint',[python,'-m','ruff','check','src/Interp.Python'],root),
 ('package-lint',[python,'-m','ruff','check','.'],root/'src/Interp.Python'),
 ('package-format',[python,'-m','ruff','format','--check','.'],root/'src/Interp.Python'),
 ('package-mypy',[python,'-m','mypy','zeta_interp/','tests/'],root/'src/Interp.Python'),
 ('component-pytest',[python,'-m','pytest',*[str(p) for p in tests],'-q'],root)]:
 r=call(label,argv,cwd);results.append({'Label':label,'ExitCode':r.returncode})
(out/'result.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(changed,indent=2));raise SystemExit(0 if all(r['ExitCode']==0 for r in results) else 1)
