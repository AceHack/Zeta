from pathlib import Path
import subprocess, os, json, datetime, time, hashlib, sys
out=Path('.git/projection-run-fixture-tests-'+sys.argv[1]);out.mkdir()
source=Path('.git/projection-run-fixture-tests-1/dependency/precision_gate_projection_process.py')
snap=out/'dependency';snap.mkdir();(snap/source.name).write_bytes(source.read_bytes())
paths=['src/Interp.Python/zeta_interp/precision_gate_projection_run.py','src/Interp.Python/tests/test_precision_gate_projection_run.py']
for p in paths:(out/Path(p).name).write_bytes(Path(p).read_bytes())
args=[paths[1],'-q']+sys.argv[2:]
bootstrap='import pytest\nclass Bootstrap:\n def pytest_configure(self):\n  import zeta_interp\n  zeta_interp.__path__.append('+repr(str(snap.resolve()))+')\nraise SystemExit(pytest.main('+repr(args)+',plugins=[Bootstrap()]))\n'
commands=[['ruff','check',*paths],['src/Interp.Python/.venv/bin/python','-c',bootstrap]]
(out/'capture.py').write_bytes(Path(__file__).read_bytes())
(out/'start.json').write_text(json.dumps({'UTC':datetime.datetime.now(datetime.UTC).isoformat(),'Scope':'synthetic callback tests with immutable captured draft DTO; no native process, solver or final subject executed','DraftSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'Argv':commands},indent=2)+'\n')
env=dict(os.environ,PYTHONPATH='src/Interp.Python');rows=[]
for i,cmd in enumerate(commands):
 t=time.time()
 with (out/f'{i}-stdout').open('wb') as so,(out/f'{i}-stderr').open('wb') as se:r=subprocess.run(cmd,env=env,stdout=so,stderr=se)
 rows.append({'Argv':cmd,'Exit':r.returncode,'Seconds':time.time()-t})
(out/'process.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows))
