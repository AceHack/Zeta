from pathlib import Path
import hashlib, json, os, subprocess, time
root = Path.cwd().resolve()
record = root / '.git/projection-final-execution-1'
record.mkdir(exist_ok=False)
def save(name, value):
    (record / name).write_text(json.dumps(value, indent=2) + '\n')
manifest = root / 'docs/research/precision-gate-projection/2026-09-08/implementation-source/implementation-manifest.json'
expected = 'FE1F5BDF732FA6B08092887210552BA9CEF68D724E519C77958A282366A348E7'
body = manifest.read_bytes()
assert hashlib.sha256(body).hexdigest().upper() == expected
parsed = json.loads(body)
host = Path('/Users/acehack/.local/share/mise/dotnet-root/dotnet')
observations = []
for row in parsed['SourceFiles'] + parsed['NativeFiles']:
    path = root / row['Path'] if 'Path' in row else host if row['Role'] == '@host' else root / row['Role']
    actual = path.read_bytes()
    item = {'Path': str(path), 'Bytes': len(actual), 'Sha256': hashlib.sha256(actual).hexdigest().upper()}
    assert (item['Bytes'], item['Sha256']) == (row['Bytes'], row['Sha256'])
    observations.append(item)
remotes = []
for branch, expected_head in [('codex/scalar-projection-evaluation-20260908', 'ba7c312d55233f507ecbbfd62e3c3fb733fd35a7'), ('codex/compiled-runtime-admission-review-20260907', '13ede4d8cfa7b69e579fe67ab477faefa5c07dab')]:
    argv = ['git', 'ls-remote', 'origin', 'refs/heads/' + branch]
    started = time.time()
    result = subprocess.run(argv, capture_output=True, check=False)
    remotes.append({'Argv': argv, 'StartedUnix': started, 'FinishedUnix': time.time(), 'ExitCode': result.returncode, 'Stdout': result.stdout.decode(), 'Stderr': result.stderr.decode()})
    assert result.returncode == 0 and result.stdout.decode().split()[0] == expected_head
save('prerequisites.json', {'SourcePublication': 'ba7c312d55233f507ecbbfd62e3c3fb733fd35a7', 'ArchiveAdmission': '13ede4d8cfa7b69e579fe67ab477faefa5c07dab', 'ExecutedHead': subprocess.check_output(['git','rev-parse','HEAD']).decode().strip(), 'Status': subprocess.check_output(['git','status','--porcelain']).decode(), 'ManifestSha256': expected, 'FileObservations': observations, 'RemoteObservations': remotes})
python = '/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906/src/Interp.Python/.venv/bin/python'
argv = [python, '-m', 'zeta_interp.precision_gate_projection_driver', '--source-root', str(root), '--manifest', str(manifest), '--manifest-sha256', expected, '--output-parent', str(root / '.git/projection-final-attempts'), '--attempt', 'registered-1', '--dotnet', str(host)]
env = dict(os.environ, PYTHONPATH=str(root / 'src/Interp.Python'))
save('invocation.json', {'Argv': argv, 'Cwd': str(root), 'EnvironmentOverride': {'PYTHONPATH': env['PYTHONPATH']}, 'StartedUnix': time.time(), 'AccountingScope': 'External coordinator process provenance; excluded from attempt retention reservation; no full DriverResult serialization'})
start = time.monotonic()
with (record / 'stdout.txt').open('xb') as out, (record / 'stderr.txt').open('xb') as err:
    result = subprocess.run(argv, cwd=root, env=env, stdout=out, stderr=err, check=False)
save('completion.json', {'ExitCode': result.returncode, 'FinishedUnix': time.time(), 'ElapsedSeconds': time.monotonic()-start})
print((record / 'stdout.txt').read_text())
print((record / 'stderr.txt').read_text())
print((record / 'completion.json').read_text())
