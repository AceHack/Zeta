from pathlib import Path
import collections, gzip, hashlib, io, json, subprocess, tarfile, time, zlib
root=Path.cwd().resolve(); attempt=root/'.git/projection-final-attempts/registered-1'; coordinator=root/'.git/projection-final-execution-1'
out=root/'docs/research/precision-gate-projection/2026-09-08/registered-1'; out.mkdir(exist_ok=False)
def digest(b): return hashlib.sha256(b).hexdigest().upper()
def save(p,v): p.write_text(json.dumps(v,indent=2)+'\n')
def read(p): return json.loads(p.read_bytes())
outer=read(attempt/'outer-final.json'); terminal=read(attempt/outer['Run']['Terminal']['Fields']['File']); journal=read(attempt/'records/final-journal.json')
seen={}
def verify_descriptors(value):
 if isinstance(value,dict):
  if all(k in value for k in ('File','Bytes','Sha256','StoredBytes','StoredSha256','Encoding')):
   rel=Path(value['File']); assert not rel.is_absolute() and '..' not in rel.parts
   b=(attempt/rel).read_bytes(); assert len(b)==value['StoredBytes'] and digest(b)==value['StoredSha256']
   plain=b if value['Encoding']=='identity' else gzip.decompress(b)
   assert len(plain)==value['Bytes'] and digest(plain)==value['Sha256']
   if str(rel) in seen: assert seen[str(rel)]==value
   seen[str(rel)]=value
  for item in value.values(): verify_descriptors(item)
 elif isinstance(value,list):
  for item in value: verify_descriptors(item)
for value in (outer,terminal,journal): verify_descriptors(value)
assert outer['Failure'] is None and outer['Run']['CollectionAndCriteriaPassed'] is True
assert terminal['RosterCollected'] is True and terminal['ExpectedOutcomesPassed'] is True and not terminal['Pending']
assert len(terminal['Entries'])==88 and len(set(r['CaseId'] for r in terminal['Entries']))==40
assert len(terminal['CoreCertified'])==12
rows=[]
for i,row in enumerate(terminal['Entries']):
 assert i==row['Index'] and row['Entered'] and row['CompleteReceipt'] and row['ReceiptRetained']
 a=row['Assessment']['Fields']['value']['Fields']; assert not a['Abnormal'] and a['Expected'] is not False
 rows.append({'Index':i,'CaseId':row['CaseId'],'Operation':row['Operation'],'Kind':a['Kind'],'FailureCode':a['FailureCode'],'Expected':a['Expected'],'CoreCertified':a['CoreCertified'],'Artifacts':row['Artifacts']})
manifest=read(attempt/'manifest.json')
post=[]
for row in manifest['SourceFiles']:
 b=(root/row['Path']).read_bytes(); assert len(b)==row['Bytes'] and digest(b)==row['Sha256']; post.append(row)
assert (attempt/'source-snapshot-1.json').read_bytes()==(attempt/'source-snapshot-2.json').read_bytes()
files=sorted(p for p in attempt.rglob('*') if p.is_file()); assert all(not p.is_symlink() for p in files)
summary={'Schema':'zeta.precision-projection.post-run-observation.v1','Scope':'Post-run extraction and custody checks, no numerical re-execution','Invocation':read(coordinator/'invocation.json'),'Completion':read(coordinator/'completion.json'),'ManifestSha256':digest((attempt/'manifest.json').read_bytes()),'ExecutedHead':read(coordinator/'prerequisites.json')['ExecutedHead'],'Counters':terminal['Counters'],'CoreCertified':terminal['CoreCertified'],'ExpectedOutcomesPassed':terminal['ExpectedOutcomesPassed'],'RosterCollected':terminal['RosterCollected'],'Pending':terminal['Pending'],'PrimaryFailure':terminal['PrimaryFailure'],'Baseline':terminal['Baseline'],'DescriptorFilesVerified':len(seen),'AttemptFiles':len(files),'AttemptFileBytes':sum(p.stat().st_size for p in files),'Reservation':outer['Reservation'],'JournalPreFinalEncodingReservation':{k:journal[k] for k in ('ReservedRawBytes','ReservedStoredBytes','ReservedSlots')},'CurrentSourceFilesUnchanged':len(post),'Rows':rows,'Limitations':['Post-run byte census is not total process memory/disk cost','Actual in-memory DriverResult/RunResult were not fully serialized','No source-to-machine or transitive runtime closure proof','Finite scalar Gaussian projection, not learned-system or state-of-the-art evaluation']}
save(out/'observation.json',summary)
items=[]
for p in files: items.append(('attempt/'+p.relative_to(attempt).as_posix(),p))
for p in sorted(coordinator.iterdir()):
 if p.is_file(): items.append(('coordinator/'+p.name,p))
items += [('coordinator/execution-helper.py',root/'.git/projection-final-execution-1.py'),('analysis/archive-helper.py',Path(__file__).resolve()),('analysis/observation.json',out/'observation.json')]
blob=io.BytesIO(); entries=[]
with tarfile.open(fileobj=blob,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for name,p in items:
  b=p.read_bytes(); info=tarfile.TarInfo(name); info.size=len(b); info.mode=0o644; info.mtime=0
  tar.addfile(info,io.BytesIO(b)); entries.append({'Path':name,'Bytes':len(b),'Sha256':digest(b),'OriginalPath':str(p)})
packed=gzip.compress(blob.getvalue(),mtime=0); (out/'custody.tar.gz').write_bytes(packed)
d=zlib.decompressobj(31); plain=d.decompress(packed)+d.flush(); assert d.eof and not d.unused_data
with tarfile.open(fileobj=io.BytesIO(plain),mode='r:') as tar:
 members=tar.getmembers(); assert len(members)==len(entries)
 for member,row in zip(members,entries,strict=True):
  assert member.isfile() and member.name==row['Path']; b=tar.extractfile(member).read(); assert len(b)==row['Bytes'] and digest(b)==row['Sha256']
save(out/'manifest.json',{'Schema':'zeta.research-custody.archive.v1','Archive':'custody.tar.gz','Bytes':len(packed),'Sha256':digest(packed),'Members':entries,'MemberCount':len(entries),'PayloadBytes':sum(r['Bytes'] for r in entries),'VerifiedWithoutExtraction':True,'ObservedUnix':time.time()})
print(json.dumps({'Rows':len(rows),'Subjects':len(set(r['CaseId'] for r in rows)),'CoreCertificates':len(terminal['CoreCertified']),'VerifiedDescriptorFiles':len(seen),'AttemptFiles':len(files),'AttemptBytes':summary['AttemptFileBytes'],'ArchiveMembers':len(entries),'ArchiveBytes':len(packed),'ArchiveSha256':digest(packed),'OutcomeCounts':dict(collections.Counter(r['Kind'] for r in rows))},indent=2))
