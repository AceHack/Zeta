from pathlib import Path
import json, gzip, hashlib
root = Path.cwd()
out = root / "docs/research/precision-gate-projection/2026-09-08/final-native-process-gate-2"
out.mkdir(exist_ok=False)
paths = []
for name in ["precision-projection-corrected-full-preflight-2", "precision-projection-corrected-formatter-1", "precision-projection-process-owner-push-1"]:
    paths.extend(sorted((root / ".git" / name).iterdir()))
paths.append(root / ".git/precision-projection-final-gate-preserve-2.py")
records = []
for i, p in enumerate(paths, 1):
    raw = p.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    name = f"{i:03d}-{p.parent.name}-{p.name}.gz"
    with (out / name).open("xb") as stream:
        stream.write(stored)
    records.append({"OriginalPath": str(p), "File": name, "Bytes": len(raw), "Sha256": hashlib.sha256(raw).hexdigest(), "StoredBytes": len(stored), "StoredSha256": hashlib.sha256(stored).hexdigest()})
base = json.loads((root / "docs/research/precision-gate-projection/2026-09-08/process-correction-1/manifest.json").read_text())
sources = []
for row in base["Sources"]:
    if row["Path"].endswith("precision-gate-projection-process-source.md"):
        continue
    raw = (root / row["Path"]).read_bytes()
    assert len(raw) == row["Bytes"] and hashlib.sha256(raw).hexdigest() == row["Sha256"]
    sources.append(row)
assert json.loads((root / ".git/precision-projection-corrected-full-preflight-2/completion.json").read_text())["ExitCode"] == 0
assert "all 18 executed check(s) passed." in (root / ".git/precision-projection-corrected-full-preflight-2/stdout").read_text()
assert json.loads((root / ".git/precision-projection-corrected-formatter-1/completion.json").read_text())["ExitCode"] == 0
assert "Format currently supports only C# and Visual Basic projects." in (root / ".git/precision-projection-corrected-formatter-1/stderr").read_text()
manifest = {"Schema": "zeta.precision-projection.final-native-process-gate.v1", "SourceCommit": "8254c827044100df1646369f1b0143ec994d5a07", "SourceReviewCommit": "2ac23bf2efdc33a57fffc068fb74c2567155356d", "FullPreflight": {"ExitCode": 0, "Passed": 18}, "Formatter": {"ExitCode": 0, "FSharpSupported": False}, "PriorOwnerPush": {"Head": "59e1867c98b3620ae0af2c96fb5740a0ac8cd904", "ExitCode": 0, "QuickPassed": 16, "RemoteHeadVerified": True}, "PriorPreservation": "../final-native-process-gate-1/manifest.json", "FinalComparisonRun": False, "ReferenceResultsRead": False, "Sources": sources, "Records": records}
(out / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
for row in records:
    assert gzip.decompress((out / row["File"]).read_bytes()) == Path(row["OriginalPath"]).read_bytes()
print(json.dumps({"Records": len(records), "Sources": len(sources), "RawBytes": sum(r["Bytes"] for r in records), "StoredBytes": sum(r["StoredBytes"] for r in records)}))
