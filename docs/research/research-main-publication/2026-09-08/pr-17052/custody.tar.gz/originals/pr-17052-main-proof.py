import datetime, json, pathlib, subprocess
root=pathlib.Path(__file__).resolve().parent.parent
out=root/'.git/pr-17052-main-proof-1';out.mkdir(exist_ok=False)
head='537803aceabfe6260353e9e946b28edab0d149ca';calls=[]
def call(argv,cwd=root):
    n=len(calls);start=datetime.datetime.now(datetime.UTC).isoformat();p=subprocess.run(argv,cwd=cwd,capture_output=True);end=datetime.datetime.now(datetime.UTC).isoformat()
    (out/f'{n}-stdout').write_bytes(p.stdout);(out/f'{n}-stderr').write_bytes(p.stderr)
    calls.append(dict(argv=argv,cwd=str(cwd),start=start,end=end,exit=p.returncode));(out/'calls.json').write_text(json.dumps(calls,indent=2)+'\n')
    if p.returncode: raise RuntimeError((argv,p.returncode,p.stderr.decode()))
    return p.stdout
pr=json.loads(call(['/opt/homebrew/bin/gh','pr','view','17052','--json','number,state,headRefOid,mergeCommit,mergedAt,title,url']))
if pr['state']!='MERGED' or pr['headRefOid']!=head: raise RuntimeError('PR merge identity mismatch')
merge=pr['mergeCommit']['oid'];call(['git','fetch','origin','refs/heads/main:refs/remotes/origin/main'])
main=call(['git','rev-parse','origin/main']).decode().strip();call(['git','merge-base','--is-ancestor',merge,main])
parent=call(['git','rev-parse',merge+'^']).decode().strip();base=call(['git','merge-base',parent,head]).decode().strip()
expected=call(['git','merge-tree','--write-tree',parent,head]).decode().splitlines()[0]
actual=call(['git','rev-parse',merge+'^{tree}']).decode().strip()
if expected!=actual: raise RuntimeError('whole merge tree mismatch')
paths=call(['git','diff','--no-renames','--name-only','-z',base,head]).decode().split('\0');paths=[x for x in paths if x]
def rows(tree):
    entries=call(['git','ls-tree','-r','-z',tree,'--',*paths]).decode().split('\0')
    return {s.split('\t',1)[1]:s.split('\t',1)[0] for s in entries if s}
e,m,o=rows(expected),rows(merge),rows(main)
census=[dict(Path=p,Expected=e.get(p),Merged=m.get(p),ObservedMain=o.get(p)) for p in paths]
proof=dict(PR=pr,Head=head,Merge=merge,MergeParent=parent,Base=base,ObservedMain=main,ExpectedWholeTree=expected,MergedWholeTree=actual,WholeTreeEqual=expected==actual,ChangedPathCountNoRenames=len(paths),AllPathsEqualOnObservedMain=all(x['Expected']==x['Merged']==x['ObservedMain'] for x in census),Paths=census)
if not proof['AllPathsEqualOnObservedMain']: raise RuntimeError('changed path mismatch on main')
(out/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
view=pathlib.Path('/Users/acehack/Documents/src/repos/Zeta')
before=call(['git','status','--porcelain'],view);branch=call(['git','branch','--show-current'],view).decode().strip()
if before or branch!='main': raise RuntimeError('shared view not clean main; skip refresh')
call(['git','pull','--ff-only','origin','main'],view);after=call(['git','status','--porcelain'],view);viewhead=call(['git','rev-parse','HEAD'],view).decode().strip();call(['git','merge-base','--is-ancestor',merge,'HEAD'],view)
(out/'shared-view.json').write_text(json.dumps(dict(Path=str(view),BeforeClean=not before,Branch=branch,AfterClean=not after,Head=viewhead,MergeIsAncestor=True),indent=2)+'\n')
print(json.dumps({k:v for k,v in proof.items() if k!='Paths'},indent=2));print('Shared view',viewhead,'clean',not after)
