import gzip, hashlib, io, json, pathlib, tarfile
root=pathlib.Path(__file__).resolve().parent.parent
proof=json.loads((root/'.git/pr-17052-main-proof-1/proof.json').read_text())
if not proof['WholeTreeEqual'] or not proof['AllPathsEqualOnObservedMain']: raise RuntimeError('publication proof not exact')
selected=[]
for item in sorted((root/'.git').glob('pr-17052-*')):
    selected.extend(sorted(x for x in item.rglob('*') if x.is_file()) if item.is_dir() else [item])
for pattern in ['epoch-contract-pr-create-1','epoch-contract-publication-push-1','epoch-contract-publication-push-2']:
    folder=root/'.git'/pattern
    selected.extend(sorted(x for x in folder.rglob('*') if x.is_file()))
if len(selected)!=len(set(selected)): raise RuntimeError('duplicate selected originals')
rows=[];buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w',format=tarfile.USTAR_FORMAT) as tar:
    for source in sorted(selected):
        if source.is_symlink(): raise RuntimeError('symlink original')
        rel=source.relative_to(root/'.git').as_posix();raw=source.read_bytes();name='originals/'+rel
        info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(raw))
        rows.append(dict(ArchivePath=name,OriginalPath='.git/'+rel,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
raw=gzip.compress(buffer.getvalue(),mtime=0)
out=root/'docs/research/research-main-publication/2026-09-08/pr-17052';out.mkdir(exist_ok=False)
(out/'custody.tar.gz').write_bytes(raw)
manifest=dict(Schema='zeta.research-main-custody.v1',PR=17052,SourceHead=proof['Head'],Merge=proof['Merge'],ObservedMain=proof['ObservedMain'],Archive='custody.tar.gz',ArchiveBytes=len(raw),ArchiveSha256=hashlib.sha256(raw).hexdigest().upper(),MemberCount=len(rows),OriginalBytes=sum(x['Bytes'] for x in rows),Members=rows)
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(fileobj=io.BytesIO(raw),mode='r:gz') as tar:
    members=tar.getmembers()
    if [x.name for x in members]!=[x['ArchivePath'] for x in rows]: raise RuntimeError('archive inventory')
    for row in rows:
        f=tar.extractfile(row['ArchivePath'])
        if f is None: raise RuntimeError('missing archive member')
        data=f.read()
        if len(data)!=row['Bytes'] or hashlib.sha256(data).hexdigest().upper()!=row['Sha256']: raise RuntimeError('archive identity')
print(json.dumps({k:v for k,v in manifest.items() if k!='Members'},indent=2))
