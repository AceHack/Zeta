import json, subprocess, pathlib, datetime, collections, sys
root=pathlib.Path(__file__).resolve().parent.parent
out=root/('.git/pr-17052-observation-'+sys.argv[1]);out.mkdir(exist_ok=False)
request=json.loads((root/'.git/pr-17052-observation-request.json').read_text())
contexts=[];threads=[];page=0
while True:
    req=out/f'request-{page}.json';req.write_text(json.dumps(request,indent=2)+'\n')
    argv=['/opt/homebrew/bin/gh','api','graphql','--input',str(req)]
    start=datetime.datetime.now(datetime.UTC).isoformat();p=subprocess.run(argv,cwd=root,capture_output=True);end=datetime.datetime.now(datetime.UTC).isoformat()
    (out/f'stdout-{page}.json').write_bytes(p.stdout);(out/f'stderr-{page}.txt').write_bytes(p.stderr)
    (out/f'invocation-{page}.json').write_text(json.dumps(dict(argv=argv,cwd=str(root),start=start,end=end,exit=p.returncode),indent=2)+'\n')
    if p.returncode: raise RuntimeError(p.stderr.decode())
    data=json.loads(p.stdout)
    if data.get('errors'): raise RuntimeError(data['errors'])
    pr=data['data']['repository']['pullRequest']
    if pr['headRefOid']!='1387b4bd0986f97fb6dac33c337c96779bf582e9': raise RuntimeError('unexpected head')
    c=pr['commits']['nodes'][0]['commit']['statusCheckRollup']['contexts'];t=pr['reviewThreads']
    if request['variables']['includeContexts']: contexts.extend(c['nodes'])
    if request['variables']['includeThreads']: threads.extend(t['nodes'])
    nc=request['variables']['includeContexts'] and c['pageInfo']['hasNextPage'];nt=request['variables']['includeThreads'] and t['pageInfo']['hasNextPage']
    if not nc and not nt: break
    request['variables'].update(contextCursor=c['pageInfo']['endCursor'] if nc else None,threadCursor=t['pageInfo']['endCursor'] if nt else None,includeContexts=nc,includeThreads=nt);page+=1
if len({x['id'] for x in contexts})!=len(contexts) or len(contexts)!=c['totalCount']: raise RuntimeError('context count drift')
if len({x['id'] for x in threads})!=len(threads) or len(threads)!=t['totalCount']: raise RuntimeError('thread count drift')
summary={k:v for k,v in pr.items() if k not in ['commits','reviewThreads']}
summary.update(ContextCount=len(contexts),Conclusions=dict(collections.Counter(x.get('conclusion') or x.get('status') or x.get('state') for x in contexts)),Outstanding=[x for x in contexts if (x.get('conclusion') or x.get('state')) not in ['SUCCESS','SKIPPED']],Unresolved=[x for x in threads if not x['isResolved']],Pages=page+1)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
