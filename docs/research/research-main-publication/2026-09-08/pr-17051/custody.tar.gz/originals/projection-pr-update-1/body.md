The precision-gate kernels lacked a native Gaussian projection with an independently checked numerical result. This adds the bounded F# candidate solver, directed-interval Python reference and certificate checks, plus a source-bound driver that records typed refusals and retains every call under a shared budget.

The first preregistered comparison completed all 88 calls across 40 subject IDs: twelve core certificates, 27 native children closed and no pending calls. The cancellation stress remains uncertified after reference exhaustion; numerical refusal and malformed-input controls are retained. All twelve certificate mutations were rejected using the actual retained baseline. This admits a finite local Gaussian projection prerequisite for composable Bayesian learning graphs; it makes no learned-performance or state-of-the-art claim.

Review starts at `docs/research/2026-09-08-precision-gate-projection-integration-register.md` and `docs/research/2026-09-08-precision-gate-projection-registered-results.md`. The source, original failed controls/corrections, independent component reviews and complete actual-run custody are preserved and indexed. Independent component, source/archive, actual-outcome and post-experiment hygiene reviews accept their explicitly bounded source cuts.

Validation: all 18 full-preflight checks passed at the recorded assembled source cut; separate ordinary-import Python validation passed 340 tests plus configured mypy/Ruff/format checks. A one-blank-line test formatting correction is explicitly bound to the later Python snapshot; production bytes are unchanged. Formatter exited zero with its unsupported-F# limitation. The exact final-run manifest was independently admitted and remotely preserved before invocation. The first CI interpretability lane passed 2,286 tests, then refused seven cwd-dependent import separators. Explicit first-party classification and those seven blank lines fix that discrepancy: both root/package lint, whole-lane format, typing of 113 files and 340 component tests pass. All test syntax trees and production sources are unchanged; the historical numerical manifest remains bound to its original source. The complete subsequent CI matrix is required before normal merge.

Next investment is the mixed-message evidence/cavity/application and module-epoch contract. Compiled-controller streams 9307/9409 remain unopened and that investment remains paused.

Agency-Signature-Version: 1
Agent: Vera
Agent-Runtime: OpenAI Codex
Agent-Model: GPT-6 Astra
Credential-Identity: AceHack
Credential-Mode: shared
Human-Review: none
Human-Review-Evidence: none
Action-Mode: autonomous-fail-open
Task: 081M1Z63YMC087G0R003N5FH9X
Co-Authored-By: Codex <noreply@openai.com>
