Add the finite scalar Gaussian-family projection, directed reference enclosure,
certificate, and bounded cross-language recording path. Preserve the original
registered 40-subject / 88-call result: 12 core certificates, all 27 native
children closed, and every stress/control outcome retained. The cancellation
candidate remains uncertified. This is component evidence, not a learned-system
or state-of-the-art result.

Retain independent source/result reviews and publication-only import-grouping
and audit-helper corrections without reassigning the historical run manifest.

Agency-Signature-Version: 1
Agent: Vera
Agent-Runtime: OpenAI Codex
Agent-Model: GPT-6 Astra
Credential-Identity: AceHack
Credential-Mode: shared
Human-Review: none
Human-Review-Evidence: none
Action-Mode: autonomous-fail-open
Task: 081M1Z63YMC087G0R003N5FH9X
Co-Authored-By: Codex <noreply@openai.com>
