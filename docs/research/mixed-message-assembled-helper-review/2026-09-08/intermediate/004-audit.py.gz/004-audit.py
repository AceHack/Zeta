"""Read retained helper sources/fixture data; never invoke either helper."""
import hashlib
import json
from pathlib import Path
import stat

owner = Path(__file__).resolve().parent
root = Path('/Users/acehack/.zeta/agents/codex/Zeta-projection-publication-20260908')

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

identities = json.loads((owner / 'source-identities.json').read_bytes())
for row in identities:
    retained = (owner / row['Path'].removeprefix('.git/')).read_bytes()
    actual = (root / row['Path']).read_bytes()
    if actual != retained or len(retained) != row['Bytes'] or sha(retained) != row['Sha256']:
        raise RuntimeError('source/result identity differs: ' + row['Path'])

checks = []
for label in ['late-metadata-refusal', 'fifo-source-refusal']:
    prefix = root / '.git/mixed-observation-freeze-fixtures-1' / label / '.git/mixed-source-freeze-prefix-1'
    rows = []
    for path in sorted(prefix.glob('*.json')):
        row = json.loads(path.read_bytes())
        file = prefix / row['File']
        observed = file.lstat()
        if not stat.S_ISREG(observed.st_mode) or observed.st_size > 128 * 1024 * 1024:
            raise RuntimeError('prefix type/size: ' + str(path))
        raw = file.read_bytes()
        if len(raw) != row['Bytes'] or sha(raw) != row['Sha256']:
            raise RuntimeError('prefix identity: ' + str(path))
        rows.append(row)
    names = [row['Name'] for row in rows]
    checks.append(dict(Case=label, StoredPrefixRows=len(rows), UniqueNames=len(set(names)), RawBytes=sum(row['Bytes'] for row in rows), DuplicateNames=sorted({name for name in names if names.count(name) > 1})))

capture = json.loads((owner / 'mixed-observation-capture-fixtures-1/results.json').read_bytes())
freeze = json.loads((owner / 'mixed-observation-freeze-fixtures-1/results.json').read_bytes())
if len(capture['Cases']) != 4 or len(freeze['Cases']) != 2:
    raise RuntimeError('fixture roster')
if [row['WrapperExit'] for row in capture['Cases']] != [2, 2, 2, 2]:
    raise RuntimeError('capture outcomes')
if [row['ChildExit'] for row in capture['Cases']] != [7, None, 0, None]:
    raise RuntimeError('actual synthetic child outcomes')
if [row['ExitCode'] for row in freeze['Cases']] != [2, 2]:
    raise RuntimeError('freeze outcomes')
print(json.dumps(dict(Scope='Retained bytes and source/fixture identity only; no helper, subprocess, numerical or registered invocation', SourceResultIdentities=len(identities), FixtureCases=6, PrefixChecks=checks), indent=2))
