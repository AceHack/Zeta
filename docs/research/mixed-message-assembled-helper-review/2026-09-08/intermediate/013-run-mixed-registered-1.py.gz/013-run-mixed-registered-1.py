"""Once-only observation of fixed controls, bound by caller-supplied admission hashes.

Ordinary exceptions are recorded separately; filesystem/console failure can still
prevent publication. This wrapper does not give a numerical control verdict.
"""
from pathlib import Path
import subprocess,sys,os,hashlib,json,time,datetime,stat,tarfile,io
from zeta_interp import hidden_switch_compiled_storage as storage
from zeta_interp import hidden_switch_compiled_admission as admission


def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def read_regular(path, cap):
    observed=path.lstat()
    if not stat.S_ISREG(observed.st_mode) or observed.st_size>cap:
        raise ValueError('not a bounded regular file: '+str(path))
    result=storage.read_exact(path.parent,path.name,expected_bytes=observed.st_size,maximum_bytes=cap)
    if not isinstance(result,admission.Admitted) or type(result.value) is not bytes:
        raise ValueError(repr(result))
    return result.value


def main():
    r=Path.cwd();mode=sys.argv[1];expected=sys.argv[2];accepted_archive=sys.argv[3]
    if mode not in ('m4','m5-and-frozen-nested'):raise ValueError('fixed mode required')
    for value in (expected,accepted_archive):
        if len(value)!=64 or any(c not in '0123456789ABCDEF' for c in value):raise ValueError('independently supplied uppercase hash required')
    base=r/'.git/mixed-registered-execution-1'
    if mode=='m4':base.mkdir();(base/'attempts').mkdir()
    out=base/mode;out.mkdir();(out/'capture.py').write_bytes(read_regular(Path(__file__),64*1024))
    errors=[];child_exit=None;entered=False;before=[];after=[]
    def failure(stage,error):
        value=dict(Stage=stage,Type=type(error).__name__,Message=str(error)[:1024]);errors.append(value)
        (out/f'error-{len(errors):03d}.json').write_text(json.dumps(value,indent=2)+'\n')
    def record(name,value):
        (out/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    host=Path('/Users/acehack/.local/share/mise/dotnet-root/dotnet').resolve();py=Path(sys.executable).resolve()
    manifest=None;frozen=r/'docs/research/mixed-message-epoch-implementation/2026-09-08/implementation-source'
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic()
    record('caller-admission.json',dict(ManifestSha256=expected,ArchiveSha256=accepted_archive,Mode=mode,Started=start))
    try:
        archive=read_regular(frozen/'custody.tar.gz',64*1024*1024)
        if sha(archive)!=accepted_archive:raise ValueError('archive differs from independently accepted bytes')
        raw=read_regular(frozen/'service-manifest.json',64*1024)
        if sha(raw)!=expected:raise ValueError('manifest differs from independently accepted bytes')
        with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
            names=[x.name for x in tar.getmembers()]
            if len(names)!=len(set(names)):raise ValueError('duplicate archive member')
            for name,value,cap in [('run-registered.py',read_regular(Path(__file__),64*1024),64*1024),('service-manifest.json',raw,64*1024)]:
                member=tar.getmember(name)
                if not member.isfile() or member.size>cap:raise ValueError('archive member type/size differs')
                handle=tar.extractfile(member)
                if handle is None or handle.read(cap+1)!=value:raise ValueError('accepted archive member differs: '+name)
        manifest=json.loads(raw);(out/'service-manifest.json').write_bytes(raw)
    except Exception as error:failure('admission',error)
    def snapshot(label):
        rows=[]
        for index,entry in enumerate([*manifest['SourceFiles'],*manifest['DirectFiles']]):
            role=entry.get('Path',entry.get('Role'));p=py if role=='@python' else host if role=='@host' else r/role
            row=dict(Role=role,ActualPath=str(p),Matches=False)
            try:
                b=read_regular(p,8*1024*1024 if 'Path' in entry else 128*1024*1024)
                row.update(Bytes=len(b),Sha256=sha(b),Matches=len(b)==entry['Bytes'] and sha(b)==entry['Sha256'])
            except Exception as error:failure(label+'/'+role,error)
            rows.append(row);record(f'{label}-{index:03d}.json',row)
        record(label+'.json',rows);return rows
    try:
        if manifest is not None:
            before=snapshot('source-before')
            if not all(x['Matches'] for x in before):raise ValueError('before-source mismatch; no child entered')
            invoker=r/'docs/research/mixed-message-epoch-implementation/2026-09-08/registered-source/invoke.py'
            a=[sys.executable,str(invoker),mode,str(r),str(base/'attempts'),str(host),str(frozen/'service-manifest.json'),expected]
            env=os.environ.copy();env['PYTHONPATH']=str(r/'src/Interp.Python')
            record('invocation.json',dict(Argv=a,Cwd=str(r),PythonPath=env['PYTHONPATH'],Started=start,SourceManifestSha256=expected))
            with (out/'stdout').open('xb') as o,(out/'stderr').open('xb') as e:
                entered=True
                result=subprocess.run(a,cwd=r,env=env,stdout=o,stderr=e,check=False)
                child_exit=result.returncode
            record('child-return.json',dict(ExitCode=child_exit,ElapsedSeconds=time.monotonic()-tick))
    except Exception as error:failure('invocation',error)
    if manifest is not None:
        try:after=snapshot('source-after')
        except Exception as error:failure('after-snapshot',error)
    records=[]
    def walk_error(error):raise error
    try:
        for dirpath,dirs,files in os.walk(base/'attempts',followlinks=False,onerror=walk_error):
            for name in sorted(dirs+files):
                p=Path(dirpath)/name;entry=dict(Path=str(p.relative_to(base)))
                try:
                    observed=p.lstat();entry.update(Mode=stat.filemode(observed.st_mode),Bytes=observed.st_size)
                    if stat.S_ISREG(observed.st_mode):entry['Sha256']=sha(read_regular(p,256*1024*1024))
                    elif stat.S_ISLNK(observed.st_mode):entry['LinkTarget']=os.readlink(p)
                except Exception as error:failure('inventory/'+entry['Path'],error)
                records.append(entry);record(f'inventory-{len(records):04d}.json',entry)
    except Exception as error:failure('inventory',error)
    record('attempt-inventory.json',records)
    matches=bool(before and after) and all(x['Matches'] for x in before+after)
    value=dict(ChildInvocationAttempted=entered,ChildExitCode=child_exit,Errors=errors,Started=start,Finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),ElapsedSeconds=time.monotonic()-tick,ActualFiles=len(records),AllSourcesUnchanged=matches,NoNumericalVerdictInCapture=True)
    record('completion.json',value);print(json.dumps(value,indent=2),flush=True)
    return 0 if child_exit==0 and not errors and matches else 2


if __name__=='__main__':
    raise SystemExit(main())
