"""Selected-source/direct-runtime freeze; no numerical execution."""
from pathlib import Path
import subprocess,hashlib,json,sys,io,tarfile,gzip,time,datetime,stat
from zeta_interp import mixed_message_epoch_bridge as bridge
from zeta_interp import precision_gate_projection_reference as reference
from zeta_interp import hidden_switch_compiled_storage as storage
from zeta_interp import hidden_switch_compiled_admission as admission
try:
 r=Path.cwd();out=r/'docs/research/mixed-message-epoch-implementation/2026-09-08/implementation-source';out.mkdir()
 head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
 tracked=subprocess.check_output(['git','status','--porcelain','--untracked-files=no'])
 if tracked:raise RuntimeError('tracked source must be clean')
 sha=lambda b:hashlib.sha256(b).hexdigest().upper()
 old=json.loads((r/'docs/research/precision-gate-projection/2026-09-08/implementation-source/implementation-manifest.json').read_text())
 extra={'tests/Bayesian.Tests/BoundedModuleLearner.Tests.fs','tests/Bayesian.Tests/MixedMessageEpoch.Tests.fs','tests/Bayesian.Tests/Bayesian.Tests.fsproj','src/Core/SoftScheduler.fs','src/Bayesian/FactorGraph.fs','docs/research/2026-09-08-mixed-message-frozen-nested-query-register.md','docs/research/mixed-message-epoch-implementation/2026-09-08/registered-source/invoke.py','docs/research/mixed-message-epoch-implementation/2026-09-08/registered-source/README.md'}
 roster=sorted({x['Path'] for x in old['SourceFiles']}|set(bridge.REQUIRED_SOURCES)|extra)
 if len(roster)>128:raise RuntimeError('source count cap')
 prefix=r/'.git/mixed-source-freeze-prefix-1';prefix.mkdir()
 class Prefix(dict):
  def __setitem__(self,name,b):
   index=len(list(prefix.glob('*.json')))
   raw_path=prefix/f'{index:04d}.raw'
   with raw_path.open('xb') as file: file.write(b)
   with (prefix/f'{index:04d}.json').open('x') as file: json.dump(dict(Name=name,File=raw_path.name,Bytes=len(b),Sha256=sha(b)),file,indent=2)
   super().__setitem__(name,b)
 items=Prefix();sources=[]
 items['freeze-source.py']=Path(__file__).read_bytes()
 def read_regular(path,cap):
  observed=path.lstat()
  if not stat.S_ISREG(observed.st_mode) or observed.st_size>cap:raise ValueError('not a bounded regular file: '+str(path))
  result=storage.read_exact(path.parent,path.name,expected_bytes=observed.st_size,maximum_bytes=cap)
  if not isinstance(result,admission.Admitted) or type(result.value) is not bytes:raise ValueError(repr(result))
  return result.value
 for name in roster:
  b=read_regular(r/name,8*bridge.MIB);items['sources/'+name]=b
  argv=['git','show',head+':'+name];tick=time.monotonic();observed=subprocess.run(argv,capture_output=True)
  items['git-source/'+str(len(sources))+'-stdout']=observed.stdout;items['git-source/'+str(len(sources))+'-stderr']=observed.stderr
  items['git-source/'+str(len(sources))+'-completion.json']=(json.dumps(dict(Argv=argv,ExitCode=observed.returncode,ElapsedSeconds=time.monotonic()-tick))+'\n').encode()
  if observed.returncode or b!=observed.stdout:raise RuntimeError('source mismatch:'+name)
  sources.append(dict(Path=name,Bytes=len(b),Sha256=sha(b)))
 if sum(x['Bytes'] for x in sources)>64*bridge.MIB:raise RuntimeError('source aggregate cap')
 host=Path('/Users/acehack/.local/share/mise/dotnet-root/dotnet').resolve();py=Path(sys.executable).resolve();direct=[];direct_archive=[]
 for role in bridge.DIRECT_ROLES:
  p=py if role=='@python' else host if role=='@host' else r/role;b=read_regular(p,bridge.native.FILE_CAP)
  if not p.is_file() or len(b)>bridge.native.FILE_CAP:raise RuntimeError('direct file cap')
  direct.append(dict(Role=role,Bytes=len(b),Sha256=sha(b)))
  member='direct/python' if role=='@python' else 'direct/dotnet' if role=='@host' else 'sources/'+role if role in roster else 'direct/'+role
  if member in items and items[member]!=b:raise RuntimeError('source/direct mismatch')
  items[member]=b;direct_archive.append(dict(Role=role,OriginalPath=str(p),ArchivePath=member,Bytes=len(b),Sha256=sha(b)))
 bindings={x['Path']:x['Sha256'] for x in sources}
 for row in direct:
  if not row['Role'].startswith('@'):bindings[row['Role']]=row['Sha256']
 bindings['ProtocolSha256']=reference.PROTOCOL_SHA256
 manifest=dict(Schema=bridge.SERVICE_SCHEMA,ExpectedBindings=dict(sorted(bindings.items())),SourceFiles=sources,DirectFiles=direct)
 raw=(json.dumps(manifest,indent=2,ensure_ascii=True,allow_nan=False)+'\n').encode()
 admitted=bridge.admit_service_manifest(raw,sha(raw))
 if not isinstance(admitted,bridge.ServiceManifest):raise RuntimeError(repr(admitted))
 (out/'service-manifest.json').write_bytes(raw);(out/'service-manifest.sha256').write_text(sha(raw)+'\n');items['service-manifest.json']=raw
 for i,a in enumerate([[str(host),'--info'],[sys.executable,'-c','import sys,platform,json; print(json.dumps({"Executable":sys.executable,"Version":sys.version,"CacheTag":sys.implementation.cache_tag,"Prefix":sys.prefix,"BasePrefix":sys.base_prefix,"Platform":platform.platform(),"Machine":platform.machine()},indent=2))']]):
  items[f'environment/{i}-invocation.json']=(json.dumps(dict(Argv=a,Started=datetime.datetime.now(datetime.timezone.utc).isoformat()))+'\n').encode()
  t=time.monotonic();p=subprocess.run(a,capture_output=True)
  items[f'environment/{i}-stdout']=p.stdout;items[f'environment/{i}-stderr']=p.stderr;items[f'environment/{i}-completion.json']=(json.dumps(dict(Argv=a,ExitCode=p.returncode,ElapsedSeconds=time.monotonic()-t),indent=2)+'\n').encode()
  if p.returncode:raise RuntimeError('runtime metadata invocation failed')
 for row in direct_archive:
  value=read_regular(Path(row['OriginalPath']),bridge.native.FILE_CAP)
  items['direct-after/'+row['Role'].replace('/','_')+'.json']=(json.dumps(dict(Role=row['Role'],Bytes=len(value),Sha256=sha(value),Matches=sha(value)==row['Sha256']))+'\n').encode()
  if sha(value)!=row['Sha256']:raise RuntimeError('direct runtime changed')
 metadata=dict(Schema='zeta.mixed-epoch.implementation-custody.v1',SourceCommit=head,ManifestSha256=sha(raw),SelectedSourceCount=len(sources),DirectFileCount=len(direct),DirectArchive=direct_archive,Invocations=['m4-registered-1','m5-registered-1','frozen-nested-1'],NamedControlsEntered=False,PassiveManifestAdmissionReturned='ServiceManifest',Scope='Committed selected source and directly observed executables/scripts/DLLs, not transitive runtime closure or source-to-machine proof. Metadata and passive manifest admission only; no peer, native producer, learner, reference or certificate execution.')
 items['source-custody.json']=(json.dumps(metadata,indent=2)+'\n').encode();items['run-registered.py']=read_regular(r/'.git/run-mixed-registered-1.py',64*1024)
 buf=io.BytesIO();members=[]
 with tarfile.open(fileobj=buf,mode='w') as tar:
  for name,b in items.items():
   info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;tar.addfile(info,io.BytesIO(b));members.append(dict(Path=name,Bytes=len(b),Sha256=sha(b)))
 z=gzip.compress(buf.getvalue(),mtime=0);(out/'custody.tar.gz').write_bytes(z)
 archive=dict(Schema='zeta.mixed-epoch.implementation-archive.v1',SourceCommit=head,ManifestSha256=sha(raw),Archive=dict(Path='custody.tar.gz',Bytes=len(z),Sha256=sha(z)),Members=members)
 (out/'archive-manifest.json').write_text(json.dumps(archive,indent=2)+'\n');(out/'source-custody.json').write_text(json.dumps(metadata,indent=2)+'\n')
 with tarfile.open(fileobj=io.BytesIO(z),mode='r:gz') as tar:
  if [m.name for m in tar.getmembers()]!=[m['Path'] for m in members]:raise RuntimeError('member roster differs')
  for row in members:
   f=tar.extractfile(row['Path'])
   if f is None:raise RuntimeError('missing member')
   b=f.read()
   if len(b)!=row['Bytes'] or sha(b)!=row['Sha256']:raise RuntimeError('member identity differs')
 print(json.dumps(dict(SourceCommit=head,ManifestSha256=sha(raw),ManifestBytes=len(raw),ArchiveBytes=len(z),ArchiveSha256=sha(z),Members=len(members),SelectedSources=len(sources),Bindings=len(bindings),DirectFiles=direct),indent=2))

except Exception as error:
 failure=dict(Stage='source-freeze',Type=type(error).__name__,Message=str(error)[:1024],NamedControlsEntered=False,CompleteArchiveEstablished=False)
 try:
  if 'items' in globals():items['freeze-failure.json']=(json.dumps(failure,indent=2)+'\n').encode()
 except Exception as secondary:
  failure['SecondaryPublicationFailure']=dict(Type=type(secondary).__name__,Message=str(secondary)[:1024])
 print(json.dumps(failure,indent=2),file=sys.stderr,flush=True)
 raise SystemExit(2)
