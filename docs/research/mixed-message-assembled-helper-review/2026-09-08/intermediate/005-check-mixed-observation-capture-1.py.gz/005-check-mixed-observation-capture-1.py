"""Isolated capture fixtures; all subprocess outcomes injected, no named route."""
from pathlib import Path
import importlib.util,sys,tempfile,json,hashlib,tarfile,io,os,contextlib,subprocess
from unittest.mock import patch
root=Path.cwd();source=root/'.git/run-mixed-registered-1.py';out=root/'.git/mixed-observation-capture-fixtures-1';out.mkdir();(out/'reviewed-source.py').write_bytes(source.read_bytes())
spec=importlib.util.spec_from_file_location('capture_fixture',source);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
sha=lambda b:hashlib.sha256(b).hexdigest().upper()
results=[]
for kind in ['child-nonzero','launch-raised','after-read-raised','wrong-accepted-manifest']:
 r=out/kind;r.mkdir();(r/'.git').mkdir();dummy=r/'selected.txt';dummy.write_bytes(b'fixed source\n')
 frozen=r/'docs/research/mixed-message-epoch-implementation/2026-09-08/implementation-source';frozen.mkdir(parents=True)
 manifest=dict(SourceFiles=[dict(Path='selected.txt',Bytes=13,Sha256=sha(dummy.read_bytes()))],DirectFiles=[])
 raw=(json.dumps(manifest)+'\n').encode();(frozen/'service-manifest.json').write_bytes(raw)
 buf=io.BytesIO()
 with tarfile.open(fileobj=buf,mode='w:gz') as tar:
  for name,b in [('run-registered.py',source.read_bytes()),('service-manifest.json',raw)]:
   info=tarfile.TarInfo(name);info.size=len(b);tar.addfile(info,io.BytesIO(b))
 archive=buf.getvalue();(frozen/'custody.tar.gz').write_bytes(archive)
 calls=[];reads=[];actual_read=module.read_regular
 def child(*a,**kw):
  calls.append('synthetic-child-entry')
  if kind=='launch-raised':raise OSError('synthetic launch failure')
  kw['stdout'].write(b'synthetic child stdout\n');kw['stderr'].write(b'synthetic child stderr\n')
  (r/'.git/mixed-registered-execution-1/attempts/retained.txt').write_bytes(b'synthetic retained artifact\n')
  return subprocess.CompletedProcess(a[0],7 if kind=='child-nonzero' else 0)
 def read(p,cap):
  if p==dummy:
   reads.append(str(p))
   if kind=='after-read-raised' and len(reads)==2:raise OSError('synthetic after-read failure')
  return actual_read(p,cap)
 os.chdir(r)
 try:
  with patch.object(sys,'argv',[str(source),'m4','0'*64 if kind=='wrong-accepted-manifest' else sha(raw),sha(archive)]),patch.object(module.subprocess,'run',child),patch.object(module,'read_regular',read),(r/'fixture-stdout').open('w') as stdout,contextlib.redirect_stdout(stdout):code=module.main()
 finally:os.chdir(root)
 completion=json.loads((r/'.git/mixed-registered-execution-1/m4/completion.json').read_text())
 if code!=2:raise RuntimeError(kind+' capture falsely passed')
 if kind=='child-nonzero' and (completion['ChildExitCode']!=7 or completion['Errors']):raise RuntimeError('nonzero child not independently retained')
 if kind=='launch-raised' and (completion['ChildExitCode'] is not None or completion['Errors'][0]['Stage']!='invocation'):raise RuntimeError('launch outcome lost')
 if kind=='after-read-raised' and (completion['ChildExitCode']!=0 or completion['AllSourcesUnchanged'] or completion['ActualFiles']!=1):raise RuntimeError('after error replaced child/inventory')
 if kind=='wrong-accepted-manifest' and (calls or completion['ChildInvocationAttempted']):raise RuntimeError('unaccepted source entered child')
 results.append(dict(Case=kind,WrapperExit=code,ChildExit=completion['ChildExitCode'],SyntheticChildCalls=len(calls),Errors=completion['Errors'],ActualFiles=completion['ActualFiles']))
(out/'results.json').write_text(json.dumps(dict(Scope='Four isolated observation fixtures; subprocess.run replaced with synthetic return or raised outcome; no peer, learner, native or reference executed',Cases=results),indent=2)+'\n')
print(json.dumps(results,indent=2))
