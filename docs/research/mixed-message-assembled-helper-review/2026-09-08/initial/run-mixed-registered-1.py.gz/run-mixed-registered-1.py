"""Capture one preregistered invocation, preserving its first actual outcome."""
from pathlib import Path
import subprocess,sys,os,hashlib,json,time,datetime,stat
r=Path.cwd();mode=sys.argv[1]
if mode not in ('m4','m5-and-frozen-nested'):raise RuntimeError('fixed mode required')
frozen=r/'docs/research/mixed-message-epoch-implementation/2026-09-08/implementation-source'
raw=(frozen/'service-manifest.json').read_bytes();manifest=json.loads(raw);sha=lambda b:hashlib.sha256(b).hexdigest().upper()
expected=(frozen/'service-manifest.sha256').read_text().strip()
if sha(raw)!=expected:raise RuntimeError('frozen manifest changed')
base=r/'.git/mixed-registered-execution-1'
if mode=='m4':base.mkdir();(base/'attempts').mkdir()
out=base/mode;out.mkdir();(out/'capture.py').write_bytes(Path(__file__).read_bytes())
host=Path('/Users/acehack/.local/share/mise/dotnet-root/dotnet').resolve();py=Path(sys.executable).resolve()
def snapshot():
 rows=[]
 for entry in [*manifest['SourceFiles'],*manifest['DirectFiles']]:
  role=entry.get('Path',entry.get('Role'));p=py if role=='@python' else host if role=='@host' else r/role;b=p.read_bytes()
  rows.append(dict(Role=role,ActualPath=str(p),Bytes=len(b),Sha256=sha(b),Matches=len(b)==entry['Bytes'] and sha(b)==entry['Sha256']))
 return rows
before=snapshot();(out/'source-before.json').write_text(json.dumps(before,indent=2)+'\n')
if not all(x['Matches'] for x in before):raise RuntimeError('before source identity differs; no invocation entered')
invoker=r/'docs/research/mixed-message-epoch-implementation/2026-09-08/registered-source/invoke.py'
a=[sys.executable,str(invoker),mode,str(r),str(base/'attempts'),str(host),str(frozen/'service-manifest.json'),expected]
env=os.environ.copy();env['PYTHONPATH']=str(r/'src/Interp.Python')
start=datetime.datetime.now(datetime.timezone.utc).isoformat();tick=time.monotonic();(out/'invocation.json').write_text(json.dumps(dict(Argv=a,Cwd=str(r),PythonPath=env['PYTHONPATH'],Started=start,SourceManifestSha256=expected,SourceCommit=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()),indent=2)+'\n')
with (out/'stdout').open('xb') as o,(out/'stderr').open('xb') as e:p=subprocess.run(a,cwd=r,env=env,stdout=o,stderr=e,check=False)
record=dict(ExitCode=p.returncode,Started=start,Finished=datetime.datetime.now(datetime.timezone.utc).isoformat(),ElapsedSeconds=time.monotonic()-tick,NoNumericalVerdictInCapture=True)
(out/'completion.json').write_text(json.dumps(record,indent=2)+'\n')
after=snapshot();(out/'source-after.json').write_text(json.dumps(after,indent=2)+'\n')
records=[]
for dirpath,dirs,files in os.walk(base/'attempts',followlinks=False):
 for name in sorted(dirs+files):
  p=Path(dirpath)/name;s=p.lstat();entry=dict(Path=str(p.relative_to(base)),Mode=stat.filemode(s.st_mode),Bytes=s.st_size)
  if stat.S_ISREG(s.st_mode):entry['Sha256']=sha(p.read_bytes())
  elif stat.S_ISLNK(s.st_mode):entry['LinkTarget']=os.readlink(p)
  records.append(entry)
(out/'attempt-inventory.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(dict(**record,ActualFiles=len(records),AllSourcesUnchanged=all(x['Matches'] for x in after)),indent=2))
