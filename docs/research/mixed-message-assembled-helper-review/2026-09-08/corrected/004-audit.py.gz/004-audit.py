"""Read final retained helper/fixture bytes only; no helper execution."""
import hashlib
import json
from pathlib import Path
import stat

owner = Path(__file__).resolve().parent
root = Path('/Users/acehack/.zeta/agents/codex/Zeta-projection-publication-20260908')

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

identities = json.loads((owner / 'source-identities.json').read_bytes())
for row in identities:
    retained = (owner / row['Path'].removeprefix('.git/')).read_bytes()
    actual = (root / row['Path']).read_bytes()
    if actual != retained or len(retained) != row['Bytes'] or sha(retained) != row['Sha256']:
        raise RuntimeError('source/result identity differs: ' + row['Path'])

checks = []
for version, label in [('2', 'late-metadata-refusal'), ('2', 'fifo-source-refusal'), ('3', 'direct-read-mismatch')]:
    prefix = root / ('.git/mixed-observation-freeze-fixtures-' + version) / label / '.git/mixed-source-freeze-prefix-1'
    rows = []
    values = {}
    for path in sorted(prefix.glob('*.json')):
        row = json.loads(path.read_bytes())
        file = prefix / row['File']
        observed = file.lstat()
        if not stat.S_ISREG(observed.st_mode) or observed.st_size > 128 * 1024 * 1024:
            raise RuntimeError('prefix type/size: ' + str(path))
        raw = file.read_bytes()
        if len(raw) != row['Bytes'] or sha(raw) != row['Sha256']:
            raise RuntimeError('prefix identity: ' + str(path))
        rows.append(row)
        values[row['Name']] = raw
    names = [row['Name'] for row in rows]
    if label == 'direct-read-mismatch' and values.get('direct-observation/src_Research.FSharp_MixedMessageEpochReplay.fsx') != b'changed direct observation\n':
        raise RuntimeError('mismatching original bytes absent')
    checks.append(dict(Case=label, StoredPrefixRows=len(rows), UniqueNames=len(set(names)), RawBytes=sum(row['Bytes'] for row in rows), DuplicateNames=sorted({name for name in names if names.count(name) > 1})))
for version, count in [('2', 2), ('3', 1)]:
    value = json.loads((owner / ('mixed-observation-freeze-fixtures-' + version) / 'results.json').read_bytes())
    if len(value['Cases']) != count or any(row['ExitCode'] != 2 for row in value['Cases']):
        raise RuntimeError('fixture outcome roster')
print(json.dumps(dict(Scope='Retained bytes and source/fixture identity only; no helper, subprocess, numerical or registered invocation', SourceResultIdentities=len(identities), FixtureCases=3, PrefixChecks=checks), indent=2))
