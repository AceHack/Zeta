"""Synthetic source-freeze failure fixtures; no real child process or control."""
from pathlib import Path
import json,os,runpy,subprocess,contextlib,sys
from unittest.mock import patch
from zeta_interp import mixed_message_epoch_bridge as bridge
from zeta_interp import hidden_switch_compiled_storage as storage
from zeta_interp import hidden_switch_compiled_admission as admission
root=Path.cwd();source=root/'.git/freeze-mixed-assembled-source-1.py';out=root/'.git/mixed-observation-freeze-fixtures-3';out.mkdir();(out/'reviewed-source.py').write_bytes(source.read_bytes())
extra={'tests/Bayesian.Tests/BoundedModuleLearner.Tests.fs','tests/Bayesian.Tests/MixedMessageEpoch.Tests.fs','tests/Bayesian.Tests/Bayesian.Tests.fsproj','src/Core/SoftScheduler.fs','src/Bayesian/FactorGraph.fs','docs/research/2026-09-08-mixed-message-frozen-nested-query-register.md','docs/research/mixed-message-epoch-implementation/2026-09-08/registered-source/invoke.py','docs/research/mixed-message-epoch-implementation/2026-09-08/registered-source/README.md'}
results=[]
for kind in ['direct-read-mismatch']:
 r=out/kind;r.mkdir();(r/'.git').mkdir();old=r/'docs/research/precision-gate-projection/2026-09-08/implementation-source/implementation-manifest.json';old.parent.mkdir(parents=True);old.write_text(json.dumps(dict(SourceFiles=[])))
 roster=sorted(set(bridge.REQUIRED_SOURCES)|extra)
 for name in roster+[x for x in bridge.DIRECT_ROLES if not x.startswith('@')]:
  p=r/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b'synthetic fixture source\n')
 if kind=='fifo-source-refusal':(r/roster[0]).unlink();os.mkfifo(r/roster[0])
 calls=[];direct_reads=[];original_read=storage.read_exact
 def mismatched_read(parent,name,**kw):
  if parent/name==r/bridge.PEER_SCRIPT:
   direct_reads.append(str(parent/name))
   if len(direct_reads)==2:return admission.Admitted(b'changed direct observation\n')
  return original_read(parent,name,**kw)
 def fake_output(a,**kw):return '' if '--porcelain' in a else 'fixture-source-commit\n'
 def fake_run(a,**kw):
  calls.append(a)
  if a[:2]==['git','show']:return subprocess.CompletedProcess(a,0,(r/a[2].split(':',1)[1]).read_bytes(),b'')
  return subprocess.CompletedProcess(a,9,b'synthetic metadata stdout\n',b'synthetic metadata stderr\n')
 os.chdir(r);code=None
 try:
  with patch.object(subprocess,'check_output',fake_output),patch.object(subprocess,'run',fake_run),patch.object(bridge,'admit_service_manifest',lambda raw,sha:bridge.ServiceManifest(raw,sha,(),(),())),patch.object(storage,'read_exact',mismatched_read),(r/'fixture-stdout').open('w') as stdout,(r/'fixture-stderr').open('w') as stderr,contextlib.redirect_stdout(stdout),contextlib.redirect_stderr(stderr):
   try:runpy.run_path(str(source),run_name='__main__')
   except SystemExit as result:code=result.code
 finally:os.chdir(root)
 prefix=r/'.git/mixed-source-freeze-prefix-1';observed={}
 for meta in prefix.glob('*.json'):
  record=json.loads(meta.read_text());observed[record['Name']]=(prefix/record['File']).read_bytes()
 if code!=2 or 'freeze-failure.json' not in observed:raise RuntimeError('freeze failure missing')
 if (r/'docs/research/mixed-message-epoch-implementation/2026-09-08/implementation-source/custody.tar.gz').exists():raise RuntimeError('failed freeze claimed complete capsule')
 if kind=='late-metadata-refusal':
  if observed.get('environment/0-stdout')!=b'synthetic metadata stdout\n' or json.loads(observed['environment/0-completion.json'])['ExitCode']!=9:raise RuntimeError('late prefix lost')
 elif kind=='fifo-source-refusal' and calls:raise RuntimeError('FIFO source entered subprocess/read')
 elif kind=='direct-read-mismatch' and observed.get('direct-observation/'+bridge.PEER_SCRIPT.replace('/','_'))!=b'changed direct observation\n':raise RuntimeError('mismatching actual read lost')
 results.append(dict(Case=kind,ExitCode=code,RetainedPrefixRecords=len(observed),SyntheticSubprocessCalls=len(calls),Failure=json.loads(observed['freeze-failure.json'])))
(out/'results.json').write_text(json.dumps(dict(Scope='Two isolated helper fixtures with fake Git/source records, injected passive manifest acceptance and synthetic metadata subprocess refusal; no real subprocess, peer, native, learner or reference',Cases=results),indent=2)+'\n');print(json.dumps(results,indent=2))
