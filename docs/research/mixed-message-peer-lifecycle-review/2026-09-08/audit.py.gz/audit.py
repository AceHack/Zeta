from pathlib import Path
import gzip
import hashlib
import json

root = Path('/Users/acehack/.zeta/agents/codex/Zeta-rendered-predictor-native-20260906')
base = root / 'docs/research/mixed-message-epoch/2026-09-08/peer-lifecycle-development'
raw_manifest = (base / 'manifest.json').read_bytes()
manifest = json.loads(raw_manifest)
def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()
def require(condition, message):
    if not condition:
        raise ValueError(message)
observations = []
files = []
raw_total = stored_total = 0
for row in manifest['Records']:
    name = row['File']
    require(Path(name).name == name and name.endswith('.gz'), 'unexpected archive path')
    stored = (base / name).read_bytes()
    require(len(stored) == row['StoredBytes'] and sha(stored) == row['StoredSha256'], 'stored mismatch ' + name)
    require(row['Bytes'] <= 4 * 1024 * 1024, 'unexpected individual raw budget')
    raw = gzip.decompress(stored)
    require(len(raw) == row['Bytes'] and sha(raw) == row['Sha256'], 'raw mismatch ' + name)
    original = Path(row['Original'])
    require(original.is_relative_to(root / '.git'), 'unexpected original locator')
    require(original.read_bytes() == raw, 'original mismatch ' + str(original))
    files.append({'File': name, 'Original': str(original), 'Bytes': len(raw), 'Sha256': sha(raw)})
    raw_total += len(raw)
    stored_total += len(stored)
    require(raw_total <= 64 * 1024 * 1024, 'unexpected aggregate budget')
    if original.name in ('completion.json', 'stdout', 'stderr') and len(raw) < 20000:
        observations.append({'Original': str(original), 'Text': raw.decode('utf-8')})
sources = []
for row in manifest['SourceFiles']:
    path = root / row['Path']
    raw = path.read_bytes()
    require(len(raw) == row['Bytes'] and sha(raw) == row['Sha256'], 'current source mismatch ' + row['Path'])
    sources.append(row)
print(json.dumps({'Manifest': {'Bytes': len(raw_manifest), 'Sha256': sha(raw_manifest)},
                  'RecordCount': len(files), 'OriginalBytes': raw_total, 'StoredBytes': stored_total,
                  'AllStoredRawOriginalsMatched': True, 'SourceFiles': sources,
                  'Records': files, 'SmallRawObservations': observations}, indent=2))
