from pathlib import Path
import gzip,hashlib,json
root=Path.cwd()
out=root/'docs/research/mixed-message-peer-lifecycle-review/2026-09-08'
selected=[
('.git/epoch-peer-lifecycle-audit-1/audit.py','audit.py.gz'),
('.git/epoch-peer-lifecycle-audit-1/invocation.json','audit-invocation.json.gz'),
('.git/epoch-peer-lifecycle-audit-1/completion.json','audit-completion.json.gz'),
('.git/epoch-peer-lifecycle-audit-1/stdout','audit-stdout.json.gz'),
('.git/epoch-peer-lifecycle-audit-1/stderr','audit-stderr.gz'),
('.git/epoch-peer-lifecycle-review-source-1/MixedMessageEpochReplay.fsx','reviewed-source.fsx.gz'),
('.git/epoch-peer-lifecycle-review-source-1/identity.json','original-source-observation.json.gz'),
('.git/epoch-peer-lifecycle-review-source-1/immutable-pin.json','immutable-pin.json.gz'),
('.git/epoch-peer-lifecycle-review-source-1/owner-manifest.json','owner-manifest.json.gz'),
('.git/epoch-peer-lifecycle-review-source-1/diff-from-a59.txt','diff-from-a59.txt.gz'),
('.git/preserve-peer-lifecycle-review-1.py','preserve.py.gz'),
]
def sha(raw):return hashlib.sha256(raw).hexdigest().upper()
rows=[]
for original,name in selected:
 raw=(root/original).read_bytes(); stored=gzip.compress(raw,mtime=0)
 if gzip.decompress(stored)!=raw:raise ValueError('gzip reconstruction mismatch')
 (out/name).write_bytes(stored)
 rows.append({'File':name,'Original':str(root/original),'Bytes':len(raw),'Sha256':sha(raw),'StoredBytes':len(stored),'StoredSha256':sha(stored)})
for row in rows:
 raw=gzip.decompress((out/row['File']).read_bytes())
 if Path(row['Original']).read_bytes()!=raw:raise ValueError('original drift')
manifest={'ReviewedCommit':'d16bafa2a71e503878d645a8ea4f52244b5c227b','Reviewer':'Vera, OpenAI Codex using GPT-6 Astra','Scope':'independent source and retained-data audit; no peer/core/numerical execution','Records':rows}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'Records':len(rows),'OriginalBytes':sum(row['Bytes'] for row in rows),'StoredBytes':sum(row['StoredBytes'] for row in rows),'AllMatched':True}))
