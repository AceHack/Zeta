# Vera continuation: projection result into composable learning

Date: 2026-09-08 UTC
Author: Vera, OpenAI Codex using GPT-6 Astra
Operational status: research-grade continuity record
Lifecycle: active
Status: scalar component verified on main; bounded learning proposal reviewed

## Bootstrap

Continue in a writer-owned clone from current origin/main. Read the projection
[integration register](../research/2026-09-08-precision-gate-projection-integration-register.md)
and [registered result](../research/2026-09-08-precision-gate-projection-registered-results.md),
then the [mixed-message/learned-module epoch proposal](../research/2026-09-08-mixed-message-learned-module-epoch-proposal.md)
and its [independent review](../research/2026-09-08-mixed-message-epoch-independent-review.md). The candidate is a composable DAG
whose nodes may contain neural modules or nested DAGs. The next investment is
one bounded checked application/epoch adapter and an actual learned comparison;
scalar projection certificates are a prerequisite, not a system benchmark.

The user's [magnet transcript](../ip-questionable/2026-09-08-magnet-paradox-memory-history-transcript.md)
and [retained-history/generator interpretation](../research/2026-09-08-history-generators-and-hidden-evolution-under-repetition.md)
are on main through PR17045. The deliberate multi-oracle/default-disclosure
clarification is on main through PR17048; PR17050 preserves their main receipts
and the paused compiled investment. Do not turn those conceptual connections
into empirical support for physics, universal computation or learning scores.

## Current evidence

The sole registered scalar attempt completed all 88 calls across 40 IDs:
12 core certificates and 27 closed native children. All failures and controls
remain retained. In stress/cancellation, the native candidate is uncertified:
reference IterationLimit and certificate NoRootEnclosure. Twelve mutations of
the actual retained baseline were rejected. Independent review accepts the
finite numerical and direct-file scope, not transitive runtime closure or a
source-to-machine proof.

Its original manifest is
FE1F5BDF732FA6B08092887210552BA9CEF68D724E519C77958A282366A348E7,
frozen source f33ac42959388344fc3c82058f165764954fa22d and executed checkout
4937d7468. The complete original source/artifact and actual-run archives are
indexed by the integration register. Later publication hygiene changes only
Ruff first-party classification and seven test blank lines. Both lint working
directories now agree; the old manifest remains a historical source identity.
Do not regenerate or reassign the recorded attempt to a new source cut.

## Next bounded work

Reuse FactorGraph's existing other-factor exclusion and per-edge replacement,
checked Gaussian/Gamma kernels, and Core's finite scheduling. The proposal adds
explicit evidence/model/weight epochs, typed local-rule dispatch and atomic
application. Shared inputs, training data or expert errors are not independent
likelihood contributions just because producers have different DAG addresses.

A projected belief becomes a unary site by checked quotient against its exact
Gaussian base. The certificate covers the undamped proposal; a damped applied
belief needs its separate admission and does not inherit a minimizer claim.
Retain proposed, certified and applied states separately. An unavailable
certificate or exhausted block budget preserves the committed block-entry
state and actual earlier prefix. Training artifacts are immutable; a frozen
query never fits weights or observes a mixed child-version set.

Exit the adapter prerequisite after its eight essential control groups and
one real learned artifact consumed by a frozen nested query. Then preregister
one chronological learned comparison with individual, flat, shallow and deeper
compositions, compatible frozen module pools, strong feasible controls and
explicit training/inference budgets. To address the user's state-of-the-art
request, name a current primary published comparator and pinned executable
implementation, or report its concrete feasibility limitation. A comparison
only to a new small learner or internal flat controls is not a SOTA result. Include failed fits, abstentions and
refusals in denominators. Do not expand prerequisites or selection searches
until a favorable result appears. Compiled streams 9307/9409 remain unopened;
compiled-controller investment stays paused.

## Preserved wider direction

Keep the additive per-identity entropy floor and pairwise cross-consistency
multiplier distinct. Fabricated memories and cartels belong to the existing
adversarial model. Name a preserved memory invariant before Lorentz claims and
explicit maps/falsifiers before CQM, Clifford or WSet universality claims.
Noninterference/highest regard alone has not established a normalized CHSH map
or the 2-sqrt-2 bound. Irreducible resource types retain their units; funding
and scheduler priority do not become posterior probability or new evidence.

## Verified publication and next boundary

[Projection source/result PR17051](https://github.com/Lucent-Financial-Group/Zeta/pull/17051)
is on main at f59b6e395603062882dd1fe69fa8247406842e4d, from reviewed head
212758f124fbe7d42cf8073c7863fa99183c1d1a. The [main receipt](../research/research-main-publication/2026-09-08/pr-17051/README.md)
retains all 92 completed contexts (90 success, two skips), normal merge and
whole-tree/1,063-path proof. The shared main view was clean and refreshed.
The next proposal is separately
preserved at 9928404da6cf7ab1c5e2b251ae7afe73bbe2eda0 and accepted by independent
design review at 6f5c62198aaee8f758d726e0c4c514f3bab57b9a. It has not
implemented a new learning module or opened a dataset.

The design review adds one concrete reuse constraint: SoftScheduler.drive
returns an error without its local threaded state. The adapter must retain
EpochResult and the last committed prefix independently before that path, and
M4 must exercise the actual selected scheduler route. This is part of the
small adapter obligation, not a new framework or a convergence-proof project.
