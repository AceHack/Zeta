import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path.cwd()
out = root / '.git/epoch-bridge-portability-1' / sys.argv[1]
out.mkdir()
paths = ['src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py', 'src/Interp.Python/zeta_interp/mixed_message_epoch_controls.py', 'src/Interp.Python/tests/test_mixed_message_epoch_bridge.py']
pins = []
for rel in paths:
    raw = (root / rel).read_bytes()
    (out / Path(rel).name).write_bytes(raw)
    pins.append({'Path': rel, 'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest().upper()})
(out / 'sources.json').write_text(json.dumps(pins, indent=2) + '\n')
python = '/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906/src/Interp.Python/.venv/bin/python'
argv = [python, '-m', 'pytest', 'tests/test_mixed_message_epoch_bridge.py', '-q', '-p', 'no:cacheprovider', *sys.argv[2:]]
cwd = root / 'src/Interp.Python'
env = {'PYTHONPATH': str(cwd), 'PYTHONDONTWRITEBYTECODE': '1'}
(out / 'invocation.json').write_text(json.dumps({'Argv': argv, 'Cwd': str(cwd), 'EnvironmentOverrides': env, 'TempPolicy': 'pytest default; no basetemp override'}, indent=2) + '\n')
start = time.monotonic()
with (out / 'stdout').open('wb') as stdout, (out / 'stderr').open('wb') as stderr:
    observed = subprocess.run(argv, cwd=cwd, env=os.environ | env, stdout=stdout, stderr=stderr)
(out / 'completion.json').write_text(json.dumps({'ExitCode': observed.returncode, 'ElapsedSeconds': time.monotonic() - start}) + '\n')
print((out / 'stdout').read_text(), end='')
print((out / 'stderr').read_text(), end='', file=sys.stderr)
sys.exit(observed.returncode)
