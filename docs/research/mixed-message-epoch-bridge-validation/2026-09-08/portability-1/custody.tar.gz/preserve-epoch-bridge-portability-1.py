"""Preserve explicit test-portability source and observed validation files."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

root = Path.cwd()
base = root / 'docs/research/mixed-message-epoch-bridge-validation/2026-09-08/portability-1'
base.mkdir()
paths = []
for selected in ['.git/epoch-bridge-portability-1', '.git/epoch-bridge-portability-checks-1', '.git/epoch-bridge-portability-checks-2', '.git/epoch-bridge-repository-gate-5', '.git/epoch-bridge-build-retry-1']:
    paths.extend(sorted((root / selected).rglob('*')))
paths.extend(root / name for name in ['.git/run-epoch-portability-check.py', '.git/run-epoch-checks.py', '.git/run-epoch-repository-gate-5.py', '.git/retry-epoch-bridge-build-1.py', '.git/preserve-epoch-bridge-portability-1.py'])
paths = [path for path in paths if not path.is_dir()]
members = []
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as archive:
    for path in paths:
        st = path.lstat()
        if not stat.S_ISREG(st.st_mode):
            raise RuntimeError('nonregular retained original: ' + str(path))
        raw = path.read_bytes()
        name = str(path.relative_to(root / '.git'))
        entry = tarfile.TarInfo(name)
        entry.size = len(raw)
        entry.mode = 0o644
        archive.addfile(entry, io.BytesIO(raw))
        members.append(dict(Path=name, OriginalFile=str(path), Bytes=len(raw), Sha256=hashlib.sha256(raw).hexdigest().upper()))
stored = gzip.compress(buffer.getvalue(), mtime=0)
(base / 'custody.tar.gz').write_bytes(stored)
manifest = dict(Schema='zeta.mixed-epoch.bridge-portability-custody.v1', OriginalProductionCommit='567a9f004cf67b9df6d4a82c55fadaaf4fdd0b9b', OriginalOwnerHead='95d7dca78e771089237fec60eceba45482d1558c', Archive=dict(Path='custody.tar.gz', Bytes=len(stored), Sha256=hashlib.sha256(stored).hexdigest().upper()), OriginalBytes=sum(row['Bytes'] for row in members), Members=members)
(base / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(fileobj=io.BytesIO(stored), mode='r:gz') as archive:
    if [entry.name for entry in archive.getmembers()] != [row['Path'] for row in members]:
        raise RuntimeError('archive roster differs')
    for row in members:
        handle = archive.extractfile(row['Path'])
        if handle is None:
            raise RuntimeError('missing member')
        raw = handle.read()
        actual = Path(row['OriginalFile']).read_bytes()
        if raw != actual or len(raw) != row['Bytes'] or hashlib.sha256(raw).hexdigest().upper() != row['Sha256']:
            raise RuntimeError('archive/source identity differs')
print(json.dumps(dict(Members=len(members), OriginalBytes=manifest['OriginalBytes'], Archive=manifest['Archive']), indent=2))
