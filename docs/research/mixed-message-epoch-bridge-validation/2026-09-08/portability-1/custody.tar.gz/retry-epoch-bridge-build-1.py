"""One unchanged-source Release build after the retained compiler exit 139."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

root = Path.cwd()
out = root / '.git/epoch-bridge-build-retry-1'
out.mkdir()
paths = ['src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py', 'src/Interp.Python/zeta_interp/mixed_message_epoch_controls.py', 'src/Interp.Python/tests/test_mixed_message_epoch_bridge.py', 'src/Core/Core.fsproj']
before = {}
for name in paths:
    raw = (root / name).read_bytes()
    before[name] = raw
    (out / Path(name).name).write_bytes(raw)
argv = ['dotnet', 'build', 'Zeta.sln', '-c', 'Release']
(out / 'invocation.json').write_text(json.dumps(dict(Argv=argv, Cwd=str(root)), indent=2) + '\n')
start = time.monotonic()
with (out / 'stdout').open('xb') as stdout, (out / 'stderr').open('xb') as stderr:
    result = subprocess.run(argv, stdout=stdout, stderr=stderr)
(out / 'completion.json').write_text(json.dumps(dict(ExitCode=result.returncode, ElapsedSeconds=time.monotonic()-start)) + '\n')
pins = [dict(Path=name, Bytes=len(raw), Sha256=hashlib.sha256(raw).hexdigest().upper(), Unchanged=raw == (root/name).read_bytes()) for name, raw in before.items()]
(out / 'source-after.json').write_text(json.dumps(pins, indent=2) + '\n')
print((out / 'completion.json').read_text(), end='')
if any(not row['Unchanged'] for row in pins):
    raise RuntimeError('source changed during build retry')
raise SystemExit(result.returncode)
