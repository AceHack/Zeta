from pathlib import Path
import json, subprocess, sys, time
root=Path.cwd(); out=root/'.git/epoch-bridge-repository-gate-5'; out.mkdir()
for path in ('src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py','src/Interp.Python/zeta_interp/mixed_message_epoch_controls.py','src/Interp.Python/tests/test_mixed_message_epoch_bridge.py'):
    (out/Path(path).name).write_bytes((root/path).read_bytes())
commands=[['bun','run','preflight'],['dotnet','format','--verify-no-changes']]
results=[]
for index,argv in enumerate(commands):
    name=str(index+1)
    (out/(name+'-invocation.json')).write_text(json.dumps({'Argv':argv,'Cwd':str(root)})+'\n')
    start=time.monotonic()
    with (out/(name+'-stdout')).open('wb') as stdout,(out/(name+'-stderr')).open('wb') as stderr:
        completed=subprocess.run(argv,stdout=stdout,stderr=stderr)
    record={'ExitCode':completed.returncode,'ElapsedSeconds':time.monotonic()-start}
    (out/(name+'-completion.json')).write_text(json.dumps(record)+'\n'); results.append(record)
    print(name,record,flush=True)
sys.exit(int(any(row['ExitCode'] for row in results)))
