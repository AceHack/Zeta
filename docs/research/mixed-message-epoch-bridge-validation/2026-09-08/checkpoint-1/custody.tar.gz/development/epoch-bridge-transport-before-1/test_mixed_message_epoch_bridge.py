"""Protocol/retention development fixtures; never the registered M4/M5 routes."""

from __future__ import annotations

import hashlib
import json
import struct
from pathlib import Path
from typing import Any

import pytest

from zeta_interp import hidden_switch_compiled_record_store as records
from zeta_interp import mixed_message_epoch_bridge as bridge
from zeta_interp import precision_gate_projection_process as native
from zeta_interp import precision_gate_projection_reference as reference


def _ready() -> dict[str, object]:
    return {
        "Kind": "Ready", "Schema": bridge.SCHEMA, "SessionId": "fixture",
        "PlanSha256": "A" * 64, "ServiceSha256": "B" * 64,
    }


def _frame(value: object) -> bytes:
    return json.dumps(value, separators=(",", ":")).encode() + b"\n"


def _hex(value: float) -> str:
    return struct.pack(">d", value).hex().upper()


def _request() -> bridge.Frame:
    # This is a transport-only target. No real numerical service is called.
    raw = b'{"Schema":"zeta.precision-projection.input.v1","Id":"fixture/p","Parameters":{"T":"2","U":"0.5","K":"0","C":"2"},"Profile":"default"}'
    value = {
        "Kind": "ProjectionRequest", "Schema": bridge.SCHEMA, "SessionId": "fixture",
        "Sequence": 1, "RequestId": "fixture/p", "InputRevision": 0,
        "Base": {"PrecisionMean": _hex(1), "Precision": _hex(2)},
        "TargetBits": {"T": _hex(2), "U": _hex(0.5), "K": _hex(0), "C": _hex(2)},
        "RawInputHex": raw.hex(), "InputSha256": hashlib.sha256(raw).hexdigest().upper(),
        "CaseId": "fixture/p", "BindingsSha256": hashlib.sha256(b'{}').hexdigest().upper(),
        "Remaining": {},
    }
    result = bridge.decode_frame(_frame(value), "fixture")
    assert isinstance(result, bridge.Frame)
    return result


def _budget() -> bridge._Budget:
    return bridge._Budget(bridge.Reservation(1, 0, 0, records.Limits()), 0, lambda: 1)


def _store(parent: Path) -> records.Store:
    opened = records.open_store(parent, "records")
    assert isinstance(opened, records.Opened)
    return opened.Store


def _prepared() -> native.PreparedNative:
    return native.PreparedNative(True, "fixture", None, None, (), (), (), None, ())


def test_ready_retains_exact_original_bytes() -> None:
    raw = _frame(_ready())
    value = bridge.decode_frame(raw, "fixture")
    assert isinstance(value, bridge.Frame)
    assert value.Raw == raw
    assert value.Sha256 == hashlib.sha256(raw).hexdigest().upper()


@pytest.mark.parametrize("raw", [
    b'{}', b'{}\n{}\n', b'{"Kind":"Ready","Kind":"Ready"}\n',
    b'{"Kind":"Ready","n":1e400}\n', b'{"Kind":"Ready","n":NaN}\n',
    b'{"Kind":"Ready","n":1.0}\n', b'{"Kind":"Ready","n":9223372036854775808}\n',
    b'{"Kind":"Ready","n":"\\ud800"}\n', b'\xff\n',
])
def test_strict_frame_refuses_malformed_input(raw: bytes) -> None:
    assert isinstance(bridge.decode_frame(raw, "fixture"), bridge.Failure)


@pytest.mark.parametrize("change", [{"extra": None}, {"SessionId": "other"}, {"Schema": "other"}])
def test_exact_outer_keys_and_bindings(change: dict[str, object]) -> None:
    value = _ready() | change
    assert isinstance(bridge.decode_frame(_frame(value), "fixture"), bridge.Failure)


def test_boolean_sequence_is_not_one() -> None:
    value = _request().Value | {"Sequence": True}
    assert isinstance(bridge.decode_frame(_frame(value), "fixture"), bridge.Failure)


def test_canonical_keeps_array_order_unicode_and_signed_zero_bits() -> None:
    value = {"z": ["é", "\\", "\n"], "a": _hex(-0.0)}
    expected = b'{"a":"8000000000000000","z":["\xc3\xa9","\\\\","\\n"]}'
    assert bridge._canonical(value, len(expected)) == expected
    with pytest.raises(bridge._Stop):
        bridge._canonical(value, len(expected) - 1)


def test_source_reservation_is_not_refunded_or_reset() -> None:
    pins = {
        "@host": native.FileIdentity(100, "A" * 64),
        native.SCRIPT: native.FileIdentity(20, "B" * 64),
        "a.dll": native.FileIdentity(30, "C" * 64),
        "b.dll": native.FileIdentity(40, "D" * 64),
        "c.dll": native.FileIdentity(50, "E" * 64),
    }
    result = bridge._reservation(2, pins)
    assert result.ExternalBytes == 2 * (140 + 2 * (65536 + 65536 + 2097152))
    assert result.ExternalSlots == 10
    assert result.StoreLimits.CombinedBytes + result.ExternalBytes == 256 * 1024 * 1024
    assert result.StoreLimits.Artifacts + result.ExternalSlots == 4096
    zero = bridge._reservation(0, {})
    assert zero.ExternalBytes == zero.ExternalSlots == 0


def test_returned_refusal_is_retained_before_encoding(tmp_path: Path) -> None:
    actual = native.NativeObservation(Failure=native.ProcessFailure("fixture", "control", "returned"))
    called = []

    def launch(*args: object, **kwargs: object) -> object:
        called.append((args, kwargs))
        return actual

    def forbidden(*_: object, **__: object) -> object:
        raise AssertionError("incomplete native return must not enter certificate")

    budget = _budget()
    retained: list[bridge.ProjectionExchange] = []
    result = bridge._projection(_request(), _prepared(), {}, "B" * 64, tmp_path / "native", _store(tmp_path), budget, retained, bridge._Services(launch, forbidden))
    assert len(called) == 1
    assert budget.NativeCallEntered == budget.NativeReturned == 1
    assert budget.CertificateEntered == 0
    assert retained[0].Native is not None and retained[0].Native.Returned is actual
    assert result["Native"]["Type"].endswith("NativeObservation")
    assert result["Certificate"] is None and result["Failure"]["Code"] == "Service"


def test_raised_native_is_not_a_return_or_known_launch(tmp_path: Path) -> None:
    def launch(*_: object, **__: object) -> object:
        raise OSError("fixture")

    budget = _budget()
    retained: list[bridge.ProjectionExchange] = []
    bridge._projection(_request(), _prepared(), {}, "B" * 64, tmp_path / "native", _store(tmp_path), budget, retained, bridge._Services(launch, launch))
    assert budget.NativeCallEntered == 1 and budget.NativeReturned == 0
    assert "NativeLaunchAttempted" in budget.RemoteIncomplete
    assert retained[0].Native is not None and retained[0].Native.Raised is not None


def test_actual_certificate_failure_retains_native_and_nested_count(tmp_path: Path) -> None:
    actual_native = native.NativeObservation(Complete=True, Receipt=b"fixture", LaunchAttempted=True)
    actual_certificate = reference.ReceiptFailure(reference.Failure("ResultTooLarge", "output", None, "fixture"), {"Counters": {"ReferenceRootCalls": 1}})
    observed_args: list[object] = []

    def launch(*args: object, **kwargs: object) -> object:
        observed_args.append((args, kwargs))
        return actual_native

    def certify(*args: object, **kwargs: object) -> object:
        observed_args.append((args, kwargs))
        return actual_certificate

    budget = _budget()
    retained: list[bridge.ProjectionExchange] = []
    result = bridge._projection(_request(), _prepared(), {}, "B" * 64, tmp_path / "native", _store(tmp_path), budget, retained, bridge._Services(launch, certify))
    assert len(observed_args) == 2
    assert (budget.NativeCallEntered, budget.NativeReturned, budget.CertificateEntered, budget.CertificateReturned, budget.NestedReferenceEntered) == (1, 1, 1, 1, 1)
    assert retained[0].Certificate is not None and retained[0].Certificate.Returned is actual_certificate
    assert result["Certificate"] is None
    assert result["Failure"]["Code"] == "Storage"


def test_actual_normal_wrong_type_counts_as_return(tmp_path: Path) -> None:
    def launch(*_: object, **__: object) -> object:
        return {"not": "NativeObservation"}

    budget = _budget()
    retained: list[bridge.ProjectionExchange] = []
    result = bridge._projection(_request(), _prepared(), {}, "B" * 64, tmp_path / "native", _store(tmp_path), budget, retained, bridge._Services(launch, launch))
    assert budget.NativeCallEntered == budget.NativeReturned == 1
    assert retained[0].Native is not None and retained[0].Native.Returned == {"not": "NativeObservation"}
    assert result["Failure"]["Code"] == "Unexpected"


def test_budget_keeps_terminal_reserve_and_first_failure() -> None:
    budget = _budget()
    budget.ProtocolBytes = bridge.TRANSCRIPT_LIMIT - bridge.TERMINAL_RESERVE
    with pytest.raises(bridge._Stop):
        budget.charge_frame(1)
    budget.charge_frame(1, terminal=True)
    first = bridge.Failure("Storage", "publish", None, "first")
    budget.stop(first)
    budget.stop(bridge.Failure("Transport", "publish", None, "later"))
    assert budget.Failure is first


@pytest.mark.parametrize("name,bits", [("U", "8000000000000000"), ("T", _hex(4.0))])
def test_request_target_correspondence_precedes_native(name: str, bits: str) -> None:
    request = _request()
    value: dict[str, Any] = json.loads(request.Raw)
    value["TargetBits"][name] = bits
    parsed = bridge.decode_frame(_frame(value), "fixture")
    assert isinstance(parsed, bridge.Frame)
    with pytest.raises(bridge._Stop):
        bridge._request_input(parsed, {})


def test_transport_charges_unterminated_incoming_frame(tmp_path: Path) -> None:
    import sys
    import time

    budget = bridge._Budget(bridge.Reservation(0, 0, 0, records.Limits()), time.monotonic())
    peer = bridge._Peer((sys.executable, "-c", "import os; os.write(1,b'prefix')"), tmp_path, budget, 1)
    try:
        with pytest.raises(bridge._Stop):
            peer.receive()
        observed = peer.available()
        assert observed.PendingStdout == b"prefix"
        assert budget.Frames == 1
        assert budget.ProtocolBytes == 6
    finally:
        peer.close(normal=False)


def test_transport_failed_write_is_latched(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    import sys
    import time

    budget = bridge._Budget(bridge.Reservation(0, 0, 0, records.Limits()), time.monotonic())
    peer = bridge._Peer((sys.executable, "-c", "import sys; sys.stdin.buffer.read()"), tmp_path, budget, 1)
    calls = []

    def write(fd: int, raw: bytes) -> int:
        calls.append((fd, raw))
        if len(calls) == 1:
            return 1
        if len(calls) == 2:
            raise OSError("after one byte")
        return len(raw)

    monkeypatch.setattr(bridge.os, "write", write)
    monkeypatch.setattr(peer, "_poll_io", lambda **_: True)
    try:
        with pytest.raises(bridge._Stop):
            peer.send(b"first\n")
        with pytest.raises(bridge._Stop):
            peer.send(b"later\n")
        assert len(calls) == 2
        assert len(peer.available().Writes) == 1
        assert peer.available().Writes[0].WrittenBytes == 1
    finally:
        peer.close(normal=False)
