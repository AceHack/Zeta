def _required_failure(value: object) -> None:
    if value is None:
        _fail("Admission", "admit", "Failure", "Error requires a non-null actual failure")
    _failure_record(value)


def _exception(value: object) -> None:
    row = _keys(value, {"Type", "Message"}, "Exception")
    for name, cap in (("Type", 256), ("Message", 1024)):
        if type(row[name]) is not str or len(row[name].encode("utf-8")) > cap:
            _fail("Admission", "admit", name, "bounded actual exception string required")


def _value_result(value: object, ok: Callable[[Any], None], error: Callable[[Any], None] = _required_failure) -> None:
    if type(value) is not dict:
        _fail("Admission", "admit", "Result", "closed result union required")
    if value.get("Kind") == "Ok":
        row = _keys(value, {"Kind", "Value"}, "Ok")
        ok(row["Value"])
    elif value.get("Kind") == "Error":
        row = _keys(value, {"Kind", "Failure"}, "Error")
        error(row["Failure"])
    else:
        _fail("Admission", "admit", "Result.Kind", "unknown result variant")


def _unit(value: object) -> None:
    if value is not None:
        _fail("Admission", "admit", "Value", "unit return must be null")


def _call_value(value: object, returned: Callable[[Any], None]) -> Tree:
    if type(value) is not dict:
        _fail("Admission", "admit", "Call", "actual call observation required")
    if value.get("Kind") == "NotEntered":
        return _keys(value, {"Kind"}, "Call")
    if value.get("Kind") == "Raised":
        row = _keys(value, {"Kind", "Exception"}, "Call")
        _exception(row["Exception"])
        return row
    row = _keys(value, {"Kind", "Result"}, "Call")
    if row["Kind"] != "Returned":
        _fail("Admission", "admit", "Call.Kind", "unknown call variant")
    returned(row["Result"])
    return row


def _bit_vector(value: object, name: str, size: int, *, complete: bool = False) -> None:
    for entry in _array(value, name, size, minimum=size if complete else 0):
        _bits(entry, name)


def _preprocessing(value: object) -> None:
    row = _keys(value, {"TrainingCut", "Count", "Means", "Scales"}, "Preprocessing")
    _hash(row["TrainingCut"], "TrainingCut")
    _integer(row["Count"], "Count", 1, 256)
    _bit_vector(row["Means"], "Means", 8, complete=True)
    _bit_vector(row["Scales"], "Scales", 8, complete=True)
    if any(_bits(entry, "Scale") <= 0 for entry in row["Scales"]):
        _fail("Improper", "admit", "Scales", "proper preprocessing scales required")


def _proposal(value: object) -> None:
    if value is None:
        return
    row = _keys(value, {"ExpectedRevision", "ExpectedStateSha256", "State", "Details"}, "Proposal")
    revision = _integer(row["ExpectedRevision"], "ExpectedRevision", 0, 4096)
    _hash(row["ExpectedStateSha256"], "ExpectedStateSha256")
    if _state(row["State"])["Revision"] != revision + 1:
        _fail("Conflict", "admit", "Proposal", "one next revision required")


def _kernel_error(value: object) -> None:
    if type(value) is not dict:
        _fail("Admission", "admit", "KernelError", "closed kernel error required")
    variants = {"InvalidInput": {"Kind", "Field", "Requirement"}, "NumericalFailure": {"Kind", "Operation", "Reason"}, "ImproperBelief": {"Kind", "Family"}}
    kind = value.get("Kind")
    if type(kind) is not str or kind not in variants:
        _fail("Admission", "admit", "KernelError", "unknown kernel error")
    for name, item in _keys(value, variants[kind], "KernelError").items():
        if type(item) is not str or len(item.encode("utf-8")) > 1024:
            _fail("Budget", "admit", name, "bounded kernel error string required")


def _kernel_value(value: object, operation: str) -> None:
    keys = {
        "tryEncodeGamma": {"RequestedShape", "RepresentedShape", "Kernel"},
        "tryGammaProduct": {"LogPower", "Rate"},
        "tryGammaMoments": {"RepresentedShape", "Rate", "Mean", "Variance"},
        "tryGaussianProduct": {"PrecisionMean", "Precision"},
        "tryGaussianQuotient": {"PrecisionMean", "Precision"},
        "tryGaussianMoments": {"Mean", "Variance"},
        "tryNormalPrecisionVmp": {"ResidualSecondMoment", "ToY", "ToMean", "ToPrecision"},
    }
    row = _keys(value, keys[operation], operation)
    for name, item in row.items():
        if name in ("Kernel", "ToPrecision"):
            _kernel_value(item, "tryGammaProduct")
        elif name in ("ToY", "ToMean"):
            _kernel_value(item, "tryGaussianProduct")
        else:
            _bits(item, name)


def _snapshot_value(value: object) -> None:
    row = _keys(value, {"SnapshotIndex", "CompletedSessions", "PriorWork", "Store", "TranscriptBytes", "TranscriptFrames", "PeerLaunchAttempted", "NativePreparationEntered", "RemainingMilliseconds"}, "BudgetSnapshot")
    for name, cap in (("SnapshotIndex", FRAME_LIMIT), ("CompletedSessions", 4), ("TranscriptBytes", TRANSCRIPT_LIMIT), ("TranscriptFrames", FRAME_LIMIT), ("PeerLaunchAttempted", 4), ("NativePreparationEntered", 1), ("RemainingMilliseconds", 300000)):
        _integer(row[name], name, 0, cap)
    work = _keys(row["PriorWork"], {"SchedulerEntered", "KernelEntered", "ForwardEntered", "LearnEntered", "ProjectionRequested", "NativeLaunchAttempted", "CertificateEntered", "NestedReferenceEntered", "TrainingArtifacts"}, "PriorWork")
    caps = {"SchedulerEntered": 4096, "KernelEntered": 256, "ForwardEntered": 4096, "LearnEntered": 2048, "ProjectionRequested": 32, "NativeLaunchAttempted": 32, "CertificateEntered": 32, "NestedReferenceEntered": 32, "TrainingArtifacts": 4}
    for name, item in work.items():
        _integer(item, name, 0, caps[name])
    store = _keys(row["Store"], {"ReservedCombinedBytes", "ReservedArtifactSlots"}, "Store")
    _integer(store["ReservedCombinedBytes"], "ReservedCombinedBytes", 0, RETENTION_LIMIT)
    _integer(store["ReservedArtifactSlots"], "ReservedArtifactSlots", 0, ARTIFACT_LIMIT)


def _projection_return(value: object) -> None:
    row = _keys(value, {"Sequence", "RequestId", "InputSha256", "BindingsSha256", "ServiceSha256", "Native", "Certificate", "Failure", "BudgetSnapshot"}, "ProjectionResponse")
    _integer(row["Sequence"], "Sequence", 1, FRAME_LIMIT)
    _id(row["RequestId"], "RequestId")
    for name in ("InputSha256", "BindingsSha256", "ServiceSha256"):
        _hash(row[name], name)
    _failure_record(row["Failure"])
    _snapshot_value(row["BudgetSnapshot"])
    # The original complete passive trees are compared to actual coordinator
    # responses separately; no Type label is dispatched or reconstructed here.


def _transport_failure(value: object) -> None:
    row = _keys(value, {"Failure", "Received", "RawSha256", "ReceivedBytes", "Exception"}, "TransportFailure")
    _required_failure(row["Failure"])
    if row["RawSha256"] is not None:
        _hash(row["RawSha256"], "RawSha256")
    _integer(row["ReceivedBytes"], "ReceivedBytes", 0, 16 * MIB)
    if row["Exception"] is not None:
        _exception(row["Exception"])


def _source_result(value: object, kind: str) -> None:
    result = _keys(value, {"Type", "Fields"}, "Call.Result")
    namespace = "Zeta.Bayesian.MixedMessageEpoch+" if kind == "BlockAttempt" else "Zeta.Bayesian.BoundedModuleLearner+"
    if result["Type"] != namespace + kind:
        _fail("Admission", "admit", "Call.Result.Type", "source-fixed return type required")
    shapes = {
        "ForwardAttempt": {"Input", "Preactivations", "Hidden", "Outcome"},
        "StepAttempt": {"Input", "Forward", "Loss", "Gradient", "ProposedParameters", "Outcome"},
        "PreprocessingAttempt": {"TrainingCut", "Rows", "Means", "Variances", "Scales", "Outcome"},
        "TransformAttempt": {"Preprocessing", "Row", "Values", "Outcome"},
        "BlockAttempt": {"Inputs", "Calls", "Proposal", "Outcome"},
    }
    fields = _keys(result["Fields"], shapes[kind], kind)
    if kind in ("ForwardAttempt", "StepAttempt"):
        if fields["Input"] is not None:
            source_input = _keys(fields["Input"], {"Parameters", "Inputs"} | ({"Target"} if kind == "StepAttempt" else set()), "Input")
            _bit_vector(source_input["Parameters"], "Parameters", 57, complete=True)
            _bit_vector(source_input["Inputs"], "Inputs", 12, complete=True)
            if kind == "StepAttempt":
                _bits(source_input["Target"], "Target")
        if kind == "ForwardAttempt":
            _bit_vector(fields["Preactivations"], "Preactivations", 4)
            _bit_vector(fields["Hidden"], "Hidden", 4)
            _value_result(fields["Outcome"], lambda item: _bits_void(item, "Prediction"))
        else:
            if fields["Forward"] is not None:
                _source_result(fields["Forward"], "ForwardAttempt")
            if fields["Loss"] is not None:
                _bits(fields["Loss"], "Loss")
            for name in ("Gradient", "ProposedParameters"):
                _bit_vector(fields[name], name, 57)
            _value_result(fields["Outcome"], _unit)
    elif kind == "PreprocessingAttempt":
        _hash(fields["TrainingCut"], "TrainingCut")
        for row in _array(fields["Rows"], "Rows", 256):
            _bit_vector(row, "Row", 8, complete=True)
        for name in ("Means", "Variances", "Scales"):
            _bit_vector(fields[name], name, 8)
        _value_result(fields["Outcome"], _preprocessing)
    elif kind == "TransformAttempt":
        _preprocessing(fields["Preprocessing"])
        _bit_vector(fields["Row"], "Row", 8, complete=True)
        _bit_vector(fields["Values"], "Values", 8)
        _value_result(fields["Outcome"], _unit)
    else:
        for item in _array(fields["Calls"], "Calls", 256):
            call = _keys(item, {"Operation", "Inputs", "Call"}, "Block.Call")
            operation = call["Operation"]
            if operation == "ProjectionService":
                _call_value(call["Call"], lambda returned: _value_result(returned, _projection_return, _transport_failure))
            elif operation in ("tryEncodeGamma", "tryGammaProduct", "tryGammaMoments", "tryGaussianProduct", "tryGaussianQuotient", "tryGaussianMoments", "tryNormalPrecisionVmp"):
                _call_value(call["Call"], lambda returned: _value_result(returned, partial(_kernel_value, operation=operation), _kernel_error))
            else:
                _fail("Admission", "admit", "Block.Operation", "unknown fixed kernel/service operation")
        _proposal(fields["Proposal"])
        _value_result(fields["Outcome"], _unit)


def _bits_void(value: object, name: str) -> None:
    _bits(value, name)


def _call(value: object, operation: str) -> Tree:
    kinds = {"LearnStep": "StepAttempt", "NeuralForward": "ForwardAttempt", "GammaBlock": "BlockAttempt", "GaussianBlock": "BlockAttempt", "Compensate": "BlockAttempt"}
    if operation not in kinds:
        _fail("Admission", "admit", "Operation", "unknown fixed operation")
    return _call_value(value, partial(_source_result, kind=kinds[operation]))


def _scheduler(value: object) -> None:
    def feedback(error: object) -> None:
        if type(error) is not dict:
            _fail("Admission", "admit", "Scheduler.Failure", "actual feedback required")
        kind = error.get("Kind")
        field_name = "Message" if kind == "Failed" else "Interrupt"
        if kind not in ("Failed", "Interrupted"):
            _fail("Admission", "admit", "Scheduler.Failure", "unknown feedback variant")
        row = _keys(error, {"Kind", field_name}, "Scheduler.Failure")
        if type(row[field_name]) is not str or len(row[field_name].encode("utf-8")) > 1024:
            _fail("Budget", "admit", "Scheduler.Failure", "bounded actual feedback string required")
    if type(value) is not dict or value.get("Kind") == "NotEntered":
        _fail("Admission", "admit", "Scheduler", "actual scheduler return or raise required")
    _call_value(value, lambda returned: _value_result(returned, lambda index: _integer_void(index, "Scheduler.Index", 0, 4096), feedback))


def _integer_void(value: object, name: str, low: int, high: int) -> None:
    _integer(value, name, low, high)


def _recorder_value(value: object, kind: str) -> None:
    def stored(item: object) -> None:
        row = _keys(item, {"Sequence", "CheckpointSha256", "Artifact", "BudgetSnapshot"}, "StoredCheckpoint")
        _integer(row["Sequence"], "Sequence", 1, FRAME_LIMIT)
        _hash(row["CheckpointSha256"], "CheckpointSha256")
        _descriptor(row["Artifact"])
        _snapshot_value(row["BudgetSnapshot"])
    _value_result(value, stored if kind == "Checkpoint" else _unit if kind == "Commit" else _snapshot_value)


def _core_publication(value: object) -> Tree:
    row = _keys(value, {"Recorder", "Unpublished", "Failure", "BudgetSnapshot"}, "CorePublication")
    for item in _array(row["Recorder"], "Recorder", FRAME_LIMIT):
        call = _keys(item, {"Kind", "Sequence", "Call"}, "Recorder.Call")
        if call["Kind"] not in ("Checkpoint", "Commit", "Snapshot"):
            _fail("Admission", "admit", "Recorder.Kind", "unknown recorder callback")
        if call["Kind"] == "Snapshot":
            _unit(call["Sequence"])
        else:
            _integer(call["Sequence"], "Sequence", 1, FRAME_LIMIT)
        _call_value(call["Call"], partial(_recorder_value, kind=call["Kind"]))
    for sequence in _array(row["Unpublished"], "Unpublished", 4096):
        _integer(sequence, "Unpublished.Sequence", 1, FRAME_LIMIT)
    _failure_record(row["Failure"])
    _snapshot_value(row["BudgetSnapshot"])
    return row
