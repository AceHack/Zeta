from pathlib import Path
p=Path('src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py'); s=p.read_text()
s=s.replace('from dataclasses import dataclass, field, replace','from copy import deepcopy\nfrom dataclasses import dataclass, field, replace')
s=s.replace('''        budget.NativeLaunchAttempted += int(actual.LaunchAttempted)
        native_tree''','''        budget.NativeLaunchAttempted += int(actual.LaunchAttempted)
        if actual.Complete is not True or type(actual.Receipt) is not bytes:
            failure = Failure("Service", "project", "Native", "native process did not return a complete admitted receipt")
        native_tree''')
s=s.replace('''        budget.check()
        if actual.Complete is not True or type(actual.Receipt) is not bytes:
            _fail(
                "Service",
                "project",
                "Native",
                "native process did not return a complete admitted receipt",
            )''','''        if failure is not None:
            raise _Stop(failure)
        budget.check()''')
s=s.replace('''        published_certificate = _retained_public(''','''        if type(certificate) is reference.ReceiptFailure:
            failure = Failure("Storage", "publish", "Certificate", "actual ReceiptFailure retained; no encoded certificate claimed")
        published_certificate = _retained_public(''')
s=s.replace('''    except _Stop as error:
        failure = error.failure
    except Exception as error:  # noqa: BLE001 - retain actual service returns on later boundary failure.
        failure = Failure("Unexpected", "project", None, type(error).__name__)''','''    except _Stop as error:
        failure = failure or error.failure
    except Exception as error:  # noqa: BLE001 - retain actual service returns on later boundary failure.
        failure = failure or Failure("Unexpected", "project", None, type(error).__name__)''')
s=s.replace('''        self.Sessions: list[SessionResult] = []''','''        self.Sessions: list[SessionResult] = []
        self.SessionSummaries: list[tuple[SessionResult, Tree]] = []''')
s=s.replace('''        _bridge_failure(handle, error.failure)
    except Exception as error:  # noqa: BLE001 - retain actual route prefix and all callbacks.''','''        _bridge_failure(handle, session.Failure)
        if session.Failure != error.failure:
            handle.SecondaryFailures.append(error.failure)
    except Exception as error:  # noqa: BLE001 - retain actual route prefix and all callbacks.''')
s=s.replace('''        _bridge_failure(handle, failure)
    finally:
        handle.Running = False''','''        _bridge_failure(handle, session.Failure)
        if session.Failure != failure:
            handle.SecondaryFailures.append(failure)
    finally:
        handle.Running = False''')
s=s.replace('''    if session.ForecastEligible:
        _SESSION_SEALS[session] = _session_seal(session)
    return session


def _outer_counts''','''    try:
        if session.Closed:
            _SESSION_SEALS[session] = _session_seal(session)
    except _Stop as error:
        session.Failure = session.Failure or error.failure
        session.Closed = session.ForecastEligible = False
        _bridge_failure(handle, session.Failure)
    except Exception as error:  # noqa: BLE001 - actual committed prefix precedes closure encoding.
        failure = Failure("Unexpected", "publish", "SessionSeal", type(error).__name__)
        session.Failure = session.Failure or failure
        session.Closed = session.ForecastEligible = False
        _bridge_failure(handle, session.Failure)
    try:
        # Private copy is captured before exposing this mutable public DTO.
        handle.SessionSummaries.append((session, deepcopy(_session_summary(session))))
    except Exception as error:  # noqa: BLE001 - retain actual result even if private summary fails.
        session.Closed = session.ForecastEligible = False
        session.Failure = session.Failure or Failure("Unexpected", "publish", "SessionSummary", type(error).__name__)
        _bridge_failure(handle, session.Failure)
    return session


def _session_summary(session: SessionResult) -> Tree:
    return {
        "SessionId": session.SessionId,
        "PlanSha256": None if session.Plan is None else session.Plan.Sha256,
        "Closed": session.Closed,
        "ForecastEligible": session.ForecastEligible,
        "Failure": _failure_tree(session.Failure),
        "EpochReturn": None if session.EpochReturnArtifact is None else session.EpochReturnArtifact.descriptor(),
        "TerminalSha256": None if session.Terminal is None else session.Terminal.Sha256,
        "LastObservedCommitted": session.LastObservedCommitted,
    }


def _outer_counts''')
a=s.index('    if handle.Store is not None and handle.Budget is not None:\n        terminal = {',s.index('def _finish_bridge'))
b=s.index('        finalized = _observe(',a)
s=s[:a]+'''    counts_call = _observe("outer-counts", lambda: _outer_counts(handle), handle.Calls)
    counts = counts_call.Returned if counts_call.Raised is None and type(counts_call.Returned) is dict else {"Available": False}
    if counts_call.Raised is not None:
        _bridge_failure(handle, Failure("Unexpected", "publish", "Counters", counts_call.Raised.Type))
    summaries: list[Tree] = []
    for session, original in handle.SessionSummaries:
        summaries.append(deepcopy(original))
        try:
            if _session_summary(session) != original:
                _fail("Conflict", "publish", "Session", "public session changed after actual return; original summary retained")
            if original["Closed"]:
                _check_session_seal(session)
        except _Stop as error:
            _bridge_failure(handle, error.failure)
        except Exception as error:  # noqa: BLE001 - DTO drift cannot prevent finalization.
            _bridge_failure(handle, Failure("Unexpected", "publish", "Session", type(error).__name__))
    if len(summaries) != len(handle.Sessions):
        _bridge_failure(handle, Failure("Storage", "publish", "SessionSummary", "actual session summary prefix is incomplete"))
    if handle.Store is not None and handle.Budget is not None:
        try:
            terminal = {
                "Schema": "zeta.mixed-epoch.bridge-result.v1",
                "ServiceSha256": None if handle.Manifest is None else handle.Manifest.Sha256,
                "Route": handle.Route,
                "Failure": _failure_tree(handle.Failure),
                "Sessions": summaries,
                "Counters": counts,
                "FullActualReturnRetention": "memory; records referenced without duplicate Store snapshots",
            }
            raw = _canonical(terminal, MIB, newline=True)
            call = _observe(
                "append_bytes/outer-terminal",
                lambda: records.append_bytes(handle.Store, "outer-terminal", raw),
                handle.Calls,
            )
            if call.Raised is not None or type(call.Returned) is not records.Stored:
                _fail("Storage", "publish", "OuterTerminal", "actual once-only outer terminal publication refused")
            handle.FinalRecord = call.Returned.Artifact
        except _Stop as error:
            _bridge_failure(handle, error.failure)
        except Exception as error:  # noqa: BLE001 - final publication cannot erase the earlier actual prefix.
            _bridge_failure(handle, Failure("Unexpected", "publish", "OuterTerminal", type(error).__name__))
''' +s[b:]
s=s.replace('''        _outer_counts(handle),
        handle.Failure is None and all(session.Closed for session in handle.Sessions),''','''        counts,
        handle.Failure is None and all(row["Closed"] for row in summaries),''')
p.write_text(s)
p=Path('src/Interp.Python/tests/test_mixed_message_epoch_bridge.py');s=p.read_text().replace('from pathlib import Path','from dataclasses import replace\nfrom pathlib import Path').replace('bridge.replace(', 'replace(')
p.write_text(s)
