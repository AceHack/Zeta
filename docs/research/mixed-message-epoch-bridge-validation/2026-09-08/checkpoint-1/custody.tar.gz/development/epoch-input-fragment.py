def _operation_inputs(value: object, operation: Tree, plan: AdmittedPlan) -> None:
    kind = operation['Kind']
    if kind == 'LearnStep':
        row = _keys(value, {'Kind', 'ArtifactId', 'Pass', 'RowId', 'Row', 'OldVector', 'Inputs', 'Target', 'ArtifactEntry', 'Transform'}, 'LearnStep.Inputs')
        for name in ('Kind', 'ArtifactId', 'Pass', 'RowId'):
            if type(row[name]) is not type(operation[name]) or row[name] != operation[name]:
                _fail('Conflict', 'admit', name, 'actual learner inputs differ from fixed operation')
        evidence = next(item for item in plan.Value['EvidenceCut']['Rows'] if item['Id'] == operation['RowId'])
        if row['Row'] != evidence or row['Target'] != evidence['Target']:
            _fail('Conflict', 'admit', 'Row', 'actual learner row/target differs from admitted original')
        _bit_vector(row['OldVector'], 'OldVector', 57)
        _bit_vector(row['Inputs'], 'Inputs', 12)
        if row['ArtifactEntry'] is not None:
            entry = _keys(row['ArtifactEntry'], {'Request', 'Preprocessing'}, 'ArtifactEntry')
            expected = next(item for item in plan.Value['Training']['Artifacts'] if item['Id'] == operation['ArtifactId'])
            if entry['Request'] != expected:
                _fail('Conflict', 'admit', 'ArtifactEntry.Request', 'actual first artifact request differs')
            _call_value(entry['Preprocessing'], partial(_source_result, kind='PreprocessingAttempt'))
        _call_value(row['Transform'], partial(_source_result, kind='TransformAttempt'))
    elif kind == 'NeuralForward':
        row = _keys(value, {'Kind', 'NodeId', 'RowId', 'ArtifactVersion', 'Transform', 'Inputs'}, 'NeuralForward.Inputs')
        node = next(item for item in plan.Value['Nodes'] if item['Id'] == operation['NodeId'])
        if row['Kind'] != kind or row['NodeId'] != node['Id'] or row['RowId'] != plan.Value['QueryRowId'] or row['ArtifactVersion'] != plan.Value['SelectedVersions'][node['Artifact']]['Version']:
            _fail('Conflict', 'admit', 'NeuralForward.Inputs', 'actual selected query/model inputs differ')
        _bit_vector(row['Inputs'], 'Inputs', 12)
        _call_value(row['Transform'], partial(_source_result, kind='TransformAttempt'))
    elif type(value) is not dict:
        _fail('Admission', 'admit', 'Block.Inputs', 'source block input record required')
    # Block's numeric input/detail payload remains a retained finite JSON value;
    # the closed source codec and actual complete call associations supply its
    # provenance. This validator does not recompute arithmetic or infer execution.


def _return_call_links(result: Tree, session: SessionResult) -> None:
    snapshots: dict[int, Tree] = {}
    acknowledgments: dict[int, Tree] = {}
    for raw in session.Outgoing:
        frame = _json(raw, 16 * MIB)
        if 'BudgetSnapshot' in frame:
            snap = frame['BudgetSnapshot']
            snapshots[snap['SnapshotIndex']] = snap
        if frame['Kind'] == 'CheckpointAck':
            acknowledgments[frame['Sequence']] = frame
    def actual_snapshot(snapshot: Tree) -> None:
        if snapshots.get(snapshot['SnapshotIndex']) != snapshot:
            _fail('Conflict', 'publish', 'BudgetSnapshot', 'returned snapshot differs from an actual outgoing coordinator observation')
    actual_snapshot(result['Publication']['BudgetSnapshot'])
    for recorder in result['Publication']['Recorder']:
        call = recorder['Call']
        if call['Kind'] != 'Returned' or call['Result']['Kind'] != 'Ok':
            continue
        value = call['Result']['Value']
        if recorder['Kind'] == 'Snapshot':
            actual_snapshot(value)
        elif recorder['Kind'] == 'Checkpoint':
            ack = acknowledgments.get(recorder['Sequence'])
            if ack is None or ack['Outcome']['Kind'] != 'stored' or value != {'Sequence': ack['Sequence'], 'CheckpointSha256': ack['CheckpointSha256'], 'Artifact': ack['Outcome']['Artifact'], 'BudgetSnapshot': ack['BudgetSnapshot']}:
                _fail('Conflict', 'publish', 'Recorder.Checkpoint', 'returned stored checkpoint differs from the actual complete ACK')
        elif not any(frame.Value['Sequence'] == recorder['Sequence'] for frame in session.Commits):
            _fail('Conflict', 'publish', 'Recorder.Commit', 'successful callback lacks an actual received Commit')
    responses = {item.Request.Value['Sequence']: {name: value for name, value in item.Response.items() if name not in _HEADER} for item in session.Projections if item.Response is not None}
    used: set[int] = set()
    entered_artifacts: set[str] = set()
    for observation in result['Observations']:
        kind = observation['Operation']['Kind']
        if kind == 'LearnStep' and observation['Inputs']['ArtifactEntry'] is not None:
            identity = observation['Operation']['ArtifactId']
            if identity in entered_artifacts:
                _fail('Conflict', 'publish', 'ArtifactEntry', 'actual artifact entry cannot repeat')
            entered_artifacts.add(identity)
        call = observation['Call']
        if kind != 'GaussianBlock' or call['Kind'] != 'Returned':
            continue
        for primitive in call['Result']['Fields']['Calls']:
            returned = primitive['Call']
            if primitive['Operation'] != 'ProjectionService' or returned['Kind'] != 'Returned' or returned['Result']['Kind'] != 'Ok':
                continue
            value = returned['Result']['Value']
            sequence = value['Sequence']
            if sequence in used or responses.get(sequence) != value:
                _fail('Conflict', 'publish', 'ProjectionService', 'returned service payload differs from actual coordinator response')
            used.add(sequence)
    if result['Outcome'] == 'completed' and used != set(responses):
        _fail('Conflict', 'publish', 'ProjectionService', 'completed return omitted an actual service response')


