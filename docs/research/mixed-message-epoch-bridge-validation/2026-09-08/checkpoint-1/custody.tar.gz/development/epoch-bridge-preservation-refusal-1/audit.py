from pathlib import Path
import hashlib,json,sys
p=Path('docs/research/mixed-message-epoch-bridge-validation/2026-09-08/checkpoint-1/manifest.json')
manifest=json.loads(p.read_bytes()); failed=[]
for row in manifest['Records']:
 if row['OriginalLocalFile'] is not None:
  raw=Path(row['OriginalLocalFile']).read_bytes()
  if len(raw)!=row['Bytes'] or hashlib.sha256(raw).hexdigest().upper()!=row['Sha256']:
   failed.append({'Name':row['Name'],'ExpectedBytes':row['Bytes'],'ActualBytes':len(raw)})
print(json.dumps({'OriginalMismatches':failed}))
sys.exit(int(bool(failed)))
