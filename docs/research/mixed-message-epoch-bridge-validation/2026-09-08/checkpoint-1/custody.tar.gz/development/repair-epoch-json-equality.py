from pathlib import Path
p=Path('src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py')
s=p.read_text()
marker='def _canonical(value: object, cap: int, *, newline: bool = False) -> bytes:\n'
helper='''def _same(left: object, right: object) -> bool:
    """Bounded structural equality that preserves JSON primitive types."""
    pending = [(left, right, 0)]
    nodes = 0
    while pending:
        actual, expected, depth = pending.pop()
        nodes += 1
        if nodes > 100_000 or depth > 128 or type(actual) is not type(expected):
            return False
        if actual is None:
            continue
        if type(actual) in (bool, int, str):
            if actual != expected:
                return False
        elif isinstance(actual, dict):
            other = cast(dict[str, object], expected)
            if (
                any(type(key) is not str for key in actual)
                or any(type(key) is not str for key in other)
                or actual.keys() != other.keys()
                or len(actual) > 100_000 - nodes
            ):
                return False
            pending.extend((value, other[key], depth + 1) for key, value in actual.items())
        elif isinstance(actual, (list, tuple)):
            sequence = cast(list[object] | tuple[object, ...], expected)
            if len(actual) != len(sequence) or len(actual) > 100_000 - nodes:
                return False
            pending.extend((a, b, depth + 1) for a, b in zip(actual, sequence, strict=True))
        else:
            return False
    return True


'''
assert marker in s
s=s.replace(marker,helper+marker,1)
pairs=[
('rechecked.Value != request.Value','not _same(rechecked.Value, request.Value)'),
('prior["LastCommitted"] != state','not _same(prior["LastCommitted"], state)'),
('plan["Operations"] != expected','not _same(plan["Operations"], expected)'),
('row["Row"] != evidence','not _same(row["Row"], evidence)'),
('entry["Request"] != expected','not _same(entry["Request"], expected)'),
('snapshots.get(snapshot["SnapshotIndex"]) != snapshot','not _same(snapshots.get(snapshot["SnapshotIndex"]), snapshot)'),
('responses.get(sequence) != value','not _same(responses.get(sequence), value)'),
('row["Operation"] != plan.Operations[index]','not _same(row["Operation"], plan.Operations[index])'),
('transport["Coordinator"] != budget.LastSnapshot','not _same(transport["Coordinator"], budget.LastSnapshot)'),
('reference_row != expected','not _same(reference_row, expected)'),
('row[name] != result[name]','not _same(row[name], result[name])'),
('_state(row["LastCommitted"]) != session.LastObservedCommitted','not _same(_state(row["LastCommitted"]), session.LastObservedCommitted)'),
('checked[name] != checkpoint[name]','not _same(checked[name], checkpoint[name])'),
('_json(expected.Raw, MIB) != plan.Value','not _same(_json(expected.Raw, MIB), plan.Value)'),
('state != proposal["State"]','not _same(state, proposal["State"])'),
('bundle["Plan"] != origin.Plan.Value','not _same(bundle["Plan"], origin.Plan.Value)'),
('bundle["Result"] != origin.EpochReturn.Value["Result"]','not _same(bundle["Result"], origin.EpochReturn.Value["Result"])'),
('bundle["ProducerModels"] != models','not _same(bundle["ProducerModels"], models)'),
('bundle["Ancestry"] != ancestry','not _same(bundle["Ancestry"], ancestry)'),
('bundles[actual_sha][0] != bundle','not _same(bundles[actual_sha][0], bundle)'),
('query_row[key] != training_row[key]','not _same(query_row[key], training_row[key])'),
('plan.Value != handle.FirstPlan.Value','not _same(plan.Value, handle.FirstPlan.Value)'),
('entry["Request"] != expected_request','not _same(entry["Request"], expected_request)'),
('_session_summary(session) != original','not _same(_session_summary(session), original)'),
('plan.Value != session.Plan.Value','not _same(plan.Value, session.Plan.Value)'),
('plan.Operations != session.Plan.Operations','not _same(plan.Operations, session.Plan.Operations)'),
('current.Value != frame.Value','not _same(current.Value, frame.Value)'),
]
for old,new in sorted(pairs, key=lambda pair: -len(pair[0])):
    assert old in s,old
    s=s.replace(old,new)
old='''or value
                != {
                    "Sequence": ack["Sequence"],
                    "CheckpointSha256": ack["CheckpointSha256"],
                    "Artifact": ack["Outcome"]["Artifact"],
                    "BudgetSnapshot": ack["BudgetSnapshot"],
                }'''
new='''or not _same(value, {
                    "Sequence": ack["Sequence"],
                    "CheckpointSha256": ack["CheckpointSha256"],
                    "Artifact": ack["Outcome"]["Artifact"],
                    "BudgetSnapshot": ack["BudgetSnapshot"],
                })'''
assert old in s
s=s.replace(old,new)
p.write_text(s)
