def _identity_definitions(nodes: Mapping[str, Tree], cut: Tree, state: Tree) -> None:
    paths = [node['InstancePath'] for node in nodes.values()]
    if len(paths) != len(set(paths)):
        _fail('Conflict', 'admit', 'InstancePath', 'distinct node instances must have distinct paths')
    definitions: dict[str, Tree] = {}
    variables: set[str] = set()
    sites: set[tuple[str, str, str, str, str]] = set()
    for node in nodes.values():
        if node['Kind'] != 'precision-gate':
            continue
        path = node['InstancePath']
        for role in ['z', *['gamma/' + str(edge['TargetSlot']) for edge in node['Inputs']]]:
            preimage = {'Kind': 'mixed-epoch-variable-v1', 'InstancePath': path, 'Role': role}
            sha = _sha(_canonical(preimage, 4096))
            if sha in definitions:
                _fail('Conflict', 'admit', 'Variable', 'duplicate or colliding derived definition')
            definitions[sha] = preimage
            variables.add(sha)
        for factor in ['unary', *['normal/' + str(edge['TargetSlot']) for edge in node['Inputs']]]:
            preimage = {'Kind': 'mixed-epoch-factor-v1', 'InstancePath': path, 'Factor': factor}
            sha = _sha(_canonical(preimage, 4096))
            if sha in definitions:
                _fail('Conflict', 'admit', 'Factor', 'duplicate or colliding derived definition')
            definitions[sha] = preimage
            sites.add(('GaussianSites', path, factor, 'z', sha))
            if factor != 'unary':
                sites.add(('GammaSites', path, factor, 'gamma', sha))
    if len(variables) > 32 or set(cut['PriorOwners']) != variables:
        _fail('Conflict', 'admit', 'PriorOwners', 'exact derived variable roster required')
    owners = list(cut['PriorOwners'].values())
    if len(owners) != len(set(owners)):
        _fail('Conflict', 'admit', 'PriorOwners', 'distinct variables need distinct independently supplied priors')
    external = set(owners) | {row['Id'] for row in cut['Rows']} | {use['ContributionId'] for row in cut['Rows'] for use in row['Uses']}
    if set(definitions) & external:
        _fail('Conflict', 'admit', 'Identity', 'derived definition collides with an external contribution or row')
    for family in ('GaussianSites', 'GammaSites'):
        for site in state[family]:
            key = site['Key']
            if (family, key['InstancePath'], key['Factor'], key['Port'], key['ContributionId']) not in sites:
                _fail('Conflict', 'admit', 'Site.Key', 'site is outside exact model-factor and port roster')


