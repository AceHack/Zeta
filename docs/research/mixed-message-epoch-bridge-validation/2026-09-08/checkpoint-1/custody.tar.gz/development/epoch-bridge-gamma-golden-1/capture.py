import ast
import hashlib
import json
from pathlib import Path
from typing import Any
from zeta_interp import mixed_message_epoch_bridge as bridge
source=Path('src/Interp.Python/tests/test_mixed_message_epoch_bridge.py').read_bytes()
tree=ast.parse(source)
function=next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name=='_gamma_codec_golden')
scope={'hashlib':hashlib,'Any':Any}
exec(compile(ast.Module(body=[function],type_ignores=[]),'<exact gamma fixture>','exec'),scope)
value=scope['_gamma_codec_golden']()
raw=bridge._canonical(value,bridge.MIB)
bridge._state(value['State']); bridge._call(value['Call'],'GammaBlock')
print(json.dumps({'Value':value,'CanonicalHex':raw.hex(),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'FixtureSourceSha256':hashlib.sha256(source).hexdigest().upper()},sort_keys=True))
