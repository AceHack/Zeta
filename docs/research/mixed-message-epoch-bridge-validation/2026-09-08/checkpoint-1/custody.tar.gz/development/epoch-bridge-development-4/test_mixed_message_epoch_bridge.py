"""Protocol/retention development fixtures; never the registered M4/M5 routes."""

from __future__ import annotations

import hashlib
import json
import os
import struct
from pathlib import Path
from typing import Any

import pytest

from zeta_interp import hidden_switch_compiled_record_store as records
from zeta_interp import mixed_message_epoch_bridge as bridge
from zeta_interp import precision_gate_projection_process as native
from zeta_interp import precision_gate_projection_reference as reference


def _ready() -> dict[str, object]:
    return {
        "Kind": "Ready",
        "Schema": bridge.SCHEMA,
        "SessionId": "fixture",
        "PlanSha256": "A" * 64,
        "ServiceSha256": "B" * 64,
    }


def _frame(value: object) -> bytes:
    return json.dumps(value, separators=(",", ":")).encode() + b"\n"


def _hex(value: float) -> str:
    return struct.pack(">d", value).hex().upper()


def _request() -> bridge.Frame:
    # This is a transport-only target. No real numerical service is called.
    raw = b'{"Schema":"zeta.precision-projection.input.v1","Id":"fixture/p","Parameters":{"T":"2","U":"0.5","K":"0","C":"2"},"Profile":"default"}'
    value = {
        "Kind": "ProjectionRequest",
        "Schema": bridge.SCHEMA,
        "SessionId": "fixture",
        "Sequence": 1,
        "RequestId": "fixture/p",
        "InputRevision": 0,
        "Base": {"PrecisionMean": _hex(1), "Precision": _hex(2)},
        "TargetBits": {"T": _hex(2), "U": _hex(0.5), "K": _hex(0), "C": _hex(2)},
        "RawInputHex": raw.hex(),
        "InputSha256": hashlib.sha256(raw).hexdigest().upper(),
        "CaseId": "fixture/p",
        "BindingsSha256": hashlib.sha256(b"{}").hexdigest().upper(),
        "Remaining": {},
    }
    result = bridge.decode_frame(_frame(value), "fixture")
    assert isinstance(result, bridge.Frame)
    return result


def _budget() -> bridge._Budget:
    return bridge._Budget(bridge.Reservation(1, 0, 0, records.Limits()), 0, lambda: 1)


def _store(parent: Path) -> records.Store:
    opened = records.open_store(parent, "records")
    assert isinstance(opened, records.Opened)
    return opened.Store


def _prepared() -> native.PreparedNative:
    return native.PreparedNative(True, "fixture", None, None, (), (), (), None, ())


def test_ready_retains_exact_original_bytes() -> None:
    raw = _frame(_ready())
    value = bridge.decode_frame(raw, "fixture")
    assert isinstance(value, bridge.Frame)
    assert value.Raw == raw
    assert value.Sha256 == hashlib.sha256(raw).hexdigest().upper()


@pytest.mark.parametrize(
    "raw",
    [
        b"{}",
        b"{}\n{}\n",
        b'{"Kind":"Ready","Kind":"Ready"}\n',
        b'{"Kind":"Ready","n":1e400}\n',
        b'{"Kind":"Ready","n":NaN}\n',
        b'{"Kind":"Ready","n":1.0}\n',
        b'{"Kind":"Ready","n":9223372036854775808}\n',
        b'{"Kind":"Ready","n":"\\ud800"}\n',
        b"\xff\n",
    ],
)
def test_strict_frame_refuses_malformed_input(raw: bytes) -> None:
    assert isinstance(bridge.decode_frame(raw, "fixture"), bridge.Failure)


@pytest.mark.parametrize(
    "change", [{"extra": None}, {"SessionId": "other"}, {"Schema": "other"}]
)
def test_exact_outer_keys_and_bindings(change: dict[str, object]) -> None:
    value = _ready() | change
    assert isinstance(bridge.decode_frame(_frame(value), "fixture"), bridge.Failure)


def test_boolean_sequence_is_not_one() -> None:
    value = _request().Value | {"Sequence": True}
    assert isinstance(bridge.decode_frame(_frame(value), "fixture"), bridge.Failure)


def test_canonical_keeps_array_order_unicode_and_signed_zero_bits() -> None:
    value = {"z": ["é", "\\", "\n"], "a": _hex(-0.0)}
    expected = b'{"a":"8000000000000000","z":["\xc3\xa9","\\\\","\\n"]}'
    assert bridge._canonical(value, len(expected)) == expected
    with pytest.raises(bridge._Stop):
        bridge._canonical(value, len(expected) - 1)


def test_source_reservation_is_not_refunded_or_reset() -> None:
    pins = {
        "@host": native.FileIdentity(100, "A" * 64),
        native.SCRIPT: native.FileIdentity(20, "B" * 64),
        "a.dll": native.FileIdentity(30, "C" * 64),
        "b.dll": native.FileIdentity(40, "D" * 64),
        "c.dll": native.FileIdentity(50, "E" * 64),
    }
    result = bridge._reservation(2, pins)
    assert result.ExternalBytes == 2 * (140 + 2 * (65536 + 65536 + 2097152))
    assert result.ExternalSlots == 10
    assert result.StoreLimits.CombinedBytes + result.ExternalBytes == 256 * 1024 * 1024
    assert result.StoreLimits.Artifacts + result.ExternalSlots == 4096
    zero = bridge._reservation(0, {})
    assert zero.ExternalBytes == zero.ExternalSlots == 0


def test_returned_refusal_is_retained_before_encoding(tmp_path: Path) -> None:
    actual = native.NativeObservation(
        Failure=native.ProcessFailure("fixture", "control", "returned")
    )
    called = []

    def launch(*args: object, **kwargs: object) -> object:
        called.append((args, kwargs))
        return actual

    def forbidden(*_: object, **__: object) -> object:
        raise AssertionError("incomplete native return must not enter certificate")

    budget = _budget()
    retained: list[bridge.ProjectionExchange] = []
    result = bridge._projection(
        _request(),
        _prepared(),
        {},
        "B" * 64,
        tmp_path / "native",
        _store(tmp_path),
        budget,
        retained,
        bridge._Services(launch, forbidden),
    )
    assert len(called) == 1
    assert budget.NativeCallEntered == budget.NativeReturned == 1
    assert budget.CertificateEntered == 0
    assert retained[0].Native is not None and retained[0].Native.Returned is actual
    assert result["Native"]["Type"].endswith("NativeObservation")
    assert result["Certificate"] is None and result["Failure"]["Code"] == "Service"


def test_raised_native_is_not_a_return_or_known_launch(tmp_path: Path) -> None:
    def launch(*_: object, **__: object) -> object:
        raise OSError("fixture")

    budget = _budget()
    retained: list[bridge.ProjectionExchange] = []
    bridge._projection(
        _request(),
        _prepared(),
        {},
        "B" * 64,
        tmp_path / "native",
        _store(tmp_path),
        budget,
        retained,
        bridge._Services(launch, launch),
    )
    assert budget.NativeCallEntered == 1 and budget.NativeReturned == 0
    assert "NativeLaunchAttempted" in budget.RemoteIncomplete
    assert retained[0].Native is not None and retained[0].Native.Raised is not None


def test_actual_certificate_failure_retains_native_and_nested_count(
    tmp_path: Path,
) -> None:
    actual_native = native.NativeObservation(
        Complete=True, Receipt=b"fixture", LaunchAttempted=True
    )
    actual_certificate = reference.ReceiptFailure(
        reference.Failure("ResultTooLarge", "output", None, "fixture"),
        {"Counters": {"ReferenceRootCalls": 1}},
    )
    observed_args: list[object] = []

    def launch(*args: object, **kwargs: object) -> object:
        observed_args.append((args, kwargs))
        return actual_native

    def certify(*args: object, **kwargs: object) -> object:
        observed_args.append((args, kwargs))
        return actual_certificate

    budget = _budget()
    retained: list[bridge.ProjectionExchange] = []
    result = bridge._projection(
        _request(),
        _prepared(),
        {},
        "B" * 64,
        tmp_path / "native",
        _store(tmp_path),
        budget,
        retained,
        bridge._Services(launch, certify),
    )
    assert len(observed_args) == 2
    assert (
        budget.NativeCallEntered,
        budget.NativeReturned,
        budget.CertificateEntered,
        budget.CertificateReturned,
        budget.NestedReferenceEntered,
    ) == (1, 1, 1, 1, 1)
    assert (
        retained[0].Certificate is not None
        and retained[0].Certificate.Returned is actual_certificate
    )
    assert result["Certificate"] is None
    assert result["Failure"]["Code"] == "Storage"


def test_actual_normal_wrong_type_counts_as_return(tmp_path: Path) -> None:
    def launch(*_: object, **__: object) -> object:
        return {"not": "NativeObservation"}

    budget = _budget()
    retained: list[bridge.ProjectionExchange] = []
    result = bridge._projection(
        _request(),
        _prepared(),
        {},
        "B" * 64,
        tmp_path / "native",
        _store(tmp_path),
        budget,
        retained,
        bridge._Services(launch, launch),
    )
    assert budget.NativeCallEntered == budget.NativeReturned == 1
    assert retained[0].Native is not None and retained[0].Native.Returned == {
        "not": "NativeObservation"
    }
    assert result["Failure"]["Code"] == "Unexpected"


def test_budget_keeps_terminal_reserve_and_first_failure() -> None:
    budget = _budget()
    budget.ProtocolBytes = bridge.TRANSCRIPT_LIMIT - bridge.TERMINAL_RESERVE
    with pytest.raises(bridge._Stop):
        budget.charge_frame(1)
    budget.charge_frame(1, terminal=True)
    first = bridge.Failure("Storage", "publish", None, "first")
    budget.stop(first)
    budget.stop(bridge.Failure("Transport", "publish", None, "later"))
    assert budget.Failure is first


@pytest.mark.parametrize("name,bits", [("U", "8000000000000000"), ("T", _hex(4.0))])
def test_request_target_correspondence_precedes_native(name: str, bits: str) -> None:
    request = _request()
    value: dict[str, Any] = json.loads(request.Raw)
    value["TargetBits"][name] = bits
    parsed = bridge.decode_frame(_frame(value), "fixture")
    assert isinstance(parsed, bridge.Frame)
    with pytest.raises(bridge._Stop):
        bridge._request_input(parsed, {})


def test_transport_charges_unterminated_incoming_frame(tmp_path: Path) -> None:
    import sys
    import time

    budget = bridge._Budget(
        bridge.Reservation(0, 0, 0, records.Limits()), time.monotonic()
    )
    peer = bridge._Peer(
        (sys.executable, "-c", "import os; os.write(1,b'prefix')"), tmp_path, budget, 1
    )
    try:
        with pytest.raises(bridge._Stop):
            peer.receive()
        observed = peer.available()
        assert observed.PendingStdout == b"prefix"
        assert budget.Frames == 1
        assert budget.ProtocolBytes == 6
    finally:
        peer.close(normal=False)


def test_transport_failed_write_is_latched(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    import sys
    import time

    budget = bridge._Budget(
        bridge.Reservation(0, 0, 0, records.Limits()), time.monotonic()
    )
    peer = bridge._Peer(
        (sys.executable, "-c", "import sys; sys.stdin.buffer.read()"),
        tmp_path,
        budget,
        1,
    )
    calls = []

    def write(fd: int, raw: bytes) -> int:
        calls.append((fd, raw))
        if len(calls) == 1:
            return 1
        if len(calls) == 2:
            raise OSError("after one byte")
        return len(raw)

    monkeypatch.setattr(os, "write", write)
    monkeypatch.setattr(peer, "_poll_io", lambda **_: True)
    try:
        with pytest.raises(bridge._Stop):
            peer.send(b"first\n")
        with pytest.raises(bridge._Stop):
            peer.send(b"later\n")
        assert len(calls) == 2
        assert len(peer.available().Writes) == 1
        assert peer.available().Writes[0].WrittenBytes == 1
    finally:
        peer.close(normal=False)


def test_error_variant_requires_actual_nonnull_failure() -> None:
    with pytest.raises(bridge._Stop):
        bridge._unit_result({"Kind": "Error", "Failure": None})


def _query_plan() -> dict[str, Any]:
    row = {"Id": "fixture/query", "Origin": 0, "FeatureAvailable": 0, "TargetTime": 1, "LabelAvailable": 1, "Split": "control", "Features": [_hex(0)] * 8, "Target": None, "Uses": []}
    row["ContentSha256"] = bridge._sha(bridge._canonical(row, bridge.MIB))
    cut: dict[str, Any] = {"Id": "fixture/cut", "Rows": [row], "ActiveIds": ["fixture/query"], "PriorOwners": {}, "ParentCut": None, "Retractions": []}
    state = {"Revision": 0, "Weights": {}, "GaussianSites": [], "GammaSites": [], "Outputs": {}, "ActiveCut": bridge._sha(bridge._canonical(cut, bridge.MIB))}
    node: dict[str, Any] = {"Id": "fixture/gate", "InstancePath": "fixture/gate", "Kind": "precision-gate", "Inputs": [], "Artifact": None, "Prior": {"Gaussian": {"PrecisionMean": _hex(0), "Precision": _hex(1)}, "Gammas": []}, "Unary": {"K": _hex(0), "C": _hex(1)}, "Children": None, "OutputAlias": None}
    return {"Id": "fixture/plan", "Mode": "query", "EvidenceCut": cut, "QueryRowId": "fixture/query", "Nodes": [node], "SelectedVersions": {}, "InitialState": state, "Operations": [{"Kind": "GaussianBlock", "NodeId": "fixture/gate", "Sweep": 0}], "Sweeps": 1, "Damping": _hex(1), "Training": None, "Horizon": 1, "SourceBindings": {}}


def test_fixed_plan_derives_one_projection_without_entering_it() -> None:
    plan = _query_plan()
    admitted = bridge.admit_plan(_frame(plan), {})
    assert isinstance(admitted, bridge.AdmittedPlan)
    assert admitted.Projections == 1
    assert admitted.Operations == tuple(plan["Operations"])


@pytest.mark.parametrize("mutation", ["omitted-operation", "boolean-sweeps", "unknown-field", "target-visible", "gamma-without-input", "cut-content", "node-cycle"])
def test_complete_plan_refuses_structural_drift(mutation: str) -> None:
    plan = _query_plan()
    if mutation == "omitted-operation":
        plan["Operations"] = []
    elif mutation == "boolean-sweeps":
        plan["Sweeps"] = True
    elif mutation == "unknown-field":
        plan["extra"] = None
    elif mutation == "target-visible":
        plan["EvidenceCut"]["Rows"][0]["Target"] = _hex(1)
    elif mutation == "gamma-without-input":
        plan["Nodes"][0]["Prior"]["Gammas"] = [{"Shape": _hex(1), "Rate": _hex(1)}]
    elif mutation == "cut-content":
        plan["EvidenceCut"]["Rows"][0]["Features"][0] = _hex(2)
    else:
        plan["Nodes"][0]["Inputs"] = [{"SourceNode": "fixture/gate", "SourcePort": "mean", "TargetSlot": 0}]
        plan["Nodes"][0]["Prior"]["Gammas"] = [{"Shape": _hex(1), "Rate": _hex(1)}]
    admitted = bridge.admit_plan(_frame(plan), {})
    assert isinstance(admitted, bridge.Failure)


def test_public_frame_cannot_drift_from_retained_original() -> None:
    request = _request()
    request.Value["TargetBits"]["K"] = _hex(1)
    with pytest.raises(bridge._Stop):
        bridge._request_input(request, {})


def test_public_handle_cannot_be_constructed_or_used_without_issuance() -> None:
    with pytest.raises(TypeError):
        bridge.Bridge(None)
    fake = object.__new__(bridge.Bridge)
    result = bridge.run_session(fake, b"{}", "fixture")
    assert isinstance(result, bridge.Failure)
    finished = bridge.finish_bridge(fake)
    assert finished.Closed is False and finished.Failure is not None


def test_shared_string_escaping_golden() -> None:
    value = {"Type": "Zeta.Bayesian.BoundedModuleLearner+StepAttempt", "Text": '<>&\"\\/é😀\u2028\u2029', "Controls": "".join(chr(i) for i in range(32))}
    controls = b'\\u0000\\u0001\\u0002\\u0003\\u0004\\u0005\\u0006\\u0007\\b\\t\\n\\u000b\\f\\r\\u000e\\u000f\\u0010\\u0011\\u0012\\u0013\\u0014\\u0015\\u0016\\u0017\\u0018\\u0019\\u001a\\u001b\\u001c\\u001d\\u001e\\u001f'
    expected = b'{"Controls":"' + controls + b'","Text":"<>&\\"\\\\/\xc3\xa9\xf0\x9f\x98\x80\xe2\x80\xa8\xe2\x80\xa9","Type":"Zeta.Bayesian.BoundedModuleLearner+StepAttempt"}'
    actual = bridge._canonical(value, 4096)
    assert actual == expected
    decoded = bridge._json(actual, 4096)
    assert decoded == value


def _forward_plan() -> bridge.AdmittedPlan:
    plan = _query_plan()
    node = plan["Nodes"][0]
    node.update(Kind="neural", Artifact="fixture/model", Prior=None, Unary=None)
    artifact = {"Id": "fixture/model", "ParentVersion": None, "TrainingCut": "A" * 64, "Architecture": "point-mlp-12-4-1-v1", "Ports": ["absent", "absent"], "Parameters": [_hex(0)] * 57, "Preprocessing": {"TrainingCut": "A" * 64, "Count": 1, "Means": [_hex(0)] * 8, "Scales": [_hex(1)] * 8}, "UpdateReceiptSha256": "B" * 64, "SourceBindings": {}}
    plan["SelectedVersions"] = {"fixture/model": {"Version": bridge._sha(bridge._canonical(artifact, 65536)), "Artifact": artifact}}
    plan["Operations"] = [{"Kind": "NeuralForward", "NodeId": "fixture/gate", "Sweep": 0}]
    admitted = bridge.admit_plan(_frame(plan), {})
    assert isinstance(admitted, bridge.AdmittedPlan)
    return admitted


def _simulated_owner(tmp_path: Path) -> bridge._Owner:
    import time

    owner = bridge._Owner(bridge._ISSUER)
    owner.SourceRoot = tmp_path
    owner.Host = tmp_path / "dotnet"
    owner.AttemptRoot = tmp_path
    owner.AttemptOwned = True
    owner.Manifest = bridge.ServiceManifest(b"fixture", "B" * 64, (), (), ())
    owner.Store = _store(tmp_path)
    owner.Budget = bridge._Budget(bridge.Reservation(0, 0, 0, records.Limits()), time.monotonic())
    owner.Budget.Calls = owner.Calls
    return owner


def _counter_fixture() -> dict[str, Any]:
    result: dict[str, Any] = dict.fromkeys(bridge._COUNTER_CAPS, 0)
    result.update(SchedulerEntered=1, ForwardEntered=1, Returned=1, Proposed=1, Applied=1)
    result["Remote"] = {name: {"Observed": 0, "Complete": True} for name in bridge._REMOTE_KEYS}
    return result


class _FixturePeer:
    """Declared transport simulation; no peer/core/native numerical process."""

    mutation = "none"

    def __init__(self, argv: tuple[str, ...], cwd: Path, budget: bridge._Budget, maximum_launches: int):
        self.budget = budget
        budget.PeerLaunches += 1
        self.received: list[bytes] = []
        self.sent: list[bytes] = []
        self.queue: list[bytes] = []
        self.observation = bridge.PeerObservation(argv, "synthetic transport fixture", LaunchAttempted=True, StderrEof=True)
        self.result: dict[str, Any] = {}
        self.plan: dict[str, Any] = {}
        self.checkpoint: dict[str, Any] = {}
        self.session = ""
        self.checkpoint_raw = b""
        self.return_raw = b""

    def available(self) -> bridge.PeerObservation:
        return self.observation

    def header(self, kind: str) -> dict[str, Any]:
        return {"Kind": kind, "Schema": bridge.SCHEMA, "SessionId": self.session}

    def send(self, raw: bytes) -> bridge.WriteObservation:
        self.budget.charge_frame(len(raw))
        self.sent.append(raw)
        value = json.loads(raw)
        if value["Kind"] == "Start":
            self.session = value["SessionId"]
            self.plan = value["Plan"]
            self.queue.append(_frame(self.header("Ready") | {"PlanSha256": value["PlanSha256"], "ServiceSha256": value["ServiceSha256"]}))
            state = json.loads(json.dumps(self.plan["InitialState"]))
            state["Revision"] = 1
            state["Outputs"] = {"fixture/gate": {"Mean": _hex(0), "Variance": None, "SourceSequence": 1}}
            call = {"Kind": "Returned", "Result": {"Type": "Zeta.Bayesian.BoundedModuleLearner+ForwardAttempt", "Fields": {"Input": {"Parameters": [_hex(0)] * 57, "Inputs": [_hex(0)] * 12}, "Preactivations": [_hex(0)] * 4, "Hidden": [_hex(0)] * 4, "Outcome": {"Kind": "Ok", "Value": _hex(0)}}}}
            observation = {"Sequence": 1, "Operation": self.plan["Operations"][0], "InputRevision": 0, "Inputs": {}, "Call": call, "Proposal": {"ExpectedRevision": 0, "ExpectedStateSha256": bridge._sha(bridge._canonical(self.plan["InitialState"], bridge.MIB)), "State": state, "Details": {}}, "Admission": {"Kind": "Ok", "Value": None}, "AppliedRevision": None, "Failure": None}
            self.checkpoint = self.header("Checkpoint") | {"Sequence": 1, "Observation": observation, "LastRevision": 0, "StateSha256": observation["Proposal"]["ExpectedStateSha256"]}
            self.checkpoint_raw = _frame(self.checkpoint)
            self.queue.append(self.checkpoint_raw)
        elif value["Sequence"] == 1:
            assert value["CheckpointSha256"] == bridge._sha(self.checkpoint_raw)
            descriptor = value["Outcome"]["Artifact"]
            assert descriptor["Sha256"] == bridge._sha(self.checkpoint_raw)
            committed = json.loads(json.dumps(self.checkpoint["Observation"]))
            committed["AppliedRevision"] = 1
            counters = _counter_fixture()
            commit = self.header("Commit") | {"Sequence": 1, "CheckpointSha256": bridge._sha(self.checkpoint_raw), "AppliedRevision": 1, "LastCommitted": committed["Proposal"]["State"], "Counters": counters}
            if self.mutation == "wrong-commit":
                commit["CheckpointSha256"] = "C" * 64
            if self.mutation != "missing-commit":
                self.queue.append(_frame(commit))
            self.result = {"PlanSha256": bridge._sha(bridge._canonical(self.plan, bridge.MIB)), "Outcome": "completed", "Termination": "BudgetCompleted", "Failure": None, "LastCommitted": committed["Proposal"]["State"], "ProposedArtifacts": [], "Observations": [committed], "Counters": counters, "PendingRequest": None, "Scheduler": {"Kind": "Returned", "Result": {"Kind": "Ok", "Value": 1}}, "Publication": {"Recorder": [], "Unpublished": [], "Failure": None, "BudgetSnapshot": value["BudgetSnapshot"]}}
            if self.mutation == "changed-return":
                self.result["Observations"][0]["Inputs"] = {"changed": True}
            if self.mutation == "missing-return":
                self.queue.append(_frame(self.header("Terminal") | {key: self.result[key] for key in ("Outcome", "Termination", "Failure", "Counters", "LastCommitted", "PendingRequest")} | {"LedgerCount": 1, "LedgerSha256": bridge._sha(bridge._canonical(self.result["Observations"], 16 * bridge.MIB)), "Publication": {}}))
            else:
                returned = self.header("EpochReturn") | {"Sequence": 2, "Result": self.result, "ResultSha256": bridge._sha(bridge._canonical(self.result, 16 * bridge.MIB))}
                self.return_raw = _frame(returned)
                self.queue.append(self.return_raw)
        else:
            transport = {"IncomingBytes": sum(map(len, self.sent)), "IncomingFrames": len(self.sent), "OutgoingReservedBytes": sum(map(len, self.received)), "OutgoingReservedFrames": len(self.received), "OutgoingCompletedBytes": sum(map(len, self.received)), "OutgoingCompletedFrames": len(self.received), "PartialWrite": None}
            publication = {"EpochReturn": {"Sequence": 2, "ResultSha256": bridge._sha(bridge._canonical(self.result, 16 * bridge.MIB)), "FrameSha256": bridge._sha(self.return_raw), "Artifact": value["Outcome"]["Artifact"]}, "ResultRetention": "acknowledged", "Failure": None, "Transport": {"Coordinator": value["BudgetSnapshot"], "Peer": transport}}
            terminal = self.header("Terminal") | {key: self.result[key] for key in ("Outcome", "Termination", "Failure", "Counters", "LastCommitted", "PendingRequest")} | {"LedgerCount": 1, "LedgerSha256": bridge._sha(bridge._canonical(self.result["Observations"], 16 * bridge.MIB)), "Publication": publication}
            if self.mutation == "wrong-return-link":
                publication["EpochReturn"]["ResultSha256"] = "D" * 64
            self.queue.append(_frame(terminal))
            if self.mutation == "after-terminal":
                self.queue.append(b"{}\n")
        return bridge.WriteObservation(raw, len(raw), None)

    def receive(self, *, terminal: bool = False) -> bytes | None:
        if not self.queue:
            self.observation = bridge.replace(self.observation, StdoutEof=True)
            return None
        raw = self.queue.pop(0)
        self.budget.charge_frame(len(raw), terminal=terminal)
        self.received.append(raw)
        return raw

    def close(self, *, normal: bool) -> bridge.PeerObservation:
        self.observation = bridge.replace(self.observation, DirectChildClosed=True, ExitCode=0, Stdout=tuple(self.received))
        return self.observation


def test_actual_store_ack_commit_and_complete_return_chain(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    owner = _simulated_owner(tmp_path)
    plan = _forward_plan()
    session = bridge.SessionResult("fixture", plan.Raw, Plan=plan)
    monkeypatch.setattr(bridge, "_Peer", _FixturePeer)
    bridge._run_peer(owner, session)
    assert session.Failure is None
    assert session.Closed and session.ForecastEligible
    assert session.LastObservedCommitted is not None and session.LastObservedCommitted["Revision"] == 1
    assert len(session.Checkpoints) == len(session.Commits) == len(session.CommitPages) == 1
    assert session.EpochReturn is not None and session.EpochReturnArtifact is not None
    assert session.EpochReturn.Value["Result"]["Publication"]["BudgetSnapshot"] != session.Terminal.Value["Publication"]["Transport"]["Coordinator"]
    assert session.EpochReturnAck is not None and session.EpochReturnAck.Failure is None
    assert owner.Budget is not None and owner.Budget.NativeCallEntered == owner.Budget.CertificateEntered == 0


@pytest.mark.parametrize("mutation", ["wrong-commit", "missing-commit", "changed-return", "missing-return", "wrong-return-link", "after-terminal"])
def test_transport_association_refusals_keep_actual_prefix(tmp_path: Path, monkeypatch: pytest.MonkeyPatch, mutation: str) -> None:
    owner = _simulated_owner(tmp_path)
    plan = _forward_plan()
    session = bridge.SessionResult("fixture", plan.Raw, Plan=plan)
    class MutatedPeer(_FixturePeer):
        pass
    MutatedPeer.mutation = mutation
    monkeypatch.setattr(bridge, "_Peer", MutatedPeer)
    bridge._run_peer(owner, session)
    assert session.Failure is not None
    assert not session.Closed and not session.ForecastEligible
    assert session.Checkpoints[0][1] is not None
    assert session.Peer is not None and session.Peer.DirectChildClosed
    if mutation in ("wrong-commit", "missing-commit"):
        assert session.LastObservedCommitted == plan.Value["InitialState"]
    else:
        assert session.LastObservedCommitted is not None and session.LastObservedCommitted["Revision"] == 1
