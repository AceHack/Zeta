import hashlib
import json
from zeta_interp import mixed_message_epoch_bridge as bridge
value = {"Type": "Zeta.Bayesian.BoundedModuleLearner+StepAttempt", "Text": '<>&"\\/\u00e9\U0001f600\u2028\u2029', "Controls": "".join(chr(i) for i in range(32))}
raw = bridge._canonical(value, 4096)
print(json.dumps({"Value": value, "CanonicalBytes": len(raw), "CanonicalHex": raw.hex(), "Sha256": hashlib.sha256(raw).hexdigest().upper()}, ensure_ascii=True, separators=(",", ":")))
