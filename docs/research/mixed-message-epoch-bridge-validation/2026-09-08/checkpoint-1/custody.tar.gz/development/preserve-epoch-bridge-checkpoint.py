from pathlib import Path
import gzip,hashlib,io,json,os,stat,subprocess,tarfile
root=Path.cwd()
out=root/'docs/research/mixed-message-epoch-bridge-validation/2026-09-08/checkpoint-1'
source_paths=['src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py','src/Interp.Python/zeta_interp/mixed_message_epoch_controls.py','src/Interp.Python/tests/test_mixed_message_epoch_bridge.py']
def sha(raw):return hashlib.sha256(raw).hexdigest().upper()
def js(value):return (json.dumps(value,indent=2,ensure_ascii=True)+'\n').encode()
for name in ('1-completion.json','2-completion.json'):
    if not (root/'.git/epoch-bridge-repository-gate-1'/name).is_file():raise ValueError('repository gate not complete')
source=[]
for name in source_paths:
    raw=(root/name).read_bytes()
    for folder in ('epoch-bridge-final-tests-2','epoch-bridge-final-checks-2','epoch-bridge-repository-gate-1'):
        captured=(root/'.git'/folder/Path(name).name).read_bytes()
        if captured!=raw:raise ValueError('source drift from '+folder+': '+name)
    source.append({'Path':name,'Bytes':len(raw),'Sha256':sha(raw)})
head=subprocess.run(['git','rev-parse','HEAD'],check=True,capture_output=True).stdout.decode().strip()
for row in source:
    committed=subprocess.run(['git','show',head+':'+row['Path']],check=True,capture_output=True).stdout
    if len(committed)!=row['Bytes'] or sha(committed)!=row['Sha256']:raise ValueError('committed source mismatch')
branch=subprocess.run(['git','branch','--show-current'],check=True,capture_output=True).stdout.decode().strip()
selected=[]
for path in sorted((root/'.git').iterdir()):
    if path.name.startswith('epoch-bridge-') or path.name in (
      'epoch-catalog-fragment.py','epoch-identity-fragment.py','epoch-input-fragment.py',
      'repair-epoch-boundaries.py','repair-epoch-json-equality-first.py','repair-epoch-json-equality.py',
      'repair-epoch-json-equality-first-failure.json','run-epoch-checks.py','run-epoch-development.py',
      'run-epoch-repository-gate.py','preserve-epoch-bridge-checkpoint.py'):
        selected.append(path)
files=[]; nodes=[]
for path in selected:
    for member in [path,*sorted(path.rglob('*'))] if path.is_dir() else [path]:
        mode=member.lstat().st_mode
        name='development/'+str(member.relative_to(root/'.git'))
        node={'Name':name,'Mode':stat.S_IMODE(mode)}
        if stat.S_ISDIR(mode):node['Kind']='directory'
        elif stat.S_ISLNK(mode):node.update(Kind='symlink',Target=os.readlink(member))
        elif stat.S_ISREG(mode):
            node['Kind']='regular';files.append((name,member,member.read_bytes()))
        else:raise ValueError('unexpected file kind '+str(member))
        nodes.append(node)
for name in source_paths:files.append(('source/'+name,root/name,(root/name).read_bytes()))
node_raw=js(nodes)
files.append(('lstat-inventory.json',None,node_raw))
if len({item[0] for item in files})!=len(files):raise ValueError('duplicate archive name')
archive=io.BytesIO(); records=[]
with gzip.GzipFile(fileobj=archive,mode='wb',mtime=0,filename='') as zipped:
    with tarfile.open(fileobj=zipped,mode='w',format=tarfile.PAX_FORMAT) as tar:
        for name,original,raw in files:
            info=tarfile.TarInfo(name);info.size=len(raw);info.mode=0o644;info.mtime=0
            tar.addfile(info,io.BytesIO(raw))
            records.append({'Name':name,'Bytes':len(raw),'Sha256':sha(raw),'OriginalLocalFile':None if original is None else str(original)})
archive_raw=archive.getvalue()
manifest={'Schema':'zeta.mixed-epoch.bridge-development-custody.v1','SourceCommit':head,'ParentCommit':'cd794f8ac4550050c5523f149551e0fc5d3fe50a','Branch':branch,
          'SourceFiles':source,'Archive':{'File':'custody.tar.gz','Bytes':len(archive_raw),'Sha256':sha(archive_raw)},
          'OriginalBytes':sum(row['Bytes'] for row in records),'Records':records,
          'FilesystemInventory':{'Name':'lstat-inventory.json','Bytes':len(node_raw),'Sha256':sha(node_raw)},
          'Notes':['Regular originals only in tar; directory and symlink metadata retained without following targets in lstat-inventory.json.',
                   'OriginalLocalFile is historical provenance, never an instruction to open it.',
                   'A same-commit source identity is expressed by exact file hashes, not an invented self-referential commit id.']}
# Validate every member and every independently reread regular original before publication.
with tarfile.open(fileobj=io.BytesIO(archive_raw),mode='r:gz') as tar:
    members=tar.getmembers()
    if [m.name for m in members]!=[r['Name'] for r in records]:raise ValueError('archive order mismatch')
    for member,row in zip(members,records,strict=True):
        stream=tar.extractfile(member)
        if stream is None or not member.isfile():raise ValueError('nonregular archive member')
        raw=stream.read()
        if len(raw)!=row['Bytes'] or sha(raw)!=row['Sha256']:raise ValueError('archive mismatch')
        if row['OriginalLocalFile'] is not None and Path(row['OriginalLocalFile']).read_bytes()!=raw:raise ValueError('original changed')
out.mkdir(parents=True,exist_ok=False)
(out/'custody.tar.gz').write_bytes(archive_raw)
(out/'manifest.json').write_bytes(js(manifest))
gates=[]
for number in (1,2):
    p=root/'.git/epoch-bridge-repository-gate-1'
    gates.append({'Command':json.loads((p/f'{number}-invocation.json').read_bytes()),'Completion':json.loads((p/f'{number}-completion.json').read_bytes())})
summary={'ArchiveMembers':len(records),'OriginalBytes':manifest['OriginalBytes'],'Archive':manifest['Archive'],
         'SourceFiles':source,'FilesystemNodes':len(nodes),'SymlinksRecorded':sum(n['Kind']=='symlink' for n in nodes),
         'AllMembersAndOriginalsMatched':True,'FinalSourceEqualsAllThreeFinalCaptures':True,'RepositoryGates':gates}
(out/'observation.json').write_bytes(js(summary))
print(json.dumps(summary,indent=2))
