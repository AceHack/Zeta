"""Bounded mixed-epoch coordinator; actual returns precede fallible publication.

The service/source identities are independently supplied caller premises.
This module neither establishes transitive runtime closure nor selects a
numerical experiment. A handle owns its one recorder and finite session route;
normal refusals never authorize a replacement session or a budget refund.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
import struct
import time
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, NoReturn, cast

from . import hidden_switch_compiled_admission as admission
from . import hidden_switch_compiled_record_encoding as encoding
from . import hidden_switch_compiled_record_store as records
from . import precision_gate_projection_process as native
from . import precision_gate_projection_reference as reference

SCHEMA = "zeta.mixed-epoch.peer.v1"
CONTRACT_SHA256 = "4234015EE650FA7190CF3375C58654499F3BB9EC9C96E4BE21D2FC97A30EC979"
MIB = 1024 * 1024
TRANSCRIPT_LIMIT = 64 * MIB
TERMINAL_RESERVE = MIB
FRAME_LIMIT = 16384
RETENTION_LIMIT = 256 * MIB
ARTIFACT_LIMIT = 4096
JOURNAL_RESERVE = 8 * MIB
PEER_SCRIPT = "src/Research.FSharp/MixedMessageEpochReplay.fsx"
_HASH = re.compile(r"[0-9A-F]{64}\Z", re.ASCII)
_BITS = re.compile(r"[0-9A-F]{16}\Z", re.ASCII)
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._/-]{0,63}\Z", re.ASCII)
_DECIMAL = re.compile(r"-?(0|[1-9][0-9]*)(\.[0-9]+)?(e[+-]?[0-9]+)?\Z", re.ASCII)
_HEADER = frozenset(("Kind", "Schema", "SessionId"))
_KEYS = {
    "Start": _HEADER | {"Plan", "PlanSha256", "ServiceSha256", "ExpectedBindings"},
    "Ready": _HEADER | {"PlanSha256", "ServiceSha256"},
    "Checkpoint": _HEADER | {"Sequence", "Observation", "LastRevision", "StateSha256"},
    "ProjectionRequest": _HEADER | {
        "Sequence", "RequestId", "InputRevision", "Base", "TargetBits", "RawInputHex",
        "InputSha256", "CaseId", "BindingsSha256", "Remaining",
    },
    "CheckpointAck": _HEADER | {"Sequence", "CheckpointSha256", "Outcome"},
    "Commit": _HEADER | {
        "Sequence", "CheckpointSha256", "AppliedRevision", "LastCommitted", "Counters",
    },
    "ProjectionResponse": _HEADER | {
        "Sequence", "RequestId", "InputSha256", "BindingsSha256", "ServiceSha256",
        "Native", "Certificate", "Failure",
    },
    "EpochReturn": _HEADER | {"Sequence", "Result", "ResultSha256"},
    "Terminal": _HEADER | {
        "Outcome", "Termination", "Failure", "Counters", "LastCommitted", "LedgerCount",
        "LedgerSha256", "PendingRequest", "Publication",
    },
}
_CAPS = {
    "Start": MIB, "Ready": 64 * 1024, "Checkpoint": 16 * MIB,
    "ProjectionRequest": 256 * 1024, "CheckpointAck": 64 * 1024,
    "Commit": 64 * 1024, "ProjectionResponse": 12 * MIB,
    "EpochReturn": 16 * MIB, "Terminal": MIB,
}
type Tree = dict[str, Any]


@dataclass(frozen=True, slots=True)
class Failure:
    Code: str
    Stage: str
    Field: str | None
    Message: str


@dataclass(frozen=True, slots=True)
class Raised:
    Type: str
    Message: str


@dataclass(frozen=True, slots=True)
class CallObservation:
    Operation: str
    Returned: object
    Raised: Raised | None


@dataclass(frozen=True, slots=True)
class Frame:
    Raw: bytes
    Sha256: str
    Value: Tree


@dataclass(frozen=True, slots=True)
class Reservation:
    Projections: int
    ExternalBytes: int
    ExternalSlots: int
    StoreLimits: records.Limits


class _Stop(Exception):
    def __init__(self, failure: Failure) -> None:
        super().__init__(failure.Message)
        self.failure = failure


def _fail(code: str, stage: str, name: str | None, message: str) -> NoReturn:
    raise _Stop(Failure(code, stage, name, message))


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest().upper()


def _keys(value: object, names: set[str] | frozenset[str], name: str) -> Tree:
    if type(value) is not dict or set(value) != names:
        _fail("Admission", "admit", name, "exact record keys required")
    return cast(Tree, value)


def _integer(value: object, name: str, lower: int, upper: int) -> int:
    if type(value) is not int or not lower <= value <= upper:
        _fail("Admission", "admit", name, "exact bounded integer required")
    return value


def _hash(value: object, name: str) -> str:
    if type(value) is not str or _HASH.fullmatch(value) is None:
        _fail("Admission", "admit", name, "uppercase SHA256 required")
    return value


def _id(value: object, name: str) -> str:
    if type(value) is not str or _ID.fullmatch(value) is None:
        _fail("Admission", "admit", name, "bounded ASCII identity required")
    return value


def _pairs(items: list[tuple[str, object]]) -> Tree:
    result: Tree = {}
    for key, value in items:
        if key in result:
            _fail("Admission", "admit", key, "duplicate JSON key")
        result[key] = value
    return result


def _non_integer(_: str) -> NoReturn:
    _fail("Admission", "admit", "JSON", "floating or nonfinite JSON number")


def _bounded_integer(text: str) -> int:
    if len(text) > 20:
        _fail("Admission", "admit", "JSON", "integer exceeds int64")
    value = int(text)
    return _integer(value, "JSON", -(1 << 63), (1 << 63) - 1)


def _tree(value: object, *, maximum_nodes: int = 100_000) -> None:
    pending = [(value, 0)]
    nodes = 0
    while pending:
        item, depth = pending.pop()
        nodes += 1
        if nodes > maximum_nodes or depth > 128:
            _fail("Budget", "admit", "JSON", "JSON node/depth allowance exhausted")
        if item is None or type(item) is bool:
            continue
        if type(item) is int:
            _integer(item, "JSON", -(1 << 63), (1 << 63) - 1)
        elif type(item) is str:
            item.encode("utf-8", errors="strict")
        elif type(item) is list:
            if len(item) > maximum_nodes - nodes:
                _fail("Budget", "admit", "JSON", "array exceeds remaining node allowance")
            pending.extend((child, depth + 1) for child in item)
        elif type(item) is dict:
            if len(item) > maximum_nodes - nodes:
                _fail("Budget", "admit", "JSON", "record exceeds remaining node allowance")
            for key, child in item.items():
                if type(key) is not str or not key.isascii():
                    _fail("Admission", "admit", "JSON", "ASCII object keys required")
                pending.append((child, depth + 1))
        else:
            _fail("Admission", "admit", "JSON", "unsupported JSON value")


def _json(raw: object, cap: int) -> object:
    if type(raw) is not bytes or len(raw) > cap:
        _fail("Budget", "admit", "Raw", "bounded original bytes required")
    result = json.loads(
        raw.decode("utf-8", errors="strict"), object_pairs_hook=_pairs,
        parse_float=_non_integer, parse_constant=_non_integer, parse_int=_bounded_integer,
    )
    _tree(result)
    return result


def _canonical(value: object, cap: int, *, newline: bool = False) -> bytes:
    _tree(value)
    encoded = bytearray()
    allowance = cap - int(newline)

    def emit(raw: bytes) -> None:
        if len(raw) > allowance - len(encoded):
            _fail("Budget", "publish", "JSON", "encoded record exceeds allowance")
        encoded.extend(raw)

    def string(text: str) -> None:
        emit(b'"')
        for offset in range(0, len(text), 512):
            part = text[offset:offset + 512]
            raw = json.dumps(part, ensure_ascii=False)[1:-1].encode("utf-8", errors="strict")
            emit(raw)
        emit(b'"')

    def visit(item: object) -> None:
        if item is None:
            emit(b"null")
        elif type(item) is bool:
            emit(b"true" if item else b"false")
        elif type(item) is int:
            emit(str(item).encode("ascii"))
        elif type(item) is str:
            string(item)
        elif type(item) is list:
            emit(b"[")
            for index, child in enumerate(item):
                if index:
                    emit(b",")
                visit(child)
            emit(b"]")
        else:
            record = cast(Tree, item)
            emit(b"{")
            for index, key in enumerate(sorted(record)):
                if index:
                    emit(b",")
                string(key)
                emit(b":")
                visit(record[key])
            emit(b"}")

    visit(value)
    if newline:
        encoded.append(10)
    return bytes(encoded)


def decode_frame(raw: object, session_id: object) -> Frame | Failure:
    """Admit an already retained frame; no session progression or numerical call."""
    try:
        session = _id(session_id, "SessionId")
        if type(raw) is not bytes or len(raw) > 16 * MIB:
            _fail("Budget", "admit", "Frame", "frame exceeds absolute cap")
        if not raw.endswith(b"\n") or raw.count(b"\n") != 1:
            _fail("Transport", "admit", "Frame", "one complete LF-terminated record required")
        value = _json(raw, 16 * MIB)
        if type(value) is not dict:
            _fail("Admission", "admit", "Frame", "object frame required")
        kind = value.get("Kind")
        if type(kind) is not str or kind not in _KEYS:
            _fail("Admission", "admit", "Kind", "unknown protocol frame")
        record = _keys(value, _KEYS[kind], "Frame")
        if record["Schema"] != SCHEMA or record["SessionId"] != session:
            _fail("Conflict", "admit", "SessionId", "protocol/session identity mismatch")
        if len(raw) > _CAPS[kind]:
            _fail("Budget", "admit", "Frame", "kind-specific frame allowance exceeded")
        if "Sequence" in record:
            _integer(record["Sequence"], "Sequence", 1, FRAME_LIMIT)
        return Frame(raw, _sha(raw), record)
    except _Stop as error:
        return error.failure
    except (ValueError, UnicodeError, RecursionError) as error:
        return Failure("Admission", "admit", "Frame", type(error).__name__)


def _observe(operation: str, call: Callable[[], object], ledger: list[CallObservation]) -> CallObservation:
    try:
        value = call()
    except Exception as error:  # noqa: BLE001 - actual boundary preserves raised vs returned.
        result = CallObservation(operation, None, Raised(type(error).__name__, str(error)[:1024]))
    else:
        result = CallObservation(operation, value, None)
    ledger.append(result)
    return result


def _public_tree(value: object, cap: int, ledger: list[CallObservation]) -> object:
    observed = _observe("encode_public_result", lambda: encoding.encode_public_result(value, maximum_bytes=cap), ledger)
    if observed.Raised is not None:
        _fail("Unexpected", "publish", None, "public encoding raised; original return retained")
    if type(observed.Returned) is not admission.Admitted:
        _fail("Storage", "publish", None, "public encoding refused; original return retained")
    raw = observed.Returned.value
    return _json(raw, cap)


def _bits(value: object, name: str) -> float:
    if type(value) is not str or _BITS.fullmatch(value) is None:
        _fail("Admission", "admit", name, "exact binary64 bits required")
    number = struct.unpack(">d", bytes.fromhex(value))[0]
    if not math.isfinite(number):
        _fail("Arithmetic", "admit", name, "finite binary64 value required")
    return number


def _round_trip(text: object, bits: object, name: str) -> None:
    _bits(bits, name)
    if type(text) is not str or len(text) > 4096 or _DECIMAL.fullmatch(text) is None:
        _fail("Admission", "admit", name, "invariant decimal text required")
    number = float(text)
    if not math.isfinite(number) or struct.pack(">d", number).hex().upper() != bits:
        _fail("Conflict", "admit", name, "rendered target differs from admitted bits")


def _reservation(projections: int, expected_files: Mapping[str, native.FileIdentity]) -> Reservation:
    _integer(projections, "Projections", 0, 32)
    if projections == 0:
        external, slots = 0, 0
    else:
        if len(expected_files) != 5 or native.SCRIPT not in expected_files or "@host" not in expected_files:
            _fail("Admission", "admit", "NativeFiles", "exact independently admitted native roster required")
        total = 0
        for path, pin in expected_files.items():
            if type(pin) is not native.FileIdentity:
                _fail("Admission", "admit", path, "typed direct file identity required")
            _integer(pin.Bytes, path, 0, native.FILE_CAP)
            _hash(pin.Sha256, path)
            if path != "@host":
                total += pin.Bytes
        external = 2 * (total + projections * (64 * 1024 + 64 * 1024 + 2 * MIB))
        slots = 4 + 3 * projections
    available = RETENTION_LIMIT - external
    remaining_slots = ARTIFACT_LIMIT - slots
    if available <= 10 * MIB or remaining_slots < 3:
        _fail("Budget", "admit", "Reservation", "insufficient journal, terminal and ordinary room")
    return Reservation(projections, external, slots, records.Limits(available, JOURNAL_RESERVE, remaining_slots))


@dataclass(slots=True)
class _Budget:
    Reservation: Reservation
    Started: float
    Clock: Callable[[], float] = time.monotonic
    ProtocolBytes: int = 0
    Frames: int = 0
    PeerLaunches: int = 0
    NativeCallEntered: int = 0
    NativeLaunchAttempted: int = 0
    NativeReturned: int = 0
    CertificateEntered: int = 0
    CertificateReturned: int = 0
    NestedReferenceEntered: int = 0
    Calls: list[CallObservation] = field(default_factory=list)
    RemoteIncomplete: set[str] = field(default_factory=set)
    Failure: Failure | None = None

    def stop(self, failure: Failure) -> None:
        if self.Failure is None:
            self.Failure = failure

    def check(self) -> None:
        if self.Failure is not None:
            raise _Stop(self.Failure)
        if self.Clock() - self.Started > 300:
            _fail("Budget", "scheduler", "Elapsed", "outer cooperative deadline exhausted")

    def charge_frame(self, size: int, *, terminal: bool = False) -> None:
        self.check()
        _integer(size, "ProtocolBytes", 1, 16 * MIB)
        cap = TRANSCRIPT_LIMIT if terminal else TRANSCRIPT_LIMIT - TERMINAL_RESERVE
        if size > cap - self.ProtocolBytes or self.Frames >= FRAME_LIMIT:
            _fail("Budget", "publish", "ProtocolBytes", "shared transcript/frame allowance exhausted")
        self.ProtocolBytes += size
        self.Frames += 1


@dataclass(frozen=True, slots=True)
class ProjectionExchange:
    Request: Frame
    Native: CallObservation | None
    Certificate: CallObservation | None
    Response: Tree | None
    Failure: Failure | None


@dataclass(frozen=True, slots=True)
class _Services:
    Launch: Callable[..., object] = native.launch_native
    Certify: Callable[..., object] = reference.certify_native


def _store_bytes(store: records.Store, role: str, raw: bytes, budget: _Budget) -> records.Artifact:
    observed = _observe("append_bytes/" + role, lambda: records.append_bytes(store, role, raw), budget.Calls)
    if observed.Raised is not None or type(observed.Returned) is not records.Stored:
        _fail("Storage", "publish", role, "actual record-store refusal or raised outcome retained")
    return observed.Returned.Artifact


def _retained_public(value: object, store: records.Store, role: str, budget: _Budget, cap: int) -> object:
    observed = _observe("encode_public_result/" + role, lambda: encoding.encode_public_result(value, maximum_bytes=cap), budget.Calls)
    if observed.Raised is not None or type(observed.Returned) is not admission.Admitted:
        _fail("Storage", "publish", role, "complete actual return remains in memory after encoding refusal")
    raw = observed.Returned.value
    if type(raw) is not bytes:
        _fail("Unexpected", "publish", role, "encoder returned an untyped byte record")
    _store_bytes(store, role, raw, budget)
    return _json(raw, cap)


def _request_input(request: Frame, bindings: Mapping[str, str]) -> tuple[bytes, str, str]:
    value = request.Value
    if value["Kind"] != "ProjectionRequest":
        _fail("Admission", "project", "Kind", "actual projection request required")
    sha = _hash(value["InputSha256"], "InputSha256")
    case = _id(value["CaseId"], "CaseId")
    encoded = value["RawInputHex"]
    if type(encoded) is not str or len(encoded) > 2 * native.INPUT_CAP or re.fullmatch(r"(?:[0-9a-fA-F]{2})*", encoded) is None:
        _fail("Admission", "project", "RawInputHex", "bounded whole-byte hex input required")
    raw = bytes.fromhex(encoded)
    if _sha(raw) != sha:
        _fail("Conflict", "project", "InputSha256", "request input hash mismatch")
    inputs = _keys(_json(raw, native.INPUT_CAP), {"Schema", "Id", "Parameters", "Profile"}, "NativeInput")
    if inputs["Schema"] != "zeta.precision-projection.input.v1" or inputs["Id"] != case or inputs["Profile"] != "default":
        _fail("Conflict", "project", "NativeInput", "unchanged scalar schema/default profile and case identity required")
    parameters = _keys(inputs["Parameters"], {"T", "U", "K", "C"}, "Parameters")
    bits = _keys(value["TargetBits"], {"T", "U", "K", "C"}, "TargetBits")
    for name in ("T", "U", "K", "C"):
        _round_trip(parameters[name], bits[name], name)
    base = _keys(value["Base"], {"PrecisionMean", "Precision"}, "Base")
    precision = _bits(base["Precision"], "Base.Precision")
    eta = _bits(base["PrecisionMean"], "Base.PrecisionMean")
    if precision <= 0 or _bits(bits["C"], "C") <= 0 or base["Precision"] != bits["T"]:
        _fail("Improper", "project", "Base", "proper matching base precision and positive C required")
    mean = eta / precision
    if not math.isfinite(mean) or struct.pack(">d", mean).hex().upper() != bits["U"]:
        _fail("Conflict", "project", "U", "actual represented base quotient mismatch")
    binding_raw = _canonical(dict(bindings), native.INPUT_CAP)
    if value["BindingsSha256"] != _sha(binding_raw):
        _fail("Conflict", "project", "BindingsSha256", "independent binding identity mismatch")
    return raw, sha, case


def _projection(
    request: Frame,
    prepared: native.PreparedNative,
    bindings: Mapping[str, str],
    service_sha256: str,
    attempt_root: Path,
    store: records.Store,
    budget: _Budget,
    retained: list[ProjectionExchange],
    services: _Services = _Services(),
) -> Tree:
    native_call: CallObservation | None = None
    certificate_call: CallObservation | None = None
    native_tree: object = None
    certificate_tree: object = None
    failure: Failure | None = None
    response: Tree | None = None
    try:
        budget.check()
        raw, sha, case = _request_input(request, bindings)
        if budget.NativeCallEntered >= budget.Reservation.Projections:
            _fail("Budget", "project", "NativeCallEntered", "pre-reserved projection count exhausted")
        budget.NativeCallEntered += 1
        native_call = _observe(
            "launch_native",
            lambda: services.Launch(prepared, raw, sha, case, bindings, attempt_root, timeout_seconds=30),
            budget.Calls,
        )
        if native_call.Raised is not None:
            budget.RemoteIncomplete.add("NativeLaunchAttempted")
            _fail("Service", "project", "Native", "native API raised; actual observation retained")
        budget.NativeReturned += 1
        actual = native_call.Returned
        if type(actual) is not native.NativeObservation:
            budget.RemoteIncomplete.add("NativeLaunchAttempted")
            _fail("Unexpected", "project", "Native", "native API returned an unexpected value")
        if type(actual.LaunchAttempted) is not bool:
            budget.RemoteIncomplete.add("NativeLaunchAttempted")
            _fail("Unexpected", "project", "Native.LaunchAttempted", "typed actual launch count required")
        budget.NativeLaunchAttempted += int(actual.LaunchAttempted)
        native_tree = _retained_public(actual, store, "native-return", budget, 6 * MIB)
        budget.check()
        if actual.Complete is not True or type(actual.Receipt) is not bytes:
            _fail("Service", "project", "Native", "native process did not return a complete admitted receipt")
        if budget.CertificateEntered >= 32:
            _fail("Budget", "project", "CertificateEntered", "certificate-entry allowance exhausted")
        budget.CertificateEntered += 1
        certificate_call = _observe(
            "certify_native",
            lambda: services.Certify(raw, actual.Receipt, bindings, expected_input_sha256=sha, expected_case_id=case),
            budget.Calls,
        )
        if certificate_call.Raised is not None:
            budget.RemoteIncomplete.add("NestedReferenceEntered")
            _fail("Service", "project", "Certificate", "certificate API raised; actual native return retained")
        budget.CertificateReturned += 1
        certificate = certificate_call.Returned
        receipt: object = None
        if type(certificate) is reference.Success:
            receipt = certificate.Value
        elif type(certificate) is reference.ReceiptFailure:
            receipt = certificate.Receipt
        elif type(certificate) is not reference.Failure:
            budget.RemoteIncomplete.add("NestedReferenceEntered")
            _fail("Unexpected", "project", "Certificate", "certificate API returned an unexpected value")
        if type(receipt) is dict:
            counters = receipt.get("Counters")
            if type(counters) is not dict or type(counters.get("ReferenceRootCalls")) is not int or not 0 <= counters["ReferenceRootCalls"] <= 1:
                budget.RemoteIncomplete.add("NestedReferenceEntered")
                _fail("Unexpected", "project", "NestedReferenceEntered", "actual nested-entry count unavailable")
            budget.NestedReferenceEntered += counters["ReferenceRootCalls"]
        elif type(certificate) is not reference.Failure:
            budget.RemoteIncomplete.add("NestedReferenceEntered")
            _fail("Unexpected", "project", "Certificate", "complete typed reference receipt required")
        published_certificate = _retained_public(certificate, store, "certificate-return", budget, 6 * MIB)
        if type(certificate) is reference.ReceiptFailure:
            _fail("Storage", "publish", "Certificate", "actual ReceiptFailure retained; no encoded certificate claimed")
        certificate_tree = published_certificate
        budget.check()
    except _Stop as error:
        failure = error.failure
    except Exception as error:  # noqa: BLE001 - retain actual service returns on later boundary failure.
        failure = Failure("Unexpected", "project", None, type(error).__name__)
    finally:
        response = {
            "Kind": "ProjectionResponse", "Schema": SCHEMA,
            "SessionId": request.Value["SessionId"], "Sequence": request.Value["Sequence"],
            "RequestId": request.Value["RequestId"], "InputSha256": request.Value["InputSha256"],
            "BindingsSha256": request.Value["BindingsSha256"], "ServiceSha256": service_sha256,
            "Native": native_tree, "Certificate": certificate_tree,
            "Failure": None if failure is None else {
                "Code": failure.Code, "Stage": failure.Stage,
                "Field": failure.Field, "Message": failure.Message,
            },
        }
        retained.append(ProjectionExchange(request, native_call, certificate_call, response, failure))
    return response
