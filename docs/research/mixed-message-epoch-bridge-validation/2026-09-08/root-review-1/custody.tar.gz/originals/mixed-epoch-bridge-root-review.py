import hashlib,json,pathlib,subprocess,tarfile
root=pathlib.Path(__file__).resolve().parent.parent
folder=root/'docs/research/mixed-message-epoch-bridge-validation/2026-09-08/checkpoint-1'
manifest=json.loads((folder/'manifest.json').read_text())
archive=folder/manifest['Archive']['File'];raw=archive.read_bytes()
if len(raw)!=manifest['Archive']['Bytes'] or hashlib.sha256(raw).hexdigest().upper()!=manifest['Archive']['Sha256']: raise RuntimeError('archive identity differs')
records=manifest['Records'];names=[r['Name'] for r in records]
if len(names)!=len(set(names)): raise RuntimeError('duplicate manifest member')
checks=[]
with tarfile.open(archive,'r:gz') as tar:
    members=tar.getmembers()
    if len(members)!=len(records) or [m.name for m in members]!=names: raise RuntimeError('archive inventory differs')
    for member,row in zip(members,records,strict=True):
        if not member.isfile(): raise RuntimeError('nonregular archive member')
        handle=tar.extractfile(member)
        if handle is None: raise RuntimeError('missing member')
        value=handle.read()
        if len(value)!=row['Bytes'] or hashlib.sha256(value).hexdigest().upper()!=row['Sha256']: raise RuntimeError('member identity differs:'+member.name)
        checks.append({'Name':member.name,'Bytes':len(value),'IdentityMatches':True})
sources=[]
for row in manifest['SourceFiles']:
    result=subprocess.run(['git','show',manifest['SourceCommit']+':'+row['Path']],cwd=root,capture_output=True,check=False)
    value=result.stdout
    if result.returncode!=0 or len(value)!=row['Bytes'] or hashlib.sha256(value).hexdigest().upper()!=row['Sha256']: raise RuntimeError('pinned source identity differs')
    current=(root/row['Path']).read_bytes()
    if current!=value: raise RuntimeError('imported source differs')
    sources.append({'Path':row['Path'],'Bytes':len(value),'Sha256':row['Sha256'],'GitAndImportedBytesMatch':True})
print(json.dumps({'Scope':'Read-only archive and exact imported source audit; no source execution, numerical callback or test rerun','SourceCommit':manifest['SourceCommit'],'SourceFiles':sources,'ArchiveBytes':len(raw),'ArchiveSha256':manifest['Archive']['Sha256'],'MemberCount':len(checks),'OriginalBytes':sum(row['Bytes'] for row in checks),'EveryMemberMatches':True,'HistoricalOriginalPathsFollowed':False,'Members':checks},indent=2))
