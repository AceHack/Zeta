from pathlib import Path
import ast,json,typing
from zeta_interp import mixed_message_epoch_bridge as bridge
from zeta_interp import precision_gate_projection_reference as reference
root=Path.cwd(); source=root/'src/Interp.Python/tests/test_mixed_message_epoch_bridge.py'
tree=ast.parse(source.read_text()); function=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_manifest_fixture')
namespace={'bridge':bridge,'reference':reference,'Any':typing.Any}
exec(compile(ast.Module(body=[function],type_ignores=[]),str(source),'exec'),namespace)
results=[]
for path in ('extra/'+('x'*257), 'extra/\nmodule.py', 'extra/\x7fmodule.py'):
    value=namespace['_manifest_fixture']()
    value['SourceFiles'].append({'Path':path,'Bytes':1,'Sha256':'A'*64})
    value['SourceFiles'].sort(key=lambda row:row['Path'])
    value['ExpectedBindings'][path]='A'*64
    raw=bridge._canonical(value,64*1024)
    actual=bridge.admit_service_manifest(raw,bridge._sha(raw))
    results.append({'Path':path,'RawHex':raw.hex(),'ActualType':type(actual).__qualname__,'ActualRepresentation':repr(actual),'Refused':isinstance(actual,bridge.Failure)})
print(json.dumps({'Scope':'pure local manifest admission; no file or service operation','Results':results},ensure_ascii=True))
raise SystemExit(0 if all(row['Refused'] for row in results) else 1)
