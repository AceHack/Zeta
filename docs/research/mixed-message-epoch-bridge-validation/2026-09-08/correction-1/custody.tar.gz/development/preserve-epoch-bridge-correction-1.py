from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import stat
import subprocess
import tarfile

root = Path.cwd()
private = root / '.git'
out = root / 'docs/research/mixed-message-epoch-bridge-validation/2026-09-08/correction-1'
source_commit = '4402be8a7121f2f1609d4a7213d7ba7d3e3e65ee'
counter_commit = '0e0369a22ca9bf1687addf2d328ef82b0d22bdf5'
initial_commit = '8e1fe19a074368c3fd48f5f6cb871b1ce5d6b141'
source_paths = [
    'src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py',
    'src/Interp.Python/zeta_interp/mixed_message_epoch_controls.py',
    'src/Interp.Python/tests/test_mixed_message_epoch_bridge.py',
]
selected_names = [
    'epoch-bridge-remote-count-before-1',
    'epoch-bridge-remote-count-after-1',
    'epoch-bridge-prior-work-before-1',
    'epoch-bridge-remote-count-final-tests-1',
    'epoch-bridge-remote-count-final-checks-1',
    'epoch-bridge-remote-count-format-1.log',
    'epoch-bridge-remote-source-commit-message.txt',
    'epoch-bridge-remote-source-commit.log',
    'epoch-bridge-repository-gate-2',
    'epoch-bridge-binding-path-before-1',
    'epoch-bridge-binding-path-format-1.log',
    'epoch-bridge-correction-final-tests-1',
    'epoch-bridge-correction-final-checks-1',
    'epoch-bridge-path-source-commit-message.txt',
    'epoch-bridge-path-source-commit.log',
    'epoch-bridge-repository-gate-3',
    'epoch-bridge-normal-push-1.log',
    'epoch-bridge-normal-push-1-remote.txt',
    'epoch-bridge-normal-push-1-status.txt',
    'epoch-peer-foundation-review-draft.md',
    'epoch-peer-foundation-review-source-1',
    'run-epoch-checks.py',
    'run-epoch-development.py',
    'run-epoch-repository-gate-2.py',
    'run-epoch-repository-gate-3.py',
    'preserve-epoch-bridge-correction-1.py',
]

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

def js(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode()

def git_raw(commit, path):
    return subprocess.run(['git', 'show', commit + ':' + path], check=True, capture_output=True).stdout

def require(condition, message):
    if not condition:
        raise ValueError(message)

for number in (2, 3):
    for command in (1, 2):
        result = json.loads((private / f'epoch-bridge-repository-gate-{number}' / f'{command}-completion.json').read_bytes())
        require(result['ExitCode'] == 0, 'repository gate not completed successfully')
source = []
for name in source_paths:
    raw = (root / name).read_bytes()
    require(raw == git_raw(source_commit, name), 'final committed source mismatch')
    for folder in ('epoch-bridge-correction-final-tests-1', 'epoch-bridge-correction-final-checks-1', 'epoch-bridge-repository-gate-3'):
        require(raw == (private / folder / Path(name).name).read_bytes(), 'final capture source mismatch: ' + folder)
    old = git_raw(counter_commit, name)
    for folder in ('epoch-bridge-remote-count-final-tests-1', 'epoch-bridge-remote-count-final-checks-1', 'epoch-bridge-repository-gate-2'):
        require(old == (private / folder / Path(name).name).read_bytes(), 'counter capture source mismatch: ' + folder)
    source.append({'Path': name, 'Bytes': len(raw), 'Sha256': sha(raw)})
bridge_path = source_paths[0]
require(git_raw(initial_commit, bridge_path) == (private / 'epoch-bridge-remote-count-before-1/mixed_message_epoch_bridge.py').read_bytes(), 'initial discriminator source mismatch')
require(git_raw(counter_commit, bridge_path) == (private / 'epoch-bridge-binding-path-before-1/mixed_message_epoch_bridge.py').read_bytes(), 'path discriminator source mismatch')

files = []
nodes = []
def observe(path):
    mode = path.lstat().st_mode
    name = 'development/' + str(path.relative_to(private))
    row = {'Name': name, 'Mode': stat.S_IMODE(mode)}
    if stat.S_ISLNK(mode):
        row.update(Kind='symlink', Target=os.readlink(path))
    elif stat.S_ISDIR(mode):
        row['Kind'] = 'directory'
    elif stat.S_ISREG(mode):
        row['Kind'] = 'regular'
        files.append((name, path, path.read_bytes()))
    else:
        raise ValueError('unexpected file kind ' + str(path))
    nodes.append(row)
    return stat.S_ISDIR(mode)

for name in selected_names:
    selected = private / name
    if observe(selected):
        for directory, dirs, names in os.walk(selected, followlinks=False):
            dirs.sort()
            for child in dirs + sorted(names):
                observe(Path(directory) / child)
for name in source_paths:
    files.append(('source/' + name, root / name, (root / name).read_bytes()))
node_raw = js(nodes)
files.append(('lstat-inventory.json', None, node_raw))
require(len({row[0] for row in files}) == len(files), 'duplicate archive path')
archive = io.BytesIO()
records = []
with gzip.GzipFile(fileobj=archive, mode='wb', mtime=0, filename='') as zipped:
    with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name, original, raw in files:
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(raw))
            records.append({'Name': name, 'Bytes': len(raw), 'Sha256': sha(raw), 'OriginalLocalFile': None if original is None else str(original)})
archive_raw = archive.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive_raw), mode='r:gz') as tar:
    members = tar.getmembers()
    require([row.name for row in members] == [row['Name'] for row in records], 'archive order mismatch')
    for member, record in zip(members, records, strict=True):
        stream = tar.extractfile(member)
        require(member.isfile() and stream is not None, 'nonregular archive member')
        raw = stream.read()
        require(len(raw) == record['Bytes'] and sha(raw) == record['Sha256'], 'stored identity mismatch')
        if record['OriginalLocalFile'] is not None:
            require(Path(record['OriginalLocalFile']).read_bytes() == raw, 'original changed during preservation')
manifest = {
    'Schema': 'zeta.mixed-epoch.bridge-correction-custody.v1',
    'SourceCommit': source_commit,
    'CounterCorrectionCommit': counter_commit,
    'InitialSourceCommit': initial_commit,
    'SourceFiles': source,
    'Archive': {'File': 'custody.tar.gz', 'Bytes': len(archive_raw), 'Sha256': sha(archive_raw)},
    'OriginalBytes': sum(row['Bytes'] for row in records),
    'Records': records,
    'FilesystemInventory': {'Name': 'lstat-inventory.json', 'Bytes': len(node_raw), 'Sha256': sha(node_raw)},
    'Notes': [
        'Regular original files only; directory and symlink metadata retained without following targets.',
        'OriginalLocalFile is a historical locator, not a new input instruction.',
        'The PriorWork discriminator binds its exact intermediate source snapshot, not the original initial source commit.',
        'This preserver stdout is outside the explicit selected roster.',
        'Repository gates include existing numerical unit/model tests; named M4/M5 and frozen nested-query routes were not run.',
    ],
}
gates = []
for number in (2, 3):
    directory = private / f'epoch-bridge-repository-gate-{number}'
    gates.append({'Gate': number, 'SourceCommit': counter_commit if number == 2 else source_commit,
                  'Commands': [{'Invocation': json.loads((directory / f'{i}-invocation.json').read_bytes()),
                                'Completion': json.loads((directory / f'{i}-completion.json').read_bytes())} for i in (1, 2)]})
summary = {'ArchiveMembers': len(records), 'OriginalBytes': manifest['OriginalBytes'], 'Archive': manifest['Archive'],
           'SourceFiles': source, 'FilesystemNodes': len(nodes), 'SymlinksRecorded': sum(row['Kind'] == 'symlink' for row in nodes),
           'AllMembersAndOriginalsMatched': True, 'BothFinalSourceCutsEqualTheirThreeCaptures': True,
           'RepositoryGates': gates}
out.mkdir(parents=True, exist_ok=False)
(out / 'custody.tar.gz').write_bytes(archive_raw)
(out / 'manifest.json').write_bytes(js(manifest))
(out / 'observation.json').write_bytes(js(summary))
print(json.dumps(summary, indent=2))
