import json, os, pathlib, subprocess, sys, time
root=pathlib.Path.cwd(); out=root/'.git'/sys.argv[1]; out.mkdir()
paths=['src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py','src/Interp.Python/tests/test_mixed_message_epoch_bridge.py']
for name in paths:
 p=root/name; (out/p.name).write_bytes(p.read_bytes())
controls=root/'src/Interp.Python/zeta_interp/mixed_message_epoch_controls.py'
if controls.exists(): (out/controls.name).write_bytes(controls.read_bytes())
python='/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906/src/Interp.Python/.venv/bin/python'
args=[python,'-m','pytest','-q',paths[1],'-p','no:cacheprovider','--basetemp',str(out/'owned'),*sys.argv[2:]]
env={'PYTHONPATH':str(root/'src/Interp.Python'),'PYTHONDONTWRITEBYTECODE':'1'}
(out/'invocation.json').write_text(json.dumps({'Argv':args,'Cwd':str(root),'EnvironmentOverrides':env})+'\n')
start=time.monotonic()
with (out/'stdout').open('wb') as stdout, (out/'stderr').open('wb') as stderr:
 r=subprocess.run(args,env=os.environ|env,stdout=stdout,stderr=stderr)
(out/'completion.json').write_text(json.dumps({'ExitCode':r.returncode,'ElapsedSeconds':time.monotonic()-start})+'\n')
print((out/'stdout').read_text()); print((out/'stderr').read_text()); sys.exit(r.returncode)
