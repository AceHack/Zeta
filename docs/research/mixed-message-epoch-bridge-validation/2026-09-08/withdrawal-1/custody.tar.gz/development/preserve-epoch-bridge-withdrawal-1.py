from pathlib import Path
import gzip
import hashlib
import io
import json
import os
import stat
import subprocess
import tarfile

root = Path.cwd()
private = root / '.git'
out = root / 'docs/research/mixed-message-epoch-bridge-validation/2026-09-08/withdrawal-1'
source_commit = '567a9f004cf67b9df6d4a82c55fadaaf4fdd0b9b'
original_commit = '4402be8a7121f2f1609d4a7213d7ba7d3e3e65ee'
clarification_commit = '87bc6b28aa1d0ef780accf592b99ce70a16283e6'
source_paths = [
    'src/Interp.Python/zeta_interp/mixed_message_epoch_bridge.py',
    'src/Interp.Python/zeta_interp/mixed_message_epoch_controls.py',
    'src/Interp.Python/tests/test_mixed_message_epoch_bridge.py',
    'docs/research/2026-09-08-mixed-message-withdrawal-admission-clarification.md',
]
selected_names = [
    'epoch-bridge-withdrawal-before-1',
    'epoch-bridge-withdrawal-manifest-before-1',
    'epoch-bridge-withdrawal-after-1',
    'epoch-bridge-withdrawal-final-tests-1',
    'epoch-bridge-withdrawal-final-checks-1',
    'epoch-bridge-withdrawal-final-tests-2',
    'epoch-bridge-withdrawal-final-checks-2',
    'epoch-bridge-withdrawal-format-1.log',
    'epoch-bridge-withdrawal-source-commit-message.txt',
    'epoch-bridge-withdrawal-source-commit.log',
    'epoch-withdrawal-doc-fetch-1.log',
    'epoch-bridge-repository-gate-4',
    'epoch-bridge-normal-push-2.log',
    'epoch-bridge-normal-push-2-remote.txt',
    'epoch-bridge-normal-push-2-status.txt',
    'run-epoch-checks.py',
    'run-epoch-development.py',
    'run-epoch-repository-gate-4.py',
    'preserve-epoch-bridge-withdrawal-1.py',
]

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

def js(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode()

def git_raw(commit, path):
    return subprocess.run(['git', 'show', commit + ':' + path], check=True, capture_output=True).stdout

def require(condition, message):
    if not condition:
        raise ValueError(message)

for i in (1, 2):
    completion = json.loads((private / 'epoch-bridge-repository-gate-4' / f'{i}-completion.json').read_bytes())
    require(completion['ExitCode'] == 0, 'repository command not complete successfully')
source = []
for name in source_paths:
    raw = (root / name).read_bytes()
    require(raw == git_raw(source_commit, name), 'final Git source mismatch')
    if name.endswith('.py'):
        for folder in ('epoch-bridge-withdrawal-final-tests-2', 'epoch-bridge-withdrawal-final-checks-2', 'epoch-bridge-repository-gate-4'):
            require(raw == (private / folder / Path(name).name).read_bytes(), 'final source capture mismatch: ' + folder)
    else:
        require(raw == git_raw(clarification_commit, name), 'root clarification import changed')
    source.append({'Path': name, 'Bytes': len(raw), 'Sha256': sha(raw)})
for folder in ('epoch-bridge-withdrawal-before-1', 'epoch-bridge-withdrawal-manifest-before-1'):
    require(git_raw(original_commit, source_paths[0]) == (private / folder / Path(source_paths[0]).name).read_bytes(), 'original bridge discriminator changed')
files = []
nodes = []

def observe(path):
    mode = path.lstat().st_mode
    name = 'development/' + str(path.relative_to(private))
    row = {'Name': name, 'Mode': stat.S_IMODE(mode)}
    if stat.S_ISLNK(mode):
        row.update(Kind='symlink', Target=os.readlink(path))
    elif stat.S_ISDIR(mode):
        row['Kind'] = 'directory'
    elif stat.S_ISREG(mode):
        row['Kind'] = 'regular'
        files.append((name, path, path.read_bytes()))
    else:
        raise ValueError('unexpected file kind ' + str(path))
    nodes.append(row)
    return stat.S_ISDIR(mode)

for name in selected_names:
    selected = private / name
    if observe(selected):
        for directory, dirs, names in os.walk(selected, followlinks=False):
            dirs.sort()
            for child in dirs + sorted(names):
                observe(Path(directory) / child)
for name in source_paths:
    files.append(('source/' + name, root / name, (root / name).read_bytes()))
node_raw = js(nodes)
files.append(('lstat-inventory.json', None, node_raw))
require(len({row[0] for row in files}) == len(files), 'duplicate archive path')
archive = io.BytesIO()
records = []
with gzip.GzipFile(fileobj=archive, mode='wb', mtime=0, filename='') as zipped:
    with tarfile.open(fileobj=zipped, mode='w', format=tarfile.PAX_FORMAT) as tar:
        for name, original, raw in files:
            info = tarfile.TarInfo(name)
            info.size = len(raw)
            info.mode = 0o644
            info.mtime = 0
            tar.addfile(info, io.BytesIO(raw))
            records.append({'Name': name, 'Bytes': len(raw), 'Sha256': sha(raw), 'OriginalLocalFile': None if original is None else str(original)})
archive_raw = archive.getvalue()
with tarfile.open(fileobj=io.BytesIO(archive_raw), mode='r:gz') as tar:
    members = tar.getmembers()
    require([row.name for row in members] == [row['Name'] for row in records], 'archive order mismatch')
    for member, record in zip(members, records, strict=True):
        stream = tar.extractfile(member)
        require(member.isfile() and stream is not None, 'nonregular archive member')
        raw = stream.read()
        require(len(raw) == record['Bytes'] and sha(raw) == record['Sha256'], 'stored identity mismatch')
        if record['OriginalLocalFile'] is not None:
            require(Path(record['OriginalLocalFile']).read_bytes() == raw, 'original changed during preservation')
manifest = {
    'Schema': 'zeta.mixed-epoch.bridge-withdrawal-custody.v1',
    'SourceCommit': source_commit,
    'OriginalSourceCommit': original_commit,
    'ClarificationCommit': clarification_commit,
    'SourceFiles': source,
    'Archive': {'File': 'custody.tar.gz', 'Bytes': len(archive_raw), 'Sha256': sha(archive_raw)},
    'OriginalBytes': sum(row['Bytes'] for row in records),
    'Records': records,
    'FilesystemInventory': {'Name': 'lstat-inventory.json', 'Bytes': len(node_raw), 'Sha256': sha(node_raw)},
    'Notes': [
        'Regular originals only; symlink targets remain passive lstat metadata.',
        'OriginalLocalFile is a historical locator, not a new input instruction.',
        'Compensation controls are inert plan-admission payloads, not actual retained runtime history.',
        'This preserver stdout is outside the explicit selected roster.',
        'Repository gates include existing numerical unit/model tests; registered actual M4/M5 and nested query were not run.',
    ],
}
directory = private / 'epoch-bridge-repository-gate-4'
commands = [{'Invocation': json.loads((directory / f'{i}-invocation.json').read_bytes()),
             'Completion': json.loads((directory / f'{i}-completion.json').read_bytes())} for i in (1, 2)]
summary = {'ArchiveMembers': len(records), 'OriginalBytes': manifest['OriginalBytes'], 'Archive': manifest['Archive'],
           'SourceFiles': source, 'FilesystemNodes': len(nodes), 'SymlinksRecorded': sum(row['Kind'] == 'symlink' for row in nodes),
           'AllMembersAndOriginalsMatched': True, 'FinalPythonSourceEqualsAllThreeCaptures': True,
           'ClarificationEqualsOriginalRootGitBytes': True, 'RepositoryCommands': commands}
out.mkdir(parents=True, exist_ok=False)
(out / 'custody.tar.gz').write_bytes(archive_raw)
(out / 'manifest.json').write_bytes(js(manifest))
(out / 'observation.json').write_bytes(js(summary))
print(json.dumps(summary, indent=2))
