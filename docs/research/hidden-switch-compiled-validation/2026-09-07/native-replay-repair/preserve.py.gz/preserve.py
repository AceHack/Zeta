from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();source=root/'.git/compiled-native-replay-repair';dest=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/native-replay-repair';dest.mkdir(exist_ok=False)
v=json.loads((source/'validation.json').read_bytes());pin=v['SourceCommit'];assert pin=='e4946ec091981ccbd3057eb568d56069e79df4f2'
m={'SourceCommit':pin,'Scope':'43 independent Python calls and31 supplied native report comparisons; no new native launches or combined source/runtime admission','SourceFiles':[],'NativeBoundarySources':[],'Artifacts':[],'OriginalNativeInputs':'../native-replay-inputs/manifest.json','NewNativeLaunches':0,'RegisteredSourceGeneration':False}
def add(name,raw):
 packed=gzip.compress(raw,mtime=0)
 with (dest/(name+'.gz')).open('xb') as f:f.write(packed)
 m['Artifacts'].append({'File':name+'.gz','Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'Encoding':'gzip','StoredBytes':len(packed),'StoredSha256':hashlib.sha256(packed).hexdigest().upper()})
for row in v['CapturedPublicResults']:
 raw=(source/row['File']).read_bytes();assert len(raw)==row['Bytes'] and hashlib.sha256(raw).hexdigest().upper()==row['Sha256']
for path in sorted({row['File'] for row in v['ObservedLoadedSources']}|{'src/Interp.Python/tests/test_hidden_switch_compiled_native_replay.py'}):
 raw=subprocess.check_output(['git','show',pin+':'+path]);assert raw==(root/path).read_bytes();m['SourceFiles'].append({'File':path,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
parent=Path('/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906');native='34b4395175cd58ee2caba179e6061e54521673f6'
for name in ('HiddenSwitchCompiledCertificate.fs','HiddenSwitchCompiledCertificateCheck.fs','HiddenSwitchCompiledReceipt.fs'):
 path='src/Research.FSharp/'+name;raw=subprocess.check_output(['git','show',native+':'+path],cwd=parent);add('native-boundary-'+name,raw);m['NativeBoundarySources'].append({'SourceCommit':native,'File':path,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'Snapshot':'native-boundary-'+name+'.gz'})
for p in sorted(source.iterdir()):
 if p.is_file():add(p.name,p.read_bytes())
for row in m['Artifacts']:
 stored=(dest/row['File']).read_bytes();raw=gzip.decompress(stored);assert len(stored)==row['StoredBytes'] and hashlib.sha256(stored).hexdigest().upper()==row['StoredSha256'];assert len(raw)==row['Bytes'] and hashlib.sha256(raw).hexdigest().upper()==row['Sha256']
(dest/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print(json.dumps({'Artifacts':len(m['Artifacts']),'SourcePins':len(m['SourceFiles']),'NativeBoundaryPins':len(m['NativeBoundarySources']),'OriginalArtifactBytes':sum(x['Bytes'] for x in m['Artifacts']),'CaptureReferences':len(v['CapturedPublicResults'])}))
