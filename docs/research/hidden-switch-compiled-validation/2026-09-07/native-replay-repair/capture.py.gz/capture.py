from pathlib import Path
import dataclasses,hashlib,json,runpy,subprocess,sys
root=Path.cwd();out=root/'.git/compiled-native-replay-repair';sys.path.insert(0,str(root/'src/Interp.Python'))
from zeta_interp import hidden_switch_compiled_native_fixtures as fixtures
from zeta_interp import hidden_switch_compiled_native_replay as replay
from zeta_interp import hidden_switch_compiled_record_encoding as encoder
from zeta_interp import hidden_switch_compiled_admission as a
from zeta_interp import hidden_switch_compiled_ieee as s
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source=='e4946ec091981ccbd3057eb568d56069e79df4f2'
helpers=runpy.run_path(str(root/'src/Interp.Python/tests/test_hidden_switch_compiled_native_replay.py'))
supplied=helpers['supplied'].__wrapped__()
validation={'Schema':'zeta.hidden-switch.compiled.native-replay-implementation-validation.v1','SourceCommit':source,'PythonExecutable':sys.executable,'PythonVersion':sys.version,'Scope':'fixed native-dependent pure replay implementation capture; mixed placeholder fixture binding maps, no combined source/runtime admission','CapturedPublicResults':[],'Runs':[],'NewNativeLaunches':0,'RegisteredSourceGeneration':False,'StandalonePolicyRuns':0}
def save(name,value,maximum=32*1024*1024):
 actual=encoder.encode_public_result(value,maximum_bytes=maximum);assert isinstance(actual,a.Admitted),actual;raw=actual.value
 with (out/name).open('xb') as stream:stream.write(raw)
 row={'File':name,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()};validation['CapturedPublicResults'].append(row);return raw
prep=fixtures.prepare_native_fixtures(**{k:v for k,v in supplied.items() if k!='native_evidence'});assert isinstance(prep,s.Success),prep
cases=[];producer_python=0;native_requests=0
for case_index,case in enumerate(prep.value.Cases):
 calls=[]
 for call_index,spec in enumerate(case.Calls):
  actual=fixtures.dispatch_native_fixture(prep.value,case.CaseId,call_index)
  save(f'producer-{case_index:02d}-{call_index}.json',actual)
  if isinstance(actual,fixtures.NativeCallPending):
   native_requests+=1
   original=helpers['decoded'](supplied['native_evidence'][case_index].RawReport)
   raw=helpers['raw']({k:original[k] for k in ('InputSha256','BindingsSha256','Outcome')})
  else:
   assert isinstance(actual,fixtures.Dispatched),actual;producer_python+=1
   result=encoder.encode_public_result(actual.Call.Result,maximum_bytes=replay.MAX_RESULT_BYTES);assert isinstance(result,a.Admitted),result;raw=result.value
  calls.append(replay.RecordedCall(spec.Operation,spec.InputRoles,raw))
 cases.append(replay.RecordedCase(case.CaseId,case.ControlId,case.Inputs,tuple(calls)))
assert (producer_python,native_requests)==(43,31)
records=tuple(cases);save('recorded-cases.json',records);save('independent-native-evidence.json',supplied['native_evidence'])
for name,evidence in [('complete',supplied['native_evidence']),('pending',None),('missing-native-final',supplied['native_evidence'][:-1])]:
 given={**supplied,'native_evidence':evidence}
 actual=replay.replay_native_cases(records,**given);save(name+'-replay.json',actual)
 validation['Runs'].append({'Name':name,'Type':type(actual).__name__,'Counts':dataclasses.asdict(actual.Counts),'Failure':dataclasses.asdict(actual.Failure) if isinstance(actual,replay.NativeReplayFailed) else None})
 if name=='complete':assert isinstance(actual,replay.NativeReplayCompleted) and actual.Counts.PythonReturned==43 and actual.Counts.NativeCompared==31
 elif name=='pending':assert isinstance(actual,replay.NativeReplayPending) and actual.Counts.PythonReturned==43 and actual.Counts.NativePending==31
 else:assert isinstance(actual,replay.NativeReplayFailed) and actual.Counts.PythonReturned==31 and actual.Counts.NativeCompared==30
validation['UnchangedOriginalReplayBytes'] = []
for name in ('complete', 'pending', 'missing-native-final'):
 original=(root/'.git/compiled-native-replay-development'/(name+'-replay.json')).read_bytes()
 repaired=(out/(name+'-replay.json')).read_bytes()
 assert repaired==original
 validation['UnchangedOriginalReplayBytes'].append({'Name':name,'Bytes':len(original),'Sha256':hashlib.sha256(original).hexdigest().upper()})
original_dispatch=fixtures.dispatch_native_fixture
try:
 for name in ('normal-dispatch-refusal','malformed-nested-call'):
  if name=='normal-dispatch-refusal':
   fixtures.dispatch_native_fixture=lambda *args: fixtures.DispatchFailure('owned-injected','normal return retained','fixture','certificate/baseline',0)
  else:
   def malformed(*args):
    actual=original_dispatch(*args);assert isinstance(actual,fixtures.Dispatched)
    return dataclasses.replace(actual,Call=None)
   fixtures.dispatch_native_fixture=malformed
  actual=replay.replay_native_cases(records,**supplied);save(name+'-replay.json',actual)
  assert isinstance(actual,replay.NativeReplayFailed)
  assert (actual.Counts.PythonStarted,actual.Counts.PythonReturned,actual.Counts.PythonMatched)==(1,1,0)
  validation['Runs'].append({'Name':name,'Type':type(actual).__name__,'Counts':dataclasses.asdict(actual.Counts),'Failure':dataclasses.asdict(actual.Failure),'Intervention':'owned dispatch fixture replacement; no completed scientific operation'})
finally:
 fixtures.dispatch_native_fixture=original_dispatch
validation['ProducerPythonReturns']=producer_python;validation['ProducerPendingNativeRequests']=native_requests
observed=[]
for name,module in sorted(sys.modules.items()):
 if not name.startswith('zeta_interp.hidden_switch_compiled_'):continue
 p=Path(module.__file__).resolve();assert p.is_relative_to(root)
 relative=p.relative_to(root).as_posix();raw=p.read_bytes();assert raw==subprocess.check_output(['git','show',source+':'+relative])
 observed.append({'Module':name,'File':relative,'AbsolutePath':str(p),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
validation['ObservedLoadedSources']=observed
with (out/'validation.json').open('x') as stream:json.dump(validation,stream,indent=2);stream.write('\n')
print(json.dumps({'ProducerPythonReturns':producer_python,'PendingNativeRequests':native_requests,'Runs':validation['Runs'],'CapturedPublicResults':len(validation['CapturedPublicResults']),'ObservedSources':len(observed)}))
