from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[1]
source = '8d50ae0b8c6d45eb58d6fc4e5a29693381fc9ecb'
base = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/transfer-shapes-whitespace-preparation'
base.mkdir()
pins = []
for name in ['hidden_switch_transfer_shapes.py', 'test_hidden_switch_transfer_shapes.py', 'inspect_hidden_switch_calls.py']:
    path = 'src/Research.FSharp.Cli/' + name
    raw = (root / path).read_bytes()
    assert raw == subprocess.check_output(['git', 'show', source + ':' + path], cwd=root)
    pins.append({'File': path, 'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest().upper()})
records = []
for path in [root / ('.git/hidden-switch-transfer-shapes-' + name) for name in ['whitespace-1.log', 'whitespace-2.log', 'whitespace-ruff.log']] + [Path(__file__).resolve()]:
    raw = path.read_bytes(); stored = gzip.compress(raw, mtime=0)
    target = base / (path.name + '.gz')
    target.write_bytes(stored)
    records.append({'File': target.name, 'OriginalLocalFile': str(path.relative_to(root)), 'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest().upper(), 'StoredBytes': len(stored), 'StoredSha256': hashlib.sha256(stored).hexdigest().upper(), 'Encoding': 'gzip'})
(base / 'manifest.json').write_text(json.dumps({'SourceCommit': source, 'OriginalSourceCommit': '8d5b846be553f2578b6474d8a4083213a6e9d908', 'SourcePins': pins, 'Finding': 'Whitespace-only instruction text reached split()[0] and raised IndexError instead of ValueError.', 'FirstTestOutcome': {'Tests': 1, 'Errors': 2}, 'FinalTests': 20, 'Ruff': 'passed', 'Records': records, 'RuntimeAdmitted': False, 'BodyResolved': False, 'ClosureAdmitted': False}, indent=2) + '\n')
print(json.dumps({'SourceCommit': source, 'Records': len(records), 'SourcePins': pins}))
