from pathlib import Path
import gzip
import hashlib
import json

root = Path(__file__).resolve().parents[1]
hash_of = lambda raw: hashlib.sha256(raw).hexdigest().upper()
attempt = root / '.git/hidden-switch-data-proposal-attempt-2'
report = json.loads((attempt / 'outcome.json').read_bytes())
raw_proposal = (attempt / 'proposal.json').read_bytes()
proposal = json.loads(raw_proposal)
completion = json.loads((root / '.git/hidden-switch-data-proposal-attempt-2-completion.json').read_bytes())
assert report['Complete'] is True and report['Failure'] is None and report['CleanupFailures'] == [] and report['InputsUnchanged'] is True
assert len(raw_proposal) == 87278 and hash_of(raw_proposal) == '7A30217E5686294E1FFD02593703D5E7348C1A528A7BB88620BB83373E745D07'
assert report['Proposal'] == proposal and len(proposal['Ranges']) == 53 and proposal['Bytes'] == 496
assert all(report[key] is False for key in ['RuntimeAdmitted', 'BodyResolved', 'ClosureAdmitted', 'RawDumpOpened', 'ObservedExecution'])
assert report['NewMemoryQueries'] == report['SourceDraws'] == 0
assert completion['ExitCode'] == 0 and completion['DirectChildClosed'] is True and completion['CleanupFailures'] == [] and completion['OuterFailure'] is None
assert completion['SourcePinsUnchanged'] is True
assert len(report['Inputs']) == 266 and len(report['Sources']) == 14 and len(report['CompletedMethods']) == 130
base = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/data-proposal-attempt-2'
base.mkdir()
names = ['hidden-switch-data-proposal-attempt-2-invocation.json', 'hidden-switch-data-proposal-attempt-2-completion.json',
         'hidden-switch-data-proposal-attempt-2.stdout.log', 'hidden-switch-data-proposal-attempt-2.stderr.log',
         'hidden-switch-data-proposal-launcher-attempt-2-tool-stdout.log', 'hidden-switch-data-proposal-launcher-attempt-2-tool-stderr.log',
         'hidden-switch-data-proposal-attempt-2-summary.json', 'run-data-proposal-attempt-2.py', Path(__file__).name]
paths = sorted(attempt.iterdir()) + [root / '.git' / name for name in names]
records = []
for path in paths:
    raw = path.read_bytes(); stored = gzip.compress(raw, mtime=0); destination = base / (path.name + '.gz')
    with destination.open('xb') as stream:
        stream.write(stored)
    assert gzip.decompress(destination.read_bytes()) == raw
    records.append({'File': destination.name, 'OriginalLocalFile': str(path.relative_to(root)), 'Bytes': len(raw),
                    'Sha256': hash_of(raw), 'StoredBytes': len(stored), 'StoredSha256': hash_of(stored), 'Encoding': 'gzip'})
manifest = {'SourceCommit': 'a80211d357d548d97caf850f367543abfbf91638', 'ExecutionHead': 'af6c1935c5240097b459d0508e204609d60855d7',
            'Scope': 'One completed metadata-only53-range proposal; no physical dump/range/target/decoder/source-stream query. All full admission flags remain false.',
            'Summary': json.loads((root / '.git/hidden-switch-data-proposal-attempt-2-summary.json').read_bytes()), 'Records': records}
with (base / 'manifest.json').open('x') as stream:
    json.dump(manifest, stream, indent=2); stream.write('\n')
print(json.dumps({'Records': len(records), 'OriginalBytes': sum(row['Bytes'] for row in records),
                  'StoredBytes': sum(row['StoredBytes'] for row in records), 'ManifestBytes': (base / 'manifest.json').stat().st_size,
                  'ManifestSha256': hash_of((base / 'manifest.json').read_bytes())}))
