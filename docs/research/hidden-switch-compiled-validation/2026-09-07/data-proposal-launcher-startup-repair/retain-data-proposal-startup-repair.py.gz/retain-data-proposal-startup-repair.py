from pathlib import Path
import gzip
import hashlib
import json

root = Path(__file__).resolve().parents[1]
hash_of = lambda raw: hashlib.sha256(raw).hexdigest().upper()
expected = {'run-data-proposal-attempt-2.py': '741927F2980759CF50DEBDBB561D9BF801B673D63F64DE67CF603CD062577FFF',
            'test-data-proposal-launcher-startup.py': '05BB15DDD6B308880B651BFEDD697D33FE781280DE3EDB0544AB54E04426EA63'}
for name, digest in expected.items():
    assert hash_of((root / '.git' / name).read_bytes()) == digest
base = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/data-proposal-launcher-startup-repair'
base.mkdir()
names = ['run-data-proposal-attempt-2-before-preparation-pin.py', 'test-data-proposal-launcher-startup-before-preparation-pin.py',
         'hidden-switch-data-proposal-launcher-startup-tests-1.log', 'run-data-proposal-attempt-2.py',
         'test-data-proposal-launcher-startup.py', 'hidden-switch-data-proposal-launcher-startup-tests-2.log',
         'hidden-switch-data-proposal-pre-retry-preservation-check.json', Path(__file__).name]
records = []
for name in names:
    path = root / '.git' / name; raw = path.read_bytes(); stored = gzip.compress(raw, mtime=0)
    destination = base / (name + '.gz')
    with destination.open('xb') as stream:
        stream.write(stored)
    assert gzip.decompress(destination.read_bytes()) == raw
    records.append({'File': destination.name, 'OriginalLocalFile': str(path.relative_to(root)), 'Bytes': len(raw),
                    'Sha256': hash_of(raw), 'StoredBytes': len(stored), 'StoredSha256': hash_of(stored), 'Encoding': 'gzip'})
manifest = {'SourceCommit': 'a80211d357d548d97caf850f367543abfbf91638',
            'Scope': 'Guarded pre-child identity prefix and explicit 32MiB Python image limit; exact preparation manifest binding. Original inspected draft and8 fixtures remain distinct from final9 exact-function fixtures. No metadata child or range query has run during this repair.',
            'ReviewedSourceIdentities': expected, 'Records': records}
with (base / 'manifest.json').open('x') as stream:
    json.dump(manifest, stream, indent=2); stream.write('\n')
print(json.dumps({'Records': len(records), 'OriginalBytes': sum(row['Bytes'] for row in records),
                  'StoredBytes': sum(row['StoredBytes'] for row in records), 'ManifestSha256': hash_of((base / 'manifest.json').read_bytes())}))
