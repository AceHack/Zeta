"""Execute only the exact launcher's extracted cleanup/publication functions, never its child path."""
import ast
import contextlib
import io
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'src/Research.FSharp.Cli'))
from inventory_hidden_switch_transfers import encode, exclusive_bytes, failure
from hidden_switch_retained_artifacts import regular_bytes, sha, strict_json

source = (root / '.git/run-data-proposal-attempt-2.py').read_bytes()
tree = ast.parse(source)
functions = [node for node in tree.body if isinstance(node, ast.FunctionDef)]
assert {node.name for node in functions} == {'identity', 'cleanup_owned', 'finish_owned', 'publish_completion', 'preflight', 'main'}
scope = {'Path': Path, 'encode': encode, 'exclusive_bytes': exclusive_bytes, 'failure': failure,
         'regular_bytes': regular_bytes, 'sha': sha, 'strict_json': strict_json, 'root': root,
         'source': 'a80211d357d548d97caf850f367543abfbf91638', 'time': time, 'sys': sys,
         'os': os, 'subprocess': subprocess, 'utc': lambda: 'fixture-utc'}
exec(compile(ast.Module(body=functions, type_ignores=[]), 'retained-launcher-functions', 'exec'), scope)


class LaunchFixtures(unittest.TestCase):
    def test_changed_sixteen_pin_preparation_is_retained_and_refused_before_git_or_child(self):
        original_path = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/data-proposal-wrapper-preparation/manifest.json'
        prepared = json.loads(original_path.read_bytes())
        alternate = root / 'src/Research.FSharp.Cli/test_inspect_hidden_switch_calls.py'
        raw = alternate.read_bytes()
        prepared['SourcePins'][0] = {'File': str(alternate.relative_to(root)), 'Bytes': len(raw), 'Sha256': sha(raw)}
        self.assertEqual(len({pin['File'] for pin in prepared['SourcePins']}), 16)
        changed = json.dumps(prepared).encode()
        with tempfile.TemporaryDirectory() as directory, contextlib.redirect_stdout(io.StringIO()):
            fixture_base = Path(directory) / 'retained'; manifest = fixture_base / 'data-proposal-wrapper-preparation/manifest.json'
            manifest.parent.mkdir(parents=True); manifest.write_bytes(changed)
            prefix = Path(directory) / 'attempt'
            with patch.dict(scope, {'base': fixture_base, 'prefix': prefix}), \
                    patch.object(subprocess, 'Popen') as child, patch.object(subprocess, 'check_output') as git:
                self.assertEqual(scope['main'](), 2)
                child.assert_not_called(); git.assert_not_called()
            report = json.loads(Path(str(prefix) + '-completion.json').read_bytes())
            self.assertEqual(report['AvailablePrefix']['Preparation'], {'File': str(manifest), 'Bytes': len(changed), 'Sha256': sha(changed)})
            self.assertEqual(report['AvailablePrefix']['ObservedSourcePins'], [])
            self.assertEqual(report['OuterFailure']['Detail'], 'exact preparation manifest identity differs')

    def test_explicit_runtime_bound_admits_observed_size_and_refuses_larger_sparse_file(self):
        with tempfile.TemporaryDirectory() as directory:
            runtime = Path(directory) / 'runtime'
            with runtime.open('xb') as stream:
                stream.truncate(18090720)
            with self.assertRaises(ValueError):
                scope['identity'](runtime)
            self.assertEqual(scope['identity'](runtime, 32 * 1024 * 1024)['Bytes'], 18090720)
            with runtime.open('r+b') as stream:
                stream.truncate(32 * 1024 * 1024 + 1)
            with self.assertRaises(ValueError):
                scope['identity'](runtime, 32 * 1024 * 1024)

    def test_early_runtime_identity_refusal_retains_actual_source_prefix_without_child(self):
        with tempfile.TemporaryDirectory() as directory, contextlib.redirect_stdout(io.StringIO()):
            prefix = Path(directory) / 'attempt'
            file = Path(directory) / 'observed-source.py'; file.write_bytes(b'actual fixture source')
            observed = scope['identity'](file)
            def early(state):
                state['ObservedSourcePins'].append(observed)
                state['Locator'] = {'Stage': 'python-identity', 'File': '/fixture/runtime'}
                raise ValueError('bounded runtime identity refusal')
            with patch.dict(scope, {'prefix': prefix, 'preflight': early}), patch.object(subprocess, 'Popen') as child:
                self.assertEqual(scope['main'](), 2)
                child.assert_not_called()
            report = json.loads(Path(str(prefix) + '-completion.json').read_bytes())
            self.assertEqual(report['AvailablePrefix']['ObservedSourcePins'], [observed])
            self.assertEqual(report['OuterFailure']['Stage'], 'python-identity')
            self.assertEqual(report['OuterFailure']['Detail'], 'bounded runtime identity refusal')
            self.assertFalse(report['DirectChildClosed'])
            self.assertIsNone(report['ProcessId'])
            self.assertFalse(Path(str(prefix) + '-invocation.json').exists())

    def test_startup_deadline_refuses_before_spawning_a_child(self):
        with tempfile.TemporaryDirectory() as directory, contextlib.redirect_stdout(io.StringIO()):
            prefix = Path(directory) / 'attempt'
            with patch.dict(scope, {'prefix': prefix, 'preflight': lambda _: ['never-run']}), \
                    patch.object(time, 'monotonic', side_effect=[0, 61, 62]), patch.object(subprocess, 'Popen') as child:
                self.assertEqual(scope['main'](), 2)
                child.assert_not_called()
            report = json.loads(Path(str(prefix) + '-completion.json').read_bytes())
            self.assertEqual(report['OuterFailure']['Stage'], 'metadata-child-launch')
            self.assertEqual(report['OuterFailure']['Code'], 'TimeoutError')

    def test_poll_and_kill_errors_do_not_skip_join_or_real_file_closes(self):
        events = []; errors = []
        class Child:
            def poll(self): events.append('poll'); raise OSError('poll refusal')
            def kill(self): events.append('kill'); raise OSError('kill refusal')
            def wait(self, timeout): events.append('join'); return 7
        class Stream:
            def __init__(self, file, name): self.file = file; self.name = name
            def close(self):
                events.append(self.name); self.file.close()
                raise OSError(self.name + ' after real close')
        with tempfile.TemporaryDirectory() as directory:
            files = [(Path(directory) / name).open('xb') for name in ['out', 'err']]
            streams = [Stream(file, name) for file, name in zip(files, ['out', 'err'], strict=True)]
            code, joined = scope['cleanup_owned'](Child(), streams, errors)
            self.assertEqual((code, joined), (7, True))
            self.assertTrue(all(file.closed for file in files))
        self.assertEqual(events, ['poll', 'kill', 'join', 'out', 'err'])
        self.assertEqual([row['Stage'] for row in errors], ['owned-child-poll', 'owned-child-kill', 'owned-output-close', 'owned-output-close'])

    def test_join_failure_still_closes_and_never_claims_closed(self):
        class Child:
            def poll(self): return 0
            def wait(self, timeout): raise TimeoutError('join refusal')
            def kill(self): raise AssertionError('already terminal')
        errors = []
        with tempfile.TemporaryDirectory() as directory:
            file = (Path(directory) / 'out').open('xb')
            self.assertEqual(scope['cleanup_owned'](Child(), [file], errors), (None, False))
            self.assertTrue(file.closed)
        self.assertEqual(errors[0]['Stage'], 'owned-child-join')

    def test_prior_actual_exit_is_retained_when_cleanup_join_refuses(self):
        class Child:
            def poll(self): return 7
            def wait(self, timeout): raise TimeoutError('later join refusal')
        errors = []
        actual = scope['finish_owned'](Child(), [], errors, 7)
        self.assertEqual(actual, {'ExitCode': 7, 'MainWaitExitCode': 7, 'CleanupWaitExitCode': None, 'DirectChildClosed': False})
        self.assertEqual(errors[0]['Detail'], 'later join refusal')

    def test_completed_write_then_failure_keeps_first_and_publishes_independently(self):
        first = failure('original', ValueError('first computation refusal'))
        report = {'OuterFailure': first, 'CleanupFailures': []}
        def write(path, raw):
            exclusive_bytes(path, raw)
            if path.name.endswith('-completion.json'):
                raise OSError('after completed original write')
        with tempfile.TemporaryDirectory() as directory, contextlib.redirect_stdout(io.StringIO()) as console:
            prefix = Path(directory) / 'attempt'
            with patch.dict(scope, {'exclusive_bytes': write}):
                actual = scope['publish_completion'](prefix, report)
            original = json.loads(Path(str(prefix) + '-completion.json').read_bytes())
            fallback = json.loads(Path(str(prefix) + '-completion-failed.json').read_bytes())
            self.assertEqual(original['OuterFailure'], first)
            self.assertNotIn('TerminalPublicationFailure', original)
            self.assertEqual(fallback['OuterFailure'], first)
            self.assertEqual(json.loads(console.getvalue()), actual)
            self.assertEqual(actual['TerminalPublicationFailure']['Detail'], 'after completed original write')

    def test_main_fallback_and_console_errors_preserve_first_in_last_independent_record(self):
        first = failure('original', ValueError('first failure'))
        def write(path, raw):
            if 'completion' in path.name:
                raise OSError(path.name)
            exclusive_bytes(path, raw)
        with tempfile.TemporaryDirectory() as directory:
            prefix = Path(directory) / 'attempt'
            with patch.dict(scope, {'exclusive_bytes': write}), patch('builtins.print', side_effect=OSError('console refusal')) as console:
                actual = scope['publish_completion'](prefix, {'OuterFailure': first, 'CleanupFailures': []})
                self.assertIs(console.call_args.kwargs['flush'], True)
            retained = json.loads(Path(str(prefix) + '-console-failed.json').read_bytes())
            self.assertEqual(actual, retained)
            self.assertEqual(retained['OuterFailure'], first)
            self.assertEqual(retained['ConsoleFailure']['Detail'], 'console refusal')
            self.assertIn('SecondaryPublicationFailure', retained)


if __name__ == '__main__':
    unittest.main()
