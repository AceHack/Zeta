"""One owned metadata-only child; exact source pins, first outcome and guarded cleanup."""
from pathlib import Path
import datetime
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'src/Research.FSharp.Cli'))
from hidden_switch_retained_artifacts import regular_bytes, sha, strict_json
from inventory_hidden_switch_transfers import encode, exclusive_bytes, failure

source = 'a80211d357d548d97caf850f367543abfbf91638'
base = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07'
attempt = root / '.git/hidden-switch-data-proposal-attempt-2'
prefix = root / '.git/hidden-switch-data-proposal-attempt-2'
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity(path, limit=4 * 1024 * 1024):
    raw = regular_bytes(path, limit)
    return {'File': str(path), 'Bytes': len(raw), 'Sha256': sha(raw)}

def cleanup_owned(child, streams, cleanup):
    code = None; joined = False; should_kill = True
    if child is not None:
        try:
            should_kill = child.poll() is None
        except Exception as error:
            cleanup.append(failure('owned-child-poll', error))
        if should_kill:
            try:
                child.kill()
            except Exception as error:
                cleanup.append(failure('owned-child-kill', error))
        try:
            code = child.wait(timeout=5); joined = True
        except Exception as error:
            cleanup.append(failure('owned-child-join', error))
    for stream in streams:
        try:
            stream.close()
        except Exception as error:
            cleanup.append(failure('owned-output-close', error))
    return code, joined

def finish_owned(child, streams, cleanup, observed_code):
    cleanup_code, joined = cleanup_owned(child, streams, cleanup)
    if observed_code is not None and cleanup_code is not None and observed_code != cleanup_code:
        cleanup.append(failure('owned-child-exit-disagreement', ValueError('observed child exit code changed')))
    return {'ExitCode': observed_code if observed_code is not None else cleanup_code,
            'MainWaitExitCode': observed_code, 'CleanupWaitExitCode': cleanup_code, 'DirectChildClosed': joined}

def publish_completion(prefix, completion):
    try:
        exclusive_bytes(Path(str(prefix) + '-completion.json'), encode(completion, 65536))
    except Exception as error:
        completion['TerminalPublicationFailure'] = failure('completion-publication', error)
        completion['OuterFailure'] = completion['OuterFailure'] or completion['TerminalPublicationFailure']
        try:
            exclusive_bytes(Path(str(prefix) + '-completion-failed.json'), encode(completion, 65536))
        except Exception as secondary:
            completion['SecondaryPublicationFailure'] = failure('secondary-completion-publication', secondary)
    try:
        print(encode(completion, 65536).decode('ascii'), end='', flush=True)
    except Exception as error:
        completion['ConsoleFailure'] = failure('completion-console', error)
        completion['OuterFailure'] = completion['OuterFailure'] or completion['ConsoleFailure']
        try:
            exclusive_bytes(Path(str(prefix) + '-console-failed.json'), encode(completion, 65536))
        except Exception as secondary:
            completion['SecondaryConsolePublicationFailure'] = failure('console-failure-publication', secondary)
    return completion

def preflight(state):
    state['Locator'] = {'Stage': 'preparation-read'}
    prep_path = base / 'data-proposal-wrapper-preparation/manifest.json'
    prep_raw = regular_bytes(prep_path, 512 * 1024)
    state['Preparation'] = {'File': str(prep_path), 'Bytes': len(prep_raw), 'Sha256': sha(prep_raw)}
    prep = strict_json(prep_raw)
    if prep['SourceCommit'] != source or len(prep['SourcePins']) != 16 or len({pin['File'] for pin in prep['SourcePins']}) != 16:
        raise ValueError('preparation source roster differs')
    state['SourcePins'] = prep['SourcePins']
    for pin in prep['SourcePins']:
        state['Locator'] = {'Stage': 'source-admission', 'File': pin['File']}
        parts = Path(pin['File']).parts
        if len(parts) != 3 or parts[:2] != ('src', 'Research.FSharp.Cli') or not parts[-1].endswith('.py'):
            raise ValueError('unexpected preparation source path')
        raw = regular_bytes(root / pin['File'], 256 * 1024)
        actual = {'File': pin['File'], 'Bytes': len(raw), 'Sha256': sha(raw)}
        state['ObservedSourcePins'].append(actual)
        if actual != pin or raw != subprocess.check_output(['git', 'show', source + ':' + pin['File']], cwd=root, timeout=10):
            raise ValueError('source bytes differ from pin or immutable commit')
    state['Locator'] = {'Stage': 'execution-head'}
    state['ExecutionHead'] = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True, timeout=10).strip()
    argv = [sys.executable, str(root / 'src/Research.FSharp.Cli/propose_hidden_switch_data_ranges.py'), str(base), str(attempt), source]
    state['Arguments'] = argv
    state['Locator'] = {'Stage': 'python-identity', 'File': str(Path(sys.executable).resolve())}
    state['PythonIdentityByteLimit'] = 32 * 1024 * 1024
    state['Python'] = identity(Path(sys.executable).resolve(), state['PythonIdentityByteLimit'])
    state['Locator'] = {'Stage': 'outer-harness-identity', 'File': str(Path(__file__).resolve())}
    state['OuterHarness'] = identity(Path(__file__).resolve())
    return argv


def main():
    child = None; streams = []; primary = None; cleanup = []; unchanged = False; started = time.monotonic(); pid = None; code = None
    state = {'SourceCommit': source, 'StartedAtUtc': utc(), 'WorkingDirectory': str(root), 'Locator': {'Stage': 'preparation-read'},
             'Preparation': None, 'SourcePins': [], 'ObservedSourcePins': [], 'PostlaunchSourcePins': [], 'ExecutionHead': None,
             'Arguments': None, 'Python': None, 'OuterHarness': None, 'TimeoutSeconds': 60, 'PolledStreamByteLimit': 65536,
             'RuntimeAdmitted': False, 'BodyResolved': False, 'ClosureAdmitted': False}
    try:
        argv = preflight(state)
        state['Locator'] = {'Stage': 'invocation-publication'}
        exclusive_bytes(Path(str(prefix) + '-invocation.json'), encode(state, 128 * 1024))
        state['Locator'] = {'Stage': 'owned-output-create'}
        for suffix in ['.stdout.log', '.stderr.log']:
            streams.append(Path(str(prefix) + suffix).open('xb'))
        state['Locator'] = {'Stage': 'metadata-child-launch'}
        if time.monotonic() - started >= 60:
            raise TimeoutError('guarded startup already exceeded sixty seconds; no child launched')
        child = subprocess.Popen(argv, cwd=root, stdout=streams[0], stderr=streams[1]); pid = child.pid
        state['Locator'] = {'Stage': 'metadata-child-wait'}
        while child.poll() is None:
            if time.monotonic() - started >= 60:
                raise TimeoutError('owned metadata child exceeded sixty seconds from guarded startup')
            if any(os.fstat(stream.fileno()).st_size > 65536 for stream in streams):
                raise ValueError('owned metadata output exceeded polled stream limit')
            time.sleep(0.01)
        code = child.wait(timeout=5)
        if any(os.fstat(stream.fileno()).st_size > 65536 for stream in streams):
            raise ValueError('closed metadata output exceeded stream limit')
        for pin in state['SourcePins']:
            state['Locator'] = {'Stage': 'postlaunch-source-identity', 'File': pin['File']}
            raw = regular_bytes(root / pin['File'], 256 * 1024)
            actual = {'File': pin['File'], 'Bytes': len(raw), 'Sha256': sha(raw)}
            state['PostlaunchSourcePins'].append(actual)
            if actual != pin:
                raise ValueError('source identity changed after metadata invocation')
        unchanged = True
    except Exception as error:
        primary = failure(state['Locator']['Stage'], error)
    finally:
        terminal = finish_owned(child, streams, cleanup, code)
        code = terminal['ExitCode']; joined = terminal['DirectChildClosed']
        completion = {'FinishedAtUtc': utc(), 'ElapsedSeconds': time.monotonic() - started, 'ProcessId': pid, **terminal,
                      'OuterFailure': primary, 'CleanupFailures': cleanup, 'SourcePinsUnchanged': unchanged, 'AvailablePrefix': state,
                      'PerTerminalChannelByteLimit': 65536,
                      'TerminalChannels': 'completion, independent failure file, bounded console, optional console-failure file'}
        completion = publish_completion(prefix, completion)
    return 0 if code == 0 and joined and unchanged and primary is None and not cleanup and completion['OuterFailure'] is None else 2


if __name__ == '__main__':
    sys.exit(main())
