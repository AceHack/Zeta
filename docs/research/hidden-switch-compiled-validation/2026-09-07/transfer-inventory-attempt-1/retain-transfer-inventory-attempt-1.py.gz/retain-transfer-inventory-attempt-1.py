from pathlib import Path
import collections
import gzip
import hashlib
import json

root=Path(__file__).resolve().parents[1]
source='370c110c93598874615efe60a5bed23ac6e5263d'
attempt=root/'.git/hidden-switch-transfer-inventory-attempt-1'
base=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/transfer-inventory-attempt-1'
base.mkdir()
report=json.loads((attempt/'outcome.json').read_text())
assert report['Complete'] is True and report['Failure'] is None and report['InputsUnchanged'] is True
assert report['Methods']==130 and report['Words']==8665 and report['CleanupFailures']==[]
assert all(report[key] is False for key in ['RuntimeAdmitted','BodyResolved','ClosureAdmitted','ObservedExecution','RawDumpOpened'])
assert report['NewMemoryQueries']==report['SourceDraws']==0
counts=collections.Counter();control=[];cells=[];literals=[];total=0
for row in report['CompletedMethods']:
 raw=(attempt/row['File']).read_bytes()
 assert len(raw)==row['Bytes'] and hashlib.sha256(raw).hexdigest().upper()==row['Sha256']
 method=json.loads(raw)
 assert method['Complete'] is True and method['UnconsumedLiteralDeclarations']==[]
 for word in method['Words']:
  total+=1;shape=word['Shape'];counts.update(shape['Unresolved']);control.extend(shape['Targets'])
  assert 'StructuralFailure' not in shape
  if shape['StaticCell']:cells.append(shape['StaticCell'])
  if shape['Literal']:literals.append(shape['Literal'])
  if any(target['Membership']=='outside-retained-code' for target in shape['Targets']):assert shape['Kind']=='call-direct'
summary={'Words':total,'Kinds':report['Kinds'],'UnresolvedReasons':dict(counts),'ControlTargetMembership':dict(collections.Counter(x['Membership'] for x in control)), 'StaticCellSites':len(cells),'KnownCellReuseSites':sum(x['PhysicalValueReused'] for x in cells),'DistinctStaticCellAddresses':len({x['Address'] for x in cells}),'UnknownStaticCellAddresses':len({x['Address'] for x in cells if not x['PhysicalValueReused']}),'LiteralWords':len(literals),'ExpectedLiteralBytes':sum(x['Bytes'] or 0 for x in literals),'DistinctLiteralAddresses':len({x['Address'] for x in literals}),'PhysicalLiteralsObserved':sum(x['PhysicalBinding'] for x in literals),'Unprepared':len(report['Unprepared']),'ExtraCompilerBlocks':len(report['ExtraCompilerBlocks']),'SelectedStoredInputs':sum(p['Kind']=='stored-record' for p in report['Inputs']),'OriginalInputBytes':sum(p['Bytes'] for p in report['Inputs'] if p['Kind'] in ['manifest','original-record']),'SourcePins':len(report['Sources']),'AllFullAdmissionFlagsFalse':True}
assert summary==json.loads((root/'.git/hidden-switch-transfer-inventory-attempt-1-summary.json').read_text())
completion=json.loads((root/'.git/hidden-switch-transfer-inventory-attempt-1-completion.json').read_text())
assert completion['ExitCode']==0 and completion['OuterFailure'] is None and completion['SourcePinsUnchanged'] is True
paths=sorted(attempt.iterdir())+[root/'.git'/name for name in ['run-transfer-inventory-attempt-1.py','hidden-switch-transfer-inventory-attempt-1-invocation.json','hidden-switch-transfer-inventory-attempt-1-completion.json','hidden-switch-transfer-inventory-attempt-1.stdout.log','hidden-switch-transfer-inventory-attempt-1.stderr.log','hidden-switch-transfer-inventory-attempt-1-summary.json']]+[Path(__file__).resolve()]
records=[]
for path in paths:
 raw=path.read_bytes();stored=gzip.compress(raw,mtime=0);destination=base/(path.name+'.gz')
 with destination.open('xb') as stream:stream.write(stored)
 assert gzip.decompress(destination.read_bytes())==raw
 records.append({'File':destination.name,'OriginalLocalFile':str(path.relative_to(root)),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper(),'Encoding':'gzip'})
result={'SourceCommit':source,'ExecutionHead':'ed95d32fcd01bc54e6c4c904baa68e8f83c792d5','Scope':'Complete finite retained-metadata transfer inventory, not execution/body/runtime/closure admission. No raw dump, new memory query, LLVM/target launch or registered source stream.','Summary':summary,'Records':records}
with (base/'manifest.json').open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
print(json.dumps({'Records':len(records),'OriginalBytes':sum(row['Bytes'] for row in records),'StoredBytes':sum(row['StoredBytes'] for row in records),'ManifestBytes':(base/'manifest.json').stat().st_size,'ManifestSha256':hashlib.sha256((base/'manifest.json').read_bytes()).hexdigest().upper()}))
