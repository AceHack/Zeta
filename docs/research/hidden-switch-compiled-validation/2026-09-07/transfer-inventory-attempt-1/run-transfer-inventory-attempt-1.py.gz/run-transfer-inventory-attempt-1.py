from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

root=Path(__file__).resolve().parents[1]
source='370c110c93598874615efe60a5bed23ac6e5263d'
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
base=root/'docs/research/hidden-switch-compiled-validation/2026-09-07'
prep=json.loads((base/'transfer-inventory-retention-preparation/manifest.json').read_text())
for pin in prep['SourcePins']:
 raw=(root/pin['File']).read_bytes()
 assert len(raw)==pin['Bytes'] and hashlib.sha256(raw).hexdigest().upper()==pin['Sha256']
 assert raw==subprocess.check_output(['git','show',source+':'+pin['File']],cwd=root)
argv=[sys.executable,str(root/'src/Research.FSharp.Cli/inventory_hidden_switch_transfers.py'),str(base),str(root/'.git/hidden-switch-transfer-inventory-attempt-1'),source]
identity=lambda p:{'File':str(p),'Bytes':p.stat().st_size,'Sha256':hashlib.sha256(p.read_bytes()).hexdigest().upper()}
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
invocation={'SourceCommit':source,'ExecutionHead':head,'Arguments':argv,'WorkingDirectory':str(root),'StartedAtUtc':start,'Python':identity(Path(sys.executable).resolve()),'OuterHarness':identity(Path(__file__).resolve()),'SourcePins':prep['SourcePins'],'RuntimeAdmitted':False,'BodyResolved':False,'ClosureAdmitted':False}
with (root/'.git/hidden-switch-transfer-inventory-attempt-1-invocation.json').open('x') as f:json.dump(invocation,f,indent=2);f.write('\n')
t0=time.monotonic();error=None;result=None
with (root/'.git/hidden-switch-transfer-inventory-attempt-1.stdout.log').open('xb') as out, (root/'.git/hidden-switch-transfer-inventory-attempt-1.stderr.log').open('xb') as err:
 try:
  result=subprocess.run(argv,cwd=root,stdout=out,stderr=err,timeout=60,check=False)
 except Exception as exc:
  error={'Code':type(exc).__name__,'Detail':str(exc)}
completion={'FinishedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ElapsedSeconds':time.monotonic()-t0,'ExitCode':None if result is None else result.returncode,'OuterFailure':error,'SourcePinsUnchanged':all(identity(root/pin['File'])['Bytes']==pin['Bytes'] and identity(root/pin['File'])['Sha256']==pin['Sha256'] for pin in prep['SourcePins'])}
with (root/'.git/hidden-switch-transfer-inventory-attempt-1-completion.json').open('x') as f:json.dump(completion,f,indent=2);f.write('\n')
print(json.dumps(completion))
