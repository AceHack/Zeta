from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys

root=Path(__file__).resolve().parents[1]
source='370c110c93598874615efe60a5bed23ac6e5263d'
sys.path.insert(0,str(root/'src/Research.FSharp.Cli'))
from inventory_hidden_switch_transfers import source_inventory
base=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/transfer-inventory-retention-preparation'
base.mkdir()
pins=source_inventory(root/'src/Research.FSharp.Cli')
for name in ['test_hidden_switch_transfer_inputs.py','test_inventory_hidden_switch_transfers.py']:
 raw=(root/'src/Research.FSharp.Cli'/name).read_bytes()
 pins.append({'File':name,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
for pin in pins:
 file='src/Research.FSharp.Cli/'+pin['File'];raw=(root/file).read_bytes()
 assert raw==subprocess.check_output(['git','show',source+':'+file],cwd=root)
 assert len(raw)==pin['Bytes'] and hashlib.sha256(raw).hexdigest().upper()==pin['Sha256']
 pin['File']=file
paths=[root/('.git/hidden-switch-transfer-inventory-'+name) for name in ['reserve-tests-1.log','reserve-ruff-1.log','retention-tests-1.log','retention-ruff-1.log','retention-combined-1.log']]
paths += [root/'.git'/name for name in ['transfer-inventory-retention-witness.py','transfer-inventory-retention-witness.json','transfer-inventory-retention-witness.stderr.log','hidden-switch-transfer-proposed-inputs.json']]+[Path(__file__).resolve()]
records=[]
for path in paths:
 raw=path.read_bytes();stored=gzip.compress(raw,mtime=0);dest=base/(path.name+'.gz')
 with dest.open('xb') as stream:stream.write(stored)
 records.append({'File':dest.name,'OriginalLocalFile':str(path.relative_to(root)),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper(),'Encoding':'gzip'})
report={'SourceCommit':source,'OriginalSourceCommit':'c97efff55ca56baa530e21c117527b8f2f4351ec','SourcePins':pins,'Records':records,'FinalFocusedCases':20,'FinalCombinedCases':69,'Ruff':'passed','Findings':[{'Attribution':'author found before reviewer independently issued same finding','Finding':'The aggregate budget reserved only the main outcome, omitting possible secondary failure and console bytes.'},{'Attribution':'independent reviewer','Finding':'A later source read/AST/checkpoint failure discarded earlier observed source hashes before source_inventory returned.'}],'WitnessScope':'Exact old c97 source, separately replayed after correction, on synthetic temporary files. Budget is accepted charge/accounting possibility, not an observed actual disk overflow. Source-prefix loss is an actual old function refusal with one completed instrumented read and empty returned Sources.','ProposedInputRosterScope':'Manifest-metadata-only planning check: 534 selected records, 7,164,913 total original bytes including manifests; not a full selected-record read/classification.','RuntimeAdmitted':False,'BodyResolved':False,'ClosureAdmitted':False}
with (base/'manifest.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps({'Records':len(records),'SourcePins':len(pins),'SourceCommit':source}))
