from pathlib import Path
import hashlib
import json
import subprocess
import sys
import tempfile
import types
from unittest.mock import patch

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'src/Research.FSharp.Cli'))
source = 'c97efff55ca56baa530e21c117527b8f2f4351ec'
file = 'src/Research.FSharp.Cli/inventory_hidden_switch_transfers.py'
raw = subprocess.check_output(['git','show',source+':'+file],cwd=root)
old = types.ModuleType('inventory_original_c97')
old.__file__ = str(root/file)
exec(compile(raw, source+':'+file, 'exec'), old.__dict__)
with tempfile.TemporaryDirectory() as fixture:
    path=Path(fixture)
    publisher=old.Publisher(path)
    try:
        cap=old.MAX_RECORD+32768+3
        with patch.object(old,'MAX_OUTPUT',cap):
            publisher.charge(b'x'*32771)
        budget={'DeclaredBytes':cap,'AcceptedPriorCharge':publisher.charged,'OutcomeBytes':old.MAX_RECORD,
                'SecondaryFailureBytes':16384,'BoundedConsoleBytes':16384,
                'PossibleTotalBytes':publisher.charged+old.MAX_RECORD+32768}
        assert budget['PossibleTotalBytes']>cap
    finally:publisher.close()
with tempfile.TemporaryDirectory() as fixture:
    path=Path(fixture); directory=path/'sources';directory.mkdir()
    first=b'from hidden_switch_missing import value\n'
    (directory/'inventory_hidden_switch_transfers.py').write_bytes(first)
    real_inventory=old.source_inventory; real_read=old.regular_bytes; observed=[]
    def read(name,limit):
        value=real_read(name,limit)
        observed.append({'File':str(name),'Bytes':len(value),'Sha256':hashlib.sha256(value).hexdigest().upper()})
        return value
    def inventory(_):
        with patch.dict(sys.modules,{'inventory_hidden_switch_transfers':None}), patch.object(old,'regular_bytes',read):
            return real_inventory(directory)
    with patch.object(old,'source_inventory',inventory):
        report=old.run(path,path/'attempt','0'*40)
    assert report['Sources']==[] and len(observed)==1 and report['Failure']['Code']=='FileNotFoundError'
    source_prefix={'ObservedReads':[{'File':Path(x['File']).name,**{k:x[k] for k in ['Bytes','Sha256']}} for x in observed],
                   'ReturnedSources':report['Sources'],'FailureCode':report['Failure']['Code'],'Complete':report['Complete']}
value={'Kind':'exact-old-source-synthetic-retention-witness','SourceCommit':source,'SourceFile':file,'SourceBytes':len(raw),
       'SourceSha256':hashlib.sha256(raw).hexdigest().upper(),'Budget':budget,'SourcePrefix':source_prefix,
       'Scope':'Synthetic writer-owned files and old pure collector functions only; no real inventory or decoder/dump/target/source stream.',
       'RuntimeAdmitted':False,'BodyResolved':False,'ClosureAdmitted':False}
print(json.dumps(value,indent=2))
