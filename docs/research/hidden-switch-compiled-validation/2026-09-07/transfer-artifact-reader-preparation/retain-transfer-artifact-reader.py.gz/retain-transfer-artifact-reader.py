from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parents[1]
source = 'e9d4c654da515097b13aa1d9f57f744155198ca9'
base = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/transfer-artifact-reader-preparation'
base.mkdir()
pins = []
for name in ['hidden_switch_retained_artifacts.py', 'test_hidden_switch_retained_artifacts.py']:
    file = 'src/Research.FSharp.Cli/' + name; raw = (root / file).read_bytes()
    assert raw == subprocess.check_output(['git', 'show', source + ':' + file], cwd=root)
    pins.append({'File': file, 'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest().upper()})
paths = [root / ('.git/hidden-switch-retained-artifacts-' + name) for name in ['tests-1.log','tests-2.log','tests-3.log','combined-1.log','combined-2.log','ruff-1.log','ruff-2.log','ruff-3.log','ruff-4.log','ruff-5.log']]
paths += [root / '.git/hidden-switch-retained-json-overflow-1.log', Path(__file__).resolve()]
records = []
for path in paths:
    raw = path.read_bytes(); stored = gzip.compress(raw, mtime=0); destination = base / (path.name + '.gz')
    with destination.open('xb') as stream: stream.write(stored)
    records.append({'File': destination.name, 'OriginalLocalFile': str(path.relative_to(root)), 'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest().upper(), 'StoredBytes': len(stored), 'StoredSha256': hashlib.sha256(stored).hexdigest().upper(), 'Encoding': 'gzip'})
value = {'SourceCommit': source, 'InitialSourceCommit': 'aef64955ea6401d6c52f3f4985f793b0bedaf18f', 'SourcePins': pins, 'Records': records, 'FinalFocusedCases': 13, 'FinalCombinedCases': 33, 'Ruff': 'passed', 'Finding': 'Default parse_float converted 1e400 and nested -1e400 to infinities; finite parse_float now refuses.', 'PreparationNotes': ['An initial root-cwd test command failed opening ../../.git output before Python ran. Corrected command ran from src/Research.FSharp.Cli.', 'Initial Ruff import-order/loop-binding and later fixture loop-binding/nested-with findings are retained; final clean source is pinned.', 'Earlier 10/12-case logs and initial 32-case combined pass describe evolving uncommitted snapshots; final focused13 and combined33 are distinct.'], 'RuntimeAdmitted': False, 'BodyResolved': False, 'ClosureAdmitted': False}
with (base / 'manifest.json').open('x') as stream: json.dump(value, stream, indent=2); stream.write('\n')
print(json.dumps({'Records':len(records),'SourceCommit':source}))
