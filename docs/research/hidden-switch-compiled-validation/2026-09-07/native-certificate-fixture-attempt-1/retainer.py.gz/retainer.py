from pathlib import Path
import gzip
import hashlib
import json

root = Path.cwd()
attempt = root / '.git/compiled-native-certificate-fixture-attempt-1'
dest = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/native-certificate-fixture-attempt-1'
result = json.loads((attempt / 'result.json').read_bytes())
assert result['Complete'] is True and result['Failure'] is None
assert len(result['Cases']) == 31 and all(x['ExitCode'] == 0 for x in result['Cases'])
assert sum(x['NativeOutcome']['Kind'] == 'accepted' for x in result['Cases']) == 1
assert sum(x['NativeOutcome']['Kind'] == 'refused' for x in result['Cases']) == 30
dest.mkdir(exist_ok=False)

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

inputs = [(str(p.relative_to(attempt)), p) for p in sorted(attempt.rglob('*')) if p.is_file()]
inputs += [('driver.py', root / '.git/run-native-certificate-fixture-1.py'),
           ('driver.stdout.log', root / '.git/compiled-native-certificate-fixture-1.stdout.log'),
           ('driver.stderr.log', root / '.git/compiled-native-certificate-fixture-1.stderr.log'),
           ('retainer.py', Path(__file__))]
artifacts = []
for name, original in inputs:
    raw = original.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    path = dest / (name + '.gz')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as output:
        output.write(stored)
    assert path.read_bytes() == stored and gzip.decompress(stored) == raw
    artifacts.append({'File': name + '.gz', 'Bytes': len(raw), 'Sha256': sha(raw),
                      'Encoding': 'gzip', 'StoredBytes': len(stored), 'StoredSha256': sha(stored)})
manifest = {'Schema': 'zeta.hidden-switch.compiled.native-certificate-fixture-preservation.v1',
            'NativeSourceCommit': result['NativeSourceCommit'],
            'CorpusSourceCommit': result['CorpusSourceCommit'],
            'StartedAtUtc': result['StartedAtUtc'], 'FinishedAtUtc': result['FinishedAtUtc'],
            'Cases': 31, 'Accepted': 1, 'Refused': 30, 'ExitCodes': [0] * 31,
            'Artifacts': artifacts, 'Scope': result['Scope']}
with (dest / 'manifest.json').open('x') as output:
    output.write(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'VerifiedArtifacts': len(artifacts), 'Cases': 31, 'Accepted': 1, 'Refused': 30,
                  'BinaryFiles': len(result['BinaryFilesBefore'])}))
