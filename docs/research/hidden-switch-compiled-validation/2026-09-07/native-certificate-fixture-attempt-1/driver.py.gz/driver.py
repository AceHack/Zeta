from datetime import UTC, datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess

from zeta_interp import hidden_switch_compiled_admission as a
from zeta_interp import hidden_switch_compiled_certificate_cases as cases

root = Path.cwd().parents[1]
fixture_root = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/certificate-cases'
dest = root / '.git/compiled-native-certificate-fixture-attempt-1'
dest.mkdir(exist_ok=False)
cli = Path('/Users/acehack/.zeta/agents/codex/Zeta-rendered-predictor-native-20260906/src/Research.FSharp.Cli/bin/Release/net10.0/Zeta.Research.HiddenSwitchCompiled.dll')
host = Path('/Users/acehack/.local/share/mise/dotnet-root/dotnet')
pins = {
    cli: (439808, '203F68A0B23157D6A07D7395DE00C8DD556E5D4E95C788DC15CB09EF1F922E77'),
    cli.with_suffix('.runtimeconfig.json'): (573, '8BE4ED4B6B8A41EB936189FEE1672D4E0AD91EDD88227E90464658C05E9598A0'),
    cli.with_suffix('.deps.json'): (12553, '16859052CFF9189BF0163E695B3B068C16DAB7A9F253DAC478042F1EFC8DAC80'),
}
def now():
    return datetime.now(UTC).isoformat()

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

def snapshot():
    files = sorted(set(cli.parent.glob('*.dll')) | set(pins) | {host})
    result = []
    for file in files:
        raw = file.read_bytes()
        if file in pins:
            assert (len(raw), sha(raw)) == pins[file], str(file)
        result.append({'File': str(file), 'ResolvedFile': str(file.resolve(strict=True)), 'Bytes': len(raw), 'Sha256': sha(raw)})
    return result

rows = []
failure = None
before = None
started = now()
delta = {'DOTNET_TieredCompilation': '0', 'DOTNET_TieredPGO': '0', 'DOTNET_ReadyToRun': '0'}
with (dest / 'events.jsonl').open('x') as journal:
    def retain(event):
        journal.write(json.dumps(event) + '\n')
        journal.flush()
        os.fsync(journal.fileno())
    retain({'Kind': 'start', 'StartedAtUtc': started, 'NativeSourceCommit': '34b4395175cd58ee2caba179e6061e54521673f6', 'EnvironmentDelta': delta})
    try:
        before = snapshot()
        retain({'Kind': 'binary-files-before', 'Files': before})
        fixture_raw = (fixture_root / 'cases.json').read_bytes()
        fixture_checked = a.strict_json(fixture_raw)
        assert isinstance(fixture_checked, a.Admitted), fixture_checked
        fixture = fixture_checked.value
        assert tuple(row['CaseId'] for row in fixture['Cases']) == cases.CASE_IDS
        binding_raw = (json.dumps(fixture['Bindings'], sort_keys=True, separators=(',', ':')) + '\n').encode()
        binding_path = dest / 'bindings.json'
        with binding_path.open('xb') as output:
            output.write(binding_raw)
        retain({'Kind': 'fixture', 'Bytes': len(fixture_raw), 'Sha256': sha(fixture_raw), 'BindingsSha256': sha(binding_raw)})
        for index, case in enumerate(fixture['Cases']):
            case_dir = dest / f'{index:02d}-{case["CaseId"]}'
            case_dir.mkdir(exist_ok=False)
            stored = (fixture_root / case['Input']['File']).read_bytes()
            raw = gzip.decompress(stored)
            checked = a.bind_artifact_bytes(case['Input'], stored, raw, case['CaseId'])
            assert isinstance(checked, a.Admitted), checked
            input_path = case_dir / 'input.json'
            output_path = case_dir / 'native.json'
            with input_path.open('xb') as output:
                output.write(raw)
            argv = [str(host), str(cli), 'certificate-check', str(binding_path), str(input_path), str(output_path)]
            call = {'Index': index, 'CaseId': case['CaseId'], 'Argv': argv, 'StartedAtUtc': now(), 'InputSha256': sha(raw)}
            retain({'Kind': 'case-enter', **call})
            with (case_dir / 'stdout.log').open('xb') as stdout, (case_dir / 'stderr.log').open('xb') as stderr:
                process = subprocess.run(argv, cwd=cli.parent, env={**os.environ, **delta}, stdout=stdout, stderr=stderr, timeout=30, check=False)
            call['ClosedAtUtc'] = now()
            call['ExitCode'] = process.returncode
            retain({'Kind': 'process-closed', **call})
            assert process.returncode == 0, call
            native_raw = output_path.read_bytes()
            parsed = a.strict_json(native_raw)
            assert isinstance(parsed, a.Admitted), parsed
            native = parsed.value
            assert native['Kind'] == 'certificate-verification'
            assert native['Complete'] is True and native['Failure'] is None
            assert type(native['VerifyCalls']) is int and native['VerifyCalls'] == 1
            assert type(native['SourceDraws']) is int and native['SourceDraws'] == 0
            assert native['RuntimeAdmitted'] is False and native['Runtime'] == '10.0.11'
            assert native['InputSha256'] == sha(raw) and native['BindingsSha256'] == sha(binding_raw)
            assert native['Arguments'] == argv[2:]
            assert Path(native['AssemblyFile']).resolve() == cli.resolve()
            assert native['AssemblySha256'] == pins[cli][1]
            actual = native['Outcome']
            if index == 0:
                assert set(actual) == {'Kind', 'NumericCertificateSha256'} and actual['Kind'] == 'accepted'
                assert actual['NumericCertificateSha256'] == fixture['BaselineSha256']
            else:
                assert set(actual) == {'Kind', 'Failure'} and actual['Kind'] == 'refused'
                refusal = actual['Failure']
                assert set(refusal) == {'Stage', 'Code', 'Detail', 'Panel', 'Mode', 'Strategy', 'Replicate', 'Episode', 'Call'}
                assert all(type(refusal[key]) is str and refusal[key] for key in ['Stage', 'Code', 'Detail'])
                assert all(refusal[key] is None for key in ['Panel', 'Mode', 'Strategy', 'Replicate', 'Episode', 'Call'])
            assert (actual['Kind'] == 'accepted') == case['Python']['Accepted']
            assert input_path.read_bytes() == raw and binding_path.read_bytes() == binding_raw
            row = {**call, 'NativeOutput': {'Bytes': len(native_raw), 'Sha256': sha(native_raw)},
                   'PythonOutcome': case['Python'], 'NativeOutcome': actual}
            rows.append(row)
            retain({'Kind': 'case-complete', **row})
        assert snapshot() == before, 'binary file identity changed across the fixed batch'
        retain({'Kind': 'binary-files-after', 'Unchanged': True})
    except Exception as error:
        failure = {'Stage': 'fixture-conformance', 'Type': type(error).__name__, 'Detail': str(error), 'CompletedCases': len(rows)}
        retain({'Kind': 'failure', 'Failure': failure})
    record = {'Schema': 'zeta.hidden-switch.compiled.native-certificate-fixture.v1',
              'StartedAtUtc': started, 'FinishedAtUtc': now(), 'Complete': failure is None, 'Failure': failure,
              'NativeSourceCommit': '34b4395175cd58ee2caba179e6061e54521673f6',
              'CorpusSourceCommit': '60eeb0b868b973298cb1c6f48044ee7172ada369',
              'EnvironmentDelta': delta, 'BinaryFilesBefore': before, 'Cases': rows,
              'Scope': '31 explicit placeholder-binding certificate inputs; actual verifier outcomes only; no full source/runtime/outer/hand admission or registered source generation'}
    with (dest / 'result.json').open('x') as output:
        output.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({'Complete': failure is None, 'CompletedCases': len(rows), 'Failure': failure}))
raise SystemExit(0 if failure is None else 1)
