from pathlib import Path
import gzip
import hashlib
import json
import subprocess
root=Path.cwd()
dest=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/binding-subjects'
dest.mkdir(exist_ok=False)
source='bdeb180c1dbc9766ec90e4f79941ce348995d605'
logs=[f'compiled-bindings-{kind}-{index}.log' for index in (1,2,3) for kind in ('format','ruff','mypy','tests')]
logs+=['compiled-bindings-style-fix-1.log']
inputs=[(name,root/'.git'/name) for name in logs]+[('retainer.py',Path(__file__))]
artifacts=[]
for name,path in inputs:
    raw=path.read_bytes();stored=gzip.compress(raw,mtime=0)
    with (dest/(name+'.gz')).open('xb') as out:out.write(stored)
    assert gzip.decompress(stored)==raw
    artifacts.append(dict(File=name+'.gz',Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper(),Encoding='gzip',StoredBytes=len(stored),StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
files=[]
for name in ['src/Interp.Python/zeta_interp/hidden_switch_compiled_bindings.py','src/Interp.Python/tests/test_hidden_switch_compiled_bindings.py']:
    raw=(root/name).read_bytes()
    assert raw==subprocess.check_output(['git','show',source+':'+name])
    files.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
with (dest/'manifest.json').open('x') as out:
    out.write(json.dumps(dict(Scope='shared whole-input binding and synthetic adapter validation; no final actual phase admission',SourceCommit=source,SourceFiles=files,Artifacts=artifacts),indent=2)+'\n')
print(json.dumps({'Artifacts':len(artifacts),'SourceFiles':len(files)}))
