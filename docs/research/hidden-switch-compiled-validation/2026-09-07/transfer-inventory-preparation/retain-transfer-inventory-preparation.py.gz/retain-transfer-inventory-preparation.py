from pathlib import Path
import gzip
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
source = 'c97efff55ca56baa530e21c117527b8f2f4351ec'
sys.path.insert(0, str(root / 'src/Research.FSharp.Cli'))
from inventory_hidden_switch_transfers import source_inventory
base = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/transfer-inventory-preparation'
base.mkdir()
pins = source_inventory(root / 'src/Research.FSharp.Cli')
for name in ['test_hidden_switch_transfer_inputs.py','test_inventory_hidden_switch_transfers.py']:
    raw=(root/'src/Research.FSharp.Cli'/name).read_bytes()
    pins.append({'File':name,'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper()})
for pin in pins:
    file = 'src/Research.FSharp.Cli/' + pin['File']; raw=(root/file).read_bytes()
    assert raw == subprocess.check_output(['git','show',source+':'+file],cwd=root)
    assert len(raw)==pin['Bytes'] and hashlib.sha256(raw).hexdigest().upper()==pin['Sha256']
    pin['File']=file
paths=[root/('.git/hidden-switch-transfer-inventory-'+name) for name in ['tests-1.log','tests-2.log','tests-3.log','combined-1.log','ruff-1.log','ruff-2.log','ruff-3.log']]+[Path(__file__).resolve()]
records=[]
for path in paths:
    raw=path.read_bytes();stored=gzip.compress(raw,mtime=0);destination=base/(path.name+'.gz')
    with destination.open('xb') as stream:stream.write(stored)
    records.append({'File':destination.name,'OriginalLocalFile':str(path.relative_to(root)),'Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper(),'Encoding':'gzip'})
value={'SourceCommit':source,'SourcePins':pins,'Records':records,'FinalFocusedCases':18,'FinalCombinedCases':67,'Ruff':'passed','FixtureScope':'Pure synthetic complete8665 NOP roster, actual archived method000 metadata/JIT mutation fixtures and failure retention; no full actual inventory, new memory query or decoder/target execution.','PreparationNotes':['Initial Ruff import ordering, unused imports and catch-boundary annotations retained; corrected source passes.','Earlier14/15-case logs reflect evolving uncommitted drafts; final18-case and67-case logs are distinct.','An early unexecuted draft treated RawDumpAndCustodyFiles as an array; direct metadata inspection showed its actual custody-description string. Final code binds LocalOnlyDump from the actual capture outcome and exact target-custody metadata.'], 'RuntimeAdmitted':False,'BodyResolved':False,'ClosureAdmitted':False}
with (base/'manifest.json').open('x') as stream:json.dump(value,stream,indent=2);stream.write('\n')
print(json.dumps({'SourceCommit':source,'Records':len(records),'SourcePins':len(pins)}))
