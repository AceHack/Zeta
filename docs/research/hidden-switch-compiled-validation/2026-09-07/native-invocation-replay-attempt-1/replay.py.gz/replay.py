from __future__ import annotations
import hashlib,json,subprocess,sys
from pathlib import Path
from dataclasses import asdict
from zeta_interp import hidden_switch_compiled_certificate as c
from zeta_interp import hidden_switch_compiled_ieee as s
from zeta_interp import hidden_switch_compiled_reference as r
from zeta_interp import hidden_switch_compiled_replay as strict
from zeta_interp import hidden_switch_compiled_falsifiers as f
root=Path(__file__).resolve().parents[2]
source=Path("/Users/acehack/.zeta/agents/codex/Zeta-rendered-predictor-native-20260906/.git/hidden-switch-compiled-invocations-attempt-1/invocations.json")
raw=source.read_bytes(); expected="9EBBC621583A24BF45DB3AD50F665CCD3EF3D4A7070004F9CDF4E58D705FD78D"
assert len(raw)==7457 and hashlib.sha256(raw).hexdigest().upper()==expected

def pairs(items):
 result={}
 for key,value in items:
  if key in result: raise ValueError("duplicate key")
  result[key]=value
 return result

def constant(value): raise ValueError("nonfinite")
def unwrap(value):
 if not isinstance(value,s.Success): raise ValueError(repr(value))
 return value.value

o=json.loads(raw.decode("utf-8"),object_pairs_hook=pairs,parse_constant=constant,parse_int=lambda x: -0.0 if x=="-0" else int(x))
bindings={"ProtocolSha256":c.PROTOCOL_SHA256,"hand-validation":"0"*64}
assert o["CertificateBindings"]==bindings
cert=unwrap(c.verify_certificate(unwrap(c.build_certificate(bindings)),bindings))
assert cert.NumericSha256==o["NumericCertificateSha256"]
checker=f._Checker()
checker.invocations(o["InvocationCases"],cert)
assert checker.completed==f.FalsifierCounts(InvocationCases=10,DelegateEntries=10,EvaluatorEntries=8)
assert len(checker.mutants)==2
w=o["SelectorWitness"]
strict._same({"Input":{"QBits":["0000000000000000",f"{cert.EpsilonBits:016X}"]},"ActualAction":0,"Mutation":{"Kind":"inclusive-epsilon-comparison","Action":1}},w,"SelectorWitness")
q=tuple(unwrap(s.parse_bits(x)) for x in w["Input"]["QBits"])
action=unwrap(r.select_bits(q))
strict._same(action,w["ActualAction"],"SelectorWitness.ActualAction")
try:
 strict._same(action,w["Mutation"]["Action"],"SelectorWitness.Mutation.Action")
except strict._Mismatch as mismatch:
 tie={"Code":mismatch.code,"Path":mismatch.path,"Message":mismatch.message}
else: raise ValueError("mutant was not refused")
assert source.read_bytes()==raw
result={"Schema":"zeta.hidden-switch.compiled.native-invocation-slice-replay.v1","Input":{"File":str(source),"Bytes":len(raw),"Sha256":expected},"ReferenceCommit":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),"PythonExecutable":sys.executable,"PythonVersion":sys.version,"NumericCertificateSha256":cert.NumericSha256,"CertificateBindings":bindings,"Completed":asdict(checker.completed),"MutantRefusals":[asdict(x) for x in checker.mutants],"SelectorActualAction":action,"SelectorMutantRefusal":tie,"Complete":True,"Scope":"actual native ten invocation rows and one supplied-Q witness only","FullFalsifierAdmission":"pending interventions/refusals/whole-hand","RuntimeAndOuterAdmission":"not-performed","RegisteredSourceGeneration":False,"InputUnchangedAfterReplay":True,"LoadedTaskSources":[{"Name":name,"File":str(Path(module.__file__).resolve()),"Sha256":hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest().upper()} for name,module in sorted(sys.modules.items()) if name.startswith("zeta_interp.hidden_switch") and getattr(module,"__file__",None)]}
print(json.dumps(result,indent=2,sort_keys=True))
