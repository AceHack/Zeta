from __future__ import annotations
import hashlib, json, subprocess, sys
from dataclasses import asdict
from pathlib import Path
from zeta_interp import hidden_switch_compiled_certificate as c
from zeta_interp import hidden_switch_compiled_ieee as s
from zeta_interp import hidden_switch_compiled_replay as replay
from zeta_interp import hidden_switch_compiled_old_replay as old

root=Path(__file__).resolve().parents[2]
source=Path("/Users/acehack/.zeta/agents/codex/Zeta-rendered-predictor-native-20260906/.git/hidden-switch-compiled-hand-core-attempt-1/hand-core.json")
raw=source.read_bytes()
expected="48965F2CD70C40047772DA7E87DD462734D5A371D059BD30C6E1D8C0BFA17D32"
assert len(raw)==447583 and hashlib.sha256(raw).hexdigest().upper()==expected

def pairs(items):
    result={}
    for key,value in items:
        if key in result: raise ValueError("duplicate key")
        result[key]=value
    return result

def constant(value): raise ValueError("nonfinite token")
def integer(value): return -0.0 if value=="-0" else int(value)
def unwrap(value):
    if not isinstance(value,s.Success): raise ValueError(repr(value))
    return value.value

payload=json.loads(raw.decode("utf-8"),object_pairs_hook=pairs,parse_int=integer,parse_constant=constant)
bindings={"ProtocolSha256":c.PROTOCOL_SHA256,"hand-validation":"0"*64}
assert payload["CertificateBindings"]==bindings
certificate=unwrap(c.verify_certificate(unwrap(c.build_certificate(bindings)),bindings))
assert certificate.NumericSha256==payload["NumericCertificateSha256"]
result={"Schema":"zeta.hidden-switch.compiled.native-slice-replay.v1","Input":{"File":str(source),"Bytes":len(raw),"Sha256":expected},"ReferenceCommit":subprocess.check_output(["git","rev-parse","HEAD"],cwd=root,text=True).strip(),"PythonExecutable":sys.executable,"PythonVersion":sys.version,"CertificateBindings":bindings,"NumericCertificateSha256":certificate.NumericSha256,"Scope":"actual native 222 scalar/48 new/24 old hand slices only","RuntimeAdmission":"not-performed","FullHandAdmission":"pending falsifiers/source/runtime","RegisteredSourceGeneration":False}
for name,fn,args in (("ScalarAndNewHand",replay.replay_scalar_and_new_hand,(payload["Payload"]["Scalars"],payload["Payload"]["Episodes"],certificate)),("OldControls",old.replay_old_hand,(payload["Payload"]["OldControls"],))):
    outcome=fn(*args)
    result[name]={"Kind":"success" if isinstance(outcome,s.Success) else "failure","Result":asdict(outcome.value if isinstance(outcome,s.Success) else outcome)}
assert source.read_bytes()==raw
result["InputUnchangedAfterReplay"]=True
result["Complete"]=all(result[name]["Kind"]=="success" for name in ("ScalarAndNewHand","OldControls"))
result["LoadedModules"]=[{"Name":name,"File":str(Path(module.__file__).resolve()),"Sha256":hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest().upper()} for name,module in sorted(sys.modules.items()) if name.startswith("zeta_interp.hidden_switch") and getattr(module,"__file__",None)]
print(json.dumps(result,indent=2,sort_keys=True))
