from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess
import zlib

root = Path.cwd()
origin = Path('/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906')
relative = Path('docs/research/hidden-switch-compiled-validation/2026-09-07/native-graph-attempt-5')
source = origin / relative
dest = root / relative
assert not dest.exists()
manifest_raw = (source / 'manifest.json').read_bytes()
manifest = json.loads(manifest_raw)
records = manifest['Records']
assert len(records) == 2550
assert set(p.name for p in source.iterdir()) == {r['StoredFile'] for r in records} | {'manifest.json'}
shutil.copytree(source, dest)
assert (dest / 'manifest.json').read_bytes() == manifest_raw
raw_total = stored_total = 0
for row in records:
    stored = (dest / row['StoredFile']).read_bytes()
    assert stored == (source / row['StoredFile']).read_bytes()
    assert row['Encoding'] == 'gzip'
    decoder = zlib.decompressobj(16 + zlib.MAX_WBITS)
    raw = decoder.decompress(stored) + decoder.flush()
    assert decoder.eof and not decoder.unused_data and not decoder.unconsumed_tail
    assert len(stored) == row['StoredBytes'] and hashlib.sha256(stored).hexdigest().upper() == row['StoredSha256']
    assert len(raw) == row['Bytes'] and hashlib.sha256(raw).hexdigest().upper() == row['Sha256']
    raw_total += len(raw)
    stored_total += len(stored)
assert raw_total == manifest['OriginalBytes'] == 10204700
assert stored_total == manifest['StoredBytes'] == 1753389
record = {'Schema': 'zeta.hidden-switch.compiled.capture-five-publication-verification.v1',
          'SourceCommit': manifest['SourceCommit'],
          'OriginalIntegrationCommit': subprocess.check_output(['git', '-C', str(origin), 'rev-parse', 'HEAD'], text=True).strip(),
          'Records': len(records), 'OriginalBytes': raw_total, 'StoredBytes': stored_total,
          'ManifestBytes': len(manifest_raw), 'ManifestSha256': hashlib.sha256(manifest_raw).hexdigest().upper(),
          'AllFilesByteIdentical': True, 'AllSingleGzipMembers': True,
          'Scope': 'unchanged historical preservation only; no runtime admission or study result'}
with (root / '.git/capture-five-publication-verification.json').open('x') as out:
    out.write(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
