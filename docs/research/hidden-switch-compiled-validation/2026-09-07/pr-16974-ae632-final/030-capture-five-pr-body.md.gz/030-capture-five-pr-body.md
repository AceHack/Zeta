Preserve every record from the fifth historical compiled-controller graph capture in a bounded PR, keeping the complete file inventory below GitHub's 3,000-file API limit. All 2,550 gzip records and the original manifest are byte-identical to the integration checkpoint; both hash layers and lossless relations were checked. Original writer histories remain reachable through four verified preservation refs.

The capture retains 32 unresolved indirect dependencies and false runtime/body/layout/closure admission. It introduces no registered source generation, measurement, implementation archive or speed claim. Parent task `081M1XXWTTF087G0R000X1HMD0` remains active; only publication task `081M1YPKNM3087G0R001M4RW87` is completed and its claim released.

Validation: all 18 full local preflight checks passed, including release build and full .NET tests, at the recorded publication base. Independent review verifies all 2,551 original Git blobs, the exact stored inventory, source-ref ancestry and bounded interpretation. Current PR CI separately validates the merge candidate. Raw validation logs and the signed review are indexed with the evidence.

Agency-Signature-Version: 1
Agent: Vera
Agent-Runtime: OpenAI Codex
Agent-Model: GPT-6 Astra
Credential-Identity: AceHack
Credential-Mode: shared
Human-Review: none
Human-Review-Evidence: none
Action-Mode: autonomous-fail-open
Task: 081M1YPKNM3087G0R001M4RW87
Co-Authored-By: Codex <noreply@openai.com>
