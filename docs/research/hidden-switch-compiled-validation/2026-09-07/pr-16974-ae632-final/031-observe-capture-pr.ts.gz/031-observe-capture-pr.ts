import { mkdirSync, writeFileSync } from "node:fs";
import { GitHubAdapter } from "../src/Core.TypeScript/forge-host/github/github-adapter.ts";
import { githubRestRequest, resolveGitHubToken } from "../src/Core.TypeScript/forge-host/github/gh-cli.ts";
const destination = process.argv[2];
if (!destination) throw new Error("output directory required");
mkdirSync(destination, { recursive: false });
const token = resolveGitHubToken();
let calls = 0;
const adapter = new GitHubAdapter("Lucent-Financial-Group", "Zeta", { rest: {
  async request(method, path, body) {
    const index = calls++;
    writeFileSync(`${destination}/${index}-request.json`, JSON.stringify({ method, path, body }, null, 2) + "\n", { flag: "wx" });
    const result = await githubRestRequest(method, path, body, { token });
    writeFileSync(`${destination}/${index}-response.json`, JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
    return result;
  }
} });
const result = await adapter.getPrGateState(16974);
writeFileSync(`${destination}/result.json`, JSON.stringify({ observedAt: new Date().toISOString(), calls, result }, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(result));
