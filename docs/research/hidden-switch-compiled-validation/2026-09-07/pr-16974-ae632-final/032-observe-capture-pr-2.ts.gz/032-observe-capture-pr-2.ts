import { mkdirSync, writeFileSync } from "node:fs";
import { GitHubAdapter } from "../src/Core.TypeScript/forge-host/github/github-adapter.ts";
import { spawnSync } from "node:child_process";
import { ok, err, forgeError } from "../src/Core.TypeScript/forge-host/result.ts";
const destination = process.argv[2];
if (!destination) throw new Error("output directory required");
mkdirSync(destination, { recursive: false });
let calls = 0;
const adapter = new GitHubAdapter("Lucent-Financial-Group", "Zeta", { rest: {
  async request(method, path, body) {
    const index = calls++;
    writeFileSync(`${destination}/${index}-request.json`, JSON.stringify({ method, path, body }, null, 2) + "\n", { flag: "wx" });
    const child = spawnSync("/opt/homebrew/bin/gh", ["api", "--method", method, path, "--input", "-"], { input: JSON.stringify(body), encoding: "utf8", timeout: 30000, maxBuffer: 32 * 1024 * 1024 });
    const result = child.status === 0 ? ok(child.stdout) : err(forgeError("network", `gh API failed: ${child.status}: ${child.stderr}`));
    writeFileSync(`${destination}/${index}-response.json`, JSON.stringify(result, null, 2) + "\n", { flag: "wx" });
    return result;
  }
} });
const result = await adapter.getPrGateState(16974);
writeFileSync(`${destination}/result.json`, JSON.stringify({ observedAt: new Date().toISOString(), calls, result }, null, 2) + "\n", { flag: "wx" });
console.log(JSON.stringify(result));
