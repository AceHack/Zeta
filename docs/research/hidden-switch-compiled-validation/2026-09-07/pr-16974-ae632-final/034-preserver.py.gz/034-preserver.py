from pathlib import Path
import datetime
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
pub = Path('/Users/acehack/.zeta/agents/codex/Zeta-compiled-evidence-publication-20260907')
dest = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/pr-16974-ae632-final'
dest.mkdir(exist_ok=False)
head = 'ae632b7396e7195097ed92e8b5832b42f9cb9489'
merged = json.loads((pub / '.git/pr-16974-merged-1.json').read_bytes())
merge = merged['mergeCommit']['oid']
assert merged['state'] == 'MERGED' and merged['headRefOid'] == head
subprocess.run(['git', 'merge-base', '--is-ancestor', merge, 'origin/main'], cwd=pub, check=True)
pages = json.loads((pub / '.git/pr-16974-publication-observations/files.stdout').read_bytes())
files = [row for page in pages for row in page]
assert len(pages) == 26 and len(files) == len({row['filename'] for row in files}) == 2566
def tree(commit):
    raw = subprocess.check_output(['git', 'ls-tree', '-rz', commit], cwd=pub)
    return {row.split(b'\t', 1)[1].decode(): row.split(b'\t', 1)[0].decode() for row in raw.split(b'\0') if row}
feature_tree, merge_tree, main_tree = tree(head), tree(merge), tree('origin/main')
for row in files:
    name = row['filename']
    assert feature_tree.get(name) == merge_tree.get(name) == main_tree.get(name), name
message = subprocess.check_output(['git', 'show', '-s', '--format=%B', merge], cwd=pub).decode()
signature = (pub / '.git/publication-signature.txt').read_text().strip()
assert signature in message
summary = dict(ObservedAtUtc=datetime.datetime.now(datetime.UTC).isoformat(), Pr=16974, Head=head, MergeCommit=merge, MergedAt=merged['mergedAt'], MainCommit=subprocess.check_output(['git','rev-parse','origin/main'],cwd=pub).decode().strip(), Pages=26, ChangedFiles=2566, AllPublishedTreeEntriesExactOnMergeAndMain=True, MainAncestryVerified=True, CompleteSignaturePresent=True, SourceRuntimeOrScientificAdmission=False)
summary_raw = (json.dumps(summary, indent=2) + '\n').encode()
inputs = [(str(path.relative_to(pub / '.git')), path.read_bytes()) for path in sorted((pub / '.git/pr-16974-publication-observations').iterdir()) if path.is_file()]
for index in range(1, 6):
    directory = pub / f'.git/pr-16974-gate-{index}'
    if directory.exists():
        inputs += [(str(path.relative_to(pub / '.git')), path.read_bytes()) for path in sorted(directory.iterdir()) if path.is_file()]
for name in ('pr-16974-checks-4.json','pr-16974-main-rules.json','pr-16974-review-state-4.json','pr-16974-drift-4.log','pr-16974-dependencies-5.json','pr-16974-merge-1.log','pr-16974-merged-1.json','capture-five-pr-body.md','observe-capture-pr.ts','observe-capture-pr-2.ts'):
    inputs.append((name,(pub / '.git' / name).read_bytes()))
inputs += [('proof-summary.json', summary_raw), ('preserver.py', Path(__file__).read_bytes())]
artifacts = []
for index, (name, raw) in enumerate(inputs):
    stored = gzip.compress(raw,mtime=0)
    filename = f'{index:03d}-' + name.replace('/', '--') + '.gz'
    with (dest / filename).open('xb') as out:
        out.write(stored)
    assert gzip.decompress(stored) == raw
    artifacts.append(dict(Source=name, File=filename, Bytes=len(raw), Sha256=hashlib.sha256(raw).hexdigest().upper(), Encoding='gzip', StoredBytes=len(stored), StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
with (dest / 'manifest.json').open('x') as out:
    out.write(json.dumps(dict(Scope='historical capture-five publication and exact main-tree proof; not native admission', Proof=summary, Artifacts=artifacts),indent=2)+'\n')
print(json.dumps(dict(Artifacts=len(artifacts), Proof=summary)))
