from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
dest = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/static-fixtures'
dest.mkdir(exist_ok=False)
source = 'fa1d34a89bc6bb2f40b6be66a10cde32d9698e1c'
names = [f'compiled-static-{kind}-{index}.log' for index in (1,2,3) for kind in ('format','ruff','mypy')]
names += ['compiled-static-tests-1.log','compiled-static-tests-2.log','compiled-static-first-execution-1.log']
artifacts=[]
for name,path in [(name,root/'.git'/name) for name in names]+[('retainer.py',Path(__file__))]:
 raw=path.read_bytes(); stored=gzip.compress(raw,mtime=0)
 with (dest/(name+'.gz')).open('xb') as out:out.write(stored)
 assert gzip.decompress(stored)==raw
 artifacts.append(dict(File=name+'.gz',Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper(),Encoding='gzip',StoredBytes=len(stored),StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
files=[]
for name in ('src/Interp.Python/zeta_interp/hidden_switch_compiled_static_fixtures.py','src/Interp.Python/tests/test_hidden_switch_compiled_static_fixtures.py'):
 raw=(root/name).read_bytes();assert raw==subprocess.check_output(['git','show',source+':'+name])
 files.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
with (dest/'manifest.json').open('x') as out:out.write(json.dumps(dict(Scope='32 non-I/O fixture definitions and 36 actual one-call dispatches under unit validation; not complete coordinator execution',SourceCommit=source,SourceFiles=files,Artifacts=artifacts),indent=2)+'\n')
print(json.dumps(dict(Artifacts=len(artifacts),SourceFiles=len(files))))
