from pathlib import Path
from datetime import UTC, datetime
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
dest = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/cost-ledgers'
dest.mkdir(exist_ok=False)
def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

source_groups = []
for commit, pattern, exclude in [
    ('dfc7b7e9c05cc13bbce65f348876956a9cb8a043', '*hidden_switch_compiled_*.py', 'cost_ledgers'),
    ('faa670a4ee615f4d55e96832f4ce4d421b560211', '*hidden_switch_compiled_cost_ledgers.py', None),
]:
    sources = []
    for folder in ['src/Interp.Python/zeta_interp', 'src/Interp.Python/tests']:
        for file in sorted((root / folder).glob(pattern)):
            if exclude and exclude in file.name:
                continue
            relative = file.relative_to(root).as_posix()
            raw = file.read_bytes()
            archived = subprocess.run(['git', 'show', commit + ':' + relative], check=True, capture_output=True).stdout
            assert archived == raw, relative
            sources.append({'File': relative, 'Bytes': len(raw), 'Sha256': sha(raw)})
    source_groups.append({'SourceCommit': commit, 'Files': sources})
artifacts = []
for name in ['compiled-integrated-tests-2.log', 'compiled-integrated-publication-2.log',
             'compiled-cost-ledgers-mypy-1.log', 'compiled-cost-ledgers-tests-1.log',
             'retain-compiled-integration-2.py']:
    raw = (root / '.git' / name).read_bytes()
    stored = gzip.compress(raw, mtime=0)
    with (dest / (name + '.gz')).open('xb') as output:
        output.write(stored)
    row = {'File': name + '.gz', 'Bytes': len(raw), 'Sha256': sha(raw), 'Encoding': 'gzip',
           'StoredBytes': len(stored), 'StoredSha256': sha(stored)}
    reread = (dest / row['File']).read_bytes()
    assert len(reread) == row['StoredBytes'] and sha(reread) == row['StoredSha256']
    expanded = gzip.decompress(reread)
    assert len(expanded) == row['Bytes'] and sha(expanded) == row['Sha256'] and expanded == raw
    artifacts.append(row)
record = {'Schema': 'zeta.hidden-switch.compiled.cost-ledger-validation.v1',
          'CapturedAtUtc': datetime.now(UTC).isoformat(), 'SourceGroups': source_groups,
          'Artifacts': artifacts, 'Scope': 'two distinct source/test snapshots; no registered source, native hand or cost replay'}
with (dest / 'manifest.json').open('x') as output:
    output.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({'VerifiedArtifacts': len(artifacts), 'SourceGroups': [len(group['Files']) for group in source_groups]}))

heartbeat = root / '.git/agent-heartbeats/codex-hidden-switch-compiled-integration-20260907.json'
state = json.loads(heartbeat.read_bytes())
state['updated_at'] = datetime.now(UTC).isoformat()
state['status'] = '583 integrated Python tests passed; 73 new cost-ledger tests passed; importing reviewed native hand slices for first exact replay. Runtime admission and implementation archive remain pending; registered streams unopened.'
heartbeat.write_text(json.dumps(state, indent=2) + '\n')
