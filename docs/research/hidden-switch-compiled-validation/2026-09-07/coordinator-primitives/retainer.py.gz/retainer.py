from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
dest = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/coordinator-primitives'
dest.mkdir(exist_ok=False)
groups = {
    'resource-ratio': ('1fece22bc84153dae0128c3a90bbca2ed09772dc', ['hidden_switch_compiled_cost_ledgers']),
    'conformance': ('2e0d01b296d16ef8a67d78d50bcd4501900b089b', ['hidden_switch_compiled_conformance']),
}
logs = [f'compiled-resource-ratio-{kind}-1.log' for kind in ('format', 'ruff', 'mypy', 'tests')]
logs += [f'compiled-conformance-{kind}-{index}.log' for index in (1, 2) for kind in ('format', 'ruff', 'mypy')]
logs += ['compiled-conformance-tests-1.log', 'compiled-integrated-tests-4.log']
records = []
for name, path in [(name, root / '.git' / name) for name in logs] + [('retainer.py', Path(__file__))]:
    raw = path.read_bytes()
    stored = gzip.compress(raw, mtime=0)
    with (dest / (name + '.gz')).open('xb') as output:
        output.write(stored)
    assert gzip.decompress(stored) == raw
    records.append(dict(File=name + '.gz', Bytes=len(raw), Sha256=hashlib.sha256(raw).hexdigest().upper(), Encoding='gzip', StoredBytes=len(stored), StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
sources = []
for group, (commit, modules) in groups.items():
    files = []
    for module in modules:
        for name in (f'src/Interp.Python/zeta_interp/{module}.py', f'src/Interp.Python/tests/test_{module}.py'):
            raw = (root / name).read_bytes()
            assert raw == subprocess.check_output(['git', 'show', commit + ':' + name])
            files.append(dict(File=name, Bytes=len(raw), Sha256=hashlib.sha256(raw).hexdigest().upper()))
    sources.append(dict(Group=group, SourceCommit=commit, Files=files))
with (dest / 'manifest.json').open('x') as output:
    output.write(json.dumps(dict(Scope='shared exact resource comparison and coordinator structure; no actual 92-case envelope or runtime admission', SourceGroups=sources, IntegratedSuiteCommit='2e0d01b296d16ef8a67d78d50bcd4501900b089b', Artifacts=records), indent=2) + '\n')
print(json.dumps(dict(Artifacts=len(records), SourceGroups=len(sources))))
