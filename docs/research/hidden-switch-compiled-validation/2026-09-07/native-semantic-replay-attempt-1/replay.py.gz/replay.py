from __future__ import annotations
import hashlib, json, subprocess, sys
from dataclasses import asdict
from pathlib import Path
from zeta_interp import hidden_switch_compiled_admission as a
from zeta_interp import hidden_switch_compiled_certificate as c
from zeta_interp import hidden_switch_compiled_falsifiers as f
from zeta_interp import hidden_switch_compiled_ieee as s
root=Path(__file__).resolve().parents[2]
owned=Path(__file__).resolve().parent
source=Path('/Users/acehack/.zeta/agents/codex/Zeta-rendered-predictor-native-20260906/.git/hidden-switch-compiled-semantic-attempt-1/semantic.json')
expected='E83775583A18712E4495EB57EFAC80A61316129E85D4EFAC0D02C8E1AB6C1451'
raw=source.read_bytes()
assert len(raw)==975309 and hashlib.sha256(raw).hexdigest().upper()==expected
with (owned/'native-semantic.json').open('xb') as target: target.write(raw)
parsed=a.strict_json(raw)
assert isinstance(parsed,a.Admitted), parsed
obj=parsed.value
assert obj['SlicesComplete'] is True and obj['Complete'] is False
assert all(obj[key] is False for key in ('RuntimeAdmitted','BodyResolved','ClosureAdmitted'))
assert obj['SourceDraws']==0
bindings={'ProtocolSha256':c.PROTOCOL_SHA256,'hand-validation':'0'*64}
assert obj['CertificateBindings']==bindings
built=c.build_certificate(bindings)
assert isinstance(built,s.Success), built
checked=c.verify_certificate(built.value,bindings)
assert isinstance(checked,s.Success), checked
cert=checked.value
assert obj['NumericCertificateSha256']==cert.NumericSha256
payload=obj['Payload']
assert type(payload) is dict and payload.keys()=={'Scalars','Episodes','OldControls','Semantic'}

def modules():
 return [{'Name':name,'File':str(Path(module.__file__).resolve()),'Bytes':len(Path(module.__file__).read_bytes()),'Sha256':hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest().upper()} for name,module in sorted(sys.modules.items()) if name.startswith('zeta_interp.hidden_switch') and getattr(module,'__file__',None)]
before=modules()
result=f.replay_semantic_falsifiers(payload['Scalars'],payload['Episodes'],payload['OldControls'],payload['Semantic'],cert)
after=modules()
output={'Schema':'zeta.hidden-switch.compiled.native-semantic-slice-replay.v1','Input':{'File':str(source),'Bytes':len(raw),'Sha256':expected},'ReferenceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'PythonExecutable':sys.executable,'PythonVersion':sys.version,'CertificateBindings':bindings,'NumericCertificateSha256':cert.NumericSha256,'ReturnedType':type(result).__module__+'.'+type(result).__qualname__,'Returned':asdict(result),'ReplayAccepted':isinstance(result,s.Success),'InputUnchangedAfterReplay':source.read_bytes()==raw,'LoadedTaskSourcesBefore':before,'LoadedTaskSourcesAfter':after,'ObservedSourceSnapshotsAgree':before==after,'Scope':'actual native complete hand slices and six semantic members only','OuterAndRuntimeAdmission':'not-performed','LoadedModuleAdmission':'not-performed; file/current-byte observations only','RegisteredSourceGeneration':False}
with (owned/'result.json').open('x') as target: json.dump(output,target,indent=2,sort_keys=True); target.write('\n')
print(json.dumps(output,indent=2,sort_keys=True))
if not isinstance(result,s.Success): raise SystemExit(1)
