from pathlib import Path
import gzip,hashlib,json,subprocess
root=Path.cwd();source=root/'.git/hidden-switch-compiled-native-semantic-replay-attempt-1';dest=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/native-semantic-replay-attempt-1'
dest.mkdir(parents=True,exist_ok=False)
result=json.loads((source/'result.json').read_bytes())
assert result['ReplayAccepted'] is True and result['InputUnchangedAfterReplay'] is True and result['ObservedSourceSnapshotsAgree'] is True
assert (source/'stderr.log').read_bytes()==b''
assert (source/'result.json').read_bytes()==(source/'stdout.json').read_bytes()
manifest={'Scope':'actual native complete hand slices and six semantic members only; no outer/runtime admission','NativeSourceCommit':'7eaec2bf2312e04ff0fc936a4c28a09d1704b1f0','NativeInput':result['Input'],'ReferenceCommit':result['ReferenceCommit'],'ExecutedCheckerCommit':'cdcf34d759a74201aa5599f4556e07af00f6dc4a','SourceFiles':[],'Artifacts':[]}
for item in result['LoadedTaskSourcesBefore']:
 p=Path(item['File']);relative=p.relative_to(root).as_posix();raw=p.read_bytes()
 assert len(raw)==item['Bytes'] and hashlib.sha256(raw).hexdigest().upper()==item['Sha256']
 assert raw==subprocess.check_output(['git','show',manifest['ReferenceCommit']+':'+relative])
 manifest['SourceFiles'].append({'File':relative,'Bytes':len(raw),'Sha256':item['Sha256']})
checker='src/Interp.Python/zeta_interp/hidden_switch_compiled_falsifiers.py'
assert (root/checker).read_bytes()==subprocess.check_output(['git','show',manifest['ExecutedCheckerCommit']+':'+checker])
for name in ('replay.py','native-semantic.json','result.json','stdout.json','stderr.log','preserve.py'):
 raw=(source/name).read_bytes();stored=gzip.compress(raw,mtime=0)
 with (dest/(name+'.gz')).open('xb') as f:f.write(stored)
 assert gzip.decompress(stored)==raw
 manifest['Artifacts'].append({'File':name+'.gz','Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'Encoding':'gzip','StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper()})
with (dest/'manifest.json').open('x') as f:json.dump(manifest,f,indent=2);f.write('\n')
print(json.dumps({'Artifacts':len(manifest['Artifacts']),'SourceFiles':len(manifest['SourceFiles']),'Completed':result['Returned']['value']['Completed']}))
