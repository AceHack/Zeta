from pathlib import Path
import gzip,hashlib,json,os,stat,subprocess,tarfile
root=Path.cwd();source="48e1041afaec4d7b3548019e7e4cbca900ea5334"
dest=root/"docs/research/hidden-switch-compiled-validation/2026-09-07/integration-5"
dest.mkdir(exist_ok=False)
fixture=root/".git/compiled-integrated-test-fixtures-5"
inventory=[]
for base,dirs,files in os.walk(fixture,followlinks=False):
 for name in sorted(dirs+files):
  p=Path(base)/name;s=p.lstat();kind="regular" if stat.S_ISREG(s.st_mode) else "directory" if stat.S_ISDIR(s.st_mode) else "symlink" if stat.S_ISLNK(s.st_mode) else "fifo" if stat.S_ISFIFO(s.st_mode) else "other"
  item=dict(File=str(p.relative_to(fixture)),Kind=kind,Mode=stat.S_IMODE(s.st_mode),Bytes=s.st_size)
  if kind=="regular":item["Sha256"]=hashlib.sha256(p.read_bytes()).hexdigest().upper()
  if kind=="symlink":item["Target"]=os.readlink(p)
  inventory.append(item)
assert len(inventory)<10000 and sum(x["Bytes"] for x in inventory if x["Kind"]=="regular")<64*1024*1024
inv=root/".git/compiled-integrated-test-fixtures-5-inventory.json";inv.write_text(json.dumps(inventory,indent=2)+"\n")
tar=root/".git/compiled-integrated-test-fixtures-5.tar"
with tarfile.open(tar,"x",dereference=False) as out:out.add(fixture,arcname=fixture.name,recursive=True)
records=[]
paths=[root/".git"/name for name in ("compiled-integrated-tests-5.log","compiled-integrated-publication-5.log","compiled-main-merge-5-science-proof.json","compiled-old-cli-search-1.json")]+[inv,tar,Path(__file__)]
for p in paths:
 raw=p.read_bytes();stored=gzip.compress(raw,mtime=0);name=p.name+".gz"
 with (dest/name).open("xb") as out:out.write(stored)
 assert gzip.decompress(stored)==raw
 records.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper(),Encoding="gzip",StoredBytes=len(stored),StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
sources=[]
for name in subprocess.check_output(["git","ls-files","src/Interp.Python"],text=True).splitlines():
 if name.endswith((".py",".toml",".lock")):
  raw=(root/name).read_bytes();assert raw==subprocess.check_output(["git","show",source+":"+name])
  sources.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
manifest=dict(Scope="983 compiled Python tests at the exact source pin; not full Interp/native or actual complete outer/runtime admission",SourceCommit=source,Command="uv run pytest -q tests/test_hidden_switch_compiled_*.py --basetemp ../../.git/compiled-integrated-test-fixtures-5",WorkingDirectory="src/Interp.Python",ExitCode=0,Passed=983,ElapsedSeconds=72.77,SourceFiles=sources,FixtureEntries=len(inventory),FixtureRegularBytes=sum(x["Bytes"] for x in inventory if x["Kind"]=="regular"),Artifacts=records)
(dest/"manifest.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(dict(Artifacts=len(records),SourceFiles=len(sources),FixtureEntries=len(inventory),FixtureRegularBytes=manifest["FixtureRegularBytes"])))
