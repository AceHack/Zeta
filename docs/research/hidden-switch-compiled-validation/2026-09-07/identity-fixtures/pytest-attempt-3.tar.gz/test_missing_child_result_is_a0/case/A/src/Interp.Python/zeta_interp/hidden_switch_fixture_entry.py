print('{}')
