raise RuntimeError('owned fixture crash')
