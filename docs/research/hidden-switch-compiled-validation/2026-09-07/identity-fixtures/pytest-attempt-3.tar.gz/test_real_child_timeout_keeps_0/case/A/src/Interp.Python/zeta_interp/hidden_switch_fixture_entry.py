import time
print('owned prefix', flush=True)
time.sleep(60)
