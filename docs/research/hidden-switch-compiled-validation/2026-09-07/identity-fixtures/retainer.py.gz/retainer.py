from pathlib import Path
import gzip
import hashlib
import io
import json
import stat
import subprocess
import tarfile

root = Path.cwd()
source = root / ".git/compiled-identity-fixtures-development"
dest = root / "docs/research/hidden-switch-compiled-validation/2026-09-07/identity-fixtures"
dest.mkdir(parents=True, exist_ok=False)
manifest = {"SourceCommit": "a7548b075b21b0c4fdc552844b66fac36789e305", "Scope": "owned fixture implementation validation only; no complete coordinator or runtime admission", "SourceFiles": [], "Artifacts": []}
for relative in (
    "zeta_interp/hidden_switch_compiled_identity_fixtures.py",
    "tests/test_hidden_switch_compiled_identity_fixtures.py",
    "zeta_interp/hidden_switch_compiled_admission.py",
    "zeta_interp/hidden_switch_compiled_storage.py",
    "zeta_interp/hidden_switch_compiled_sources.py",
    "zeta_interp/hidden_switch_compiled_conformance.py",
    "zeta_interp/hidden_switch_compiled_certificate_cases.py",
    "zeta_interp/hidden_switch_compiled_certificate.py",
    "zeta_interp/hidden_switch_compiled_ieee.py",
    "zeta_interp/hidden_switch_compiled_python_identity.py",
):
    name = "src/Interp.Python/" + relative
    data = subprocess.check_output(["git", "show", manifest["SourceCommit"] + ":" + name])
    assert data == (root / name).read_bytes()
    manifest["SourceFiles"].append({"File": name, "Bytes": len(data), "Sha256": hashlib.sha256(data).hexdigest().upper()})

def keep(name, data):
    packed = gzip.compress(data, mtime=0)
    with (dest / (name + ".gz")).open("xb") as stream:
        stream.write(packed)
    assert gzip.decompress(packed) == data
    manifest["Artifacts"].append({"File": name + ".gz", "Bytes": len(data), "Sha256": hashlib.sha256(data).hexdigest().upper(), "Encoding": "gzip", "StoredBytes": len(packed), "StoredSha256": hashlib.sha256(packed).hexdigest().upper()})

for path in sorted(source.iterdir()):
    if path.is_file() and path.name != "preflight-1.log":
        keep(path.name, path.read_bytes())

fixture = source / "pytest-attempt-3"
regular = []
links = []
# Preserve actual source files, Git object database, child outputs and symlinks.
# Never extract this archive during verification.
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode="w", format=tarfile.PAX_FORMAT) as archive:
    for path in sorted(fixture.rglob("*")):
        relative = path.relative_to(fixture).as_posix()
        metadata = path.lstat()
        if stat.S_ISREG(metadata.st_mode):
            raw = path.read_bytes()
            regular.append({"File": relative, "Bytes": len(raw), "Sha256": hashlib.sha256(raw).hexdigest().upper()})
            info = archive.gettarinfo(str(path), arcname=relative)
            archive.addfile(info, io.BytesIO(raw))
        elif stat.S_ISLNK(metadata.st_mode):
            info = archive.gettarinfo(str(path), arcname=relative)
            links.append({"File": relative, "Target": info.linkname})
            archive.addfile(info)
        elif not stat.S_ISDIR(metadata.st_mode):
            raise AssertionError((relative, metadata.st_mode))
raw_tar = buffer.getvalue()
with tarfile.open(fileobj=io.BytesIO(raw_tar), mode="r:") as archive:
    by_name = {entry.name: entry for entry in archive}
    assert len(by_name) == len(regular) + len(links)
    for row in regular:
        reader = archive.extractfile(by_name[row["File"]])
        assert reader is not None
        raw = reader.read()
        assert len(raw) == row["Bytes"] and hashlib.sha256(raw).hexdigest().upper() == row["Sha256"]
    for row in links:
        entry = by_name[row["File"]]
        assert entry.issym() and entry.linkname == row["Target"]
keep("pytest-attempt-3.tar", raw_tar)
keep("pytest-attempt-3-inventory.json", (json.dumps({"OriginalRoot": str(fixture), "RegularFiles": regular, "Symlinks": links}, indent=2) + "\n").encode())
manifest["RetainedFixtureRegularFiles"] = len(regular)
manifest["RetainedFixtureOriginalBytes"] = sum(row["Bytes"] for row in regular)
manifest["RetainedFixtureSymlinks"] = len(links)
with (dest / "manifest.json").open("x") as stream:
    stream.write(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({"Artifacts": len(manifest["Artifacts"]), "SourceFiles": len(manifest["SourceFiles"]), "FixtureFiles": len(regular), "FixtureBytes": manifest["RetainedFixtureOriginalBytes"], "FixtureSymlinks": len(links)}))
