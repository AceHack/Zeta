from pathlib import Path
import gzip
import hashlib
import io
import json
import stat
import subprocess
import tarfile

root = Path.cwd()
dest = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/file-fixtures'
dest.mkdir(exist_ok=False)
source='9e2201236f0bd7c2e2b32644554d0b847831b7e0'
names=[f'compiled-file-{kind}-{index}.log' for index in (1,2,3) for kind in ('format','ruff','mypy')]
names+=['compiled-file-tests-1.log','compiled-file-tests-2.log']
inputs=[(name,(root/'.git'/name).read_bytes()) for name in names]
trees=[]
for index in (1,2):
 base=root/f'.git/compiled-file-test-fixtures-{index}'
 paths=sorted(base.rglob('*'))
 assert len(paths)<1000
 inventory=[]; total=0
 buffer=io.BytesIO()
 with tarfile.open(fileobj=buffer,mode='w',dereference=False) as archive:
  for path in paths:
   info=path.lstat();relative=str(path.relative_to(base))
   row=dict(File=relative,Mode=info.st_mode,Device=info.st_dev,Inode=info.st_ino,ModifiedNs=info.st_mtime_ns,ChangedNs=info.st_ctime_ns)
   if stat.S_ISREG(info.st_mode):
    assert info.st_size<=4096
    raw=path.read_bytes(); assert len(raw)==info.st_size
    total+=len(raw); assert total<=1024*1024
    row.update(Kind='regular',Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper())
   elif stat.S_ISLNK(info.st_mode):row.update(Kind='symlink',Target=str(path.readlink()))
   elif stat.S_ISDIR(info.st_mode):row.update(Kind='directory')
   elif stat.S_ISFIFO(info.st_mode):row.update(Kind='fifo')
   else:raise RuntimeError('unexpected fixture inode type')
   inventory.append(row)
   archive.add(path,arcname=relative,recursive=False)
 trees.append(dict(Index=index,Root=str(base),Files=inventory,RegularBytes=total,Entries=len(paths)))
 inputs.append((f'fixture-tree-{index}.tar',buffer.getvalue()))
inputs += [('tree-inventory.json',(json.dumps(trees,indent=2)+'\n').encode()),('retainer.py',Path(__file__).read_bytes())]
artifacts=[]
for name,raw in inputs:
 stored=gzip.compress(raw,mtime=0)
 with (dest/(name+'.gz')).open('xb') as out:out.write(stored)
 assert gzip.decompress(stored)==raw
 artifacts.append(dict(File=name+'.gz',Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper(),Encoding='gzip',StoredBytes=len(stored),StoredSha256=hashlib.sha256(stored).hexdigest().upper()))
files=[]
for name in ('src/Interp.Python/zeta_interp/hidden_switch_compiled_file_fixtures.py','src/Interp.Python/tests/test_hidden_switch_compiled_file_fixtures.py'):
 raw=(root/name).read_bytes();assert raw==subprocess.check_output(['git','show',source+':'+name])
 files.append(dict(File=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest().upper()))
with (dest/'manifest.json').open('x') as out:out.write(json.dumps(dict(Scope='seven owned filesystem fixtures and eleven actual operation positions under unit validation; no complete outer admission',SourceCommit=source,SourceFiles=files,Artifacts=artifacts),indent=2)+'\n')
print(json.dumps(dict(Artifacts=len(artifacts),Trees=[dict(Index=x['Index'],Entries=x['Entries'],RegularBytes=x['RegularBytes']) for x in trees])))
