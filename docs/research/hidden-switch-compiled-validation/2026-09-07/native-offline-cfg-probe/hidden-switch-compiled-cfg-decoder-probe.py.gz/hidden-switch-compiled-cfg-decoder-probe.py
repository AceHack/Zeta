import hashlib,json
from pathlib import Path
import lldb

def probe(debugger,command,result,_dict):
    root=Path('/Users/acehack/.zeta/agents/codex/Zeta-rendered-predictor-native-20260906')
    source=root/'.git/hidden-switch-compiled-graph-attempt-5'
    output=root/'.git/hidden-switch-compiled-cfg-decoder-probe.json'
    rows=[];settings=[]
    for command in ['settings set symbols.enable-external-lookup false','settings set target.load-script-from-symbol-file false','settings clear plugin.symbol-locator.debuginfod.server-urls']:
        reply=lldb.SBCommandReturnObject();debugger.GetCommandInterpreter().HandleCommand(command,reply)
        settings.append({'Command':command,'Success':reply.Succeeded(),'Output':reply.GetOutput(),'Error':reply.GetError()})
        if not reply.Succeeded():raise ValueError('offline setting refused')
    target=debugger.CreateTargetWithFileAndArch('/Users/acehack/.local/share/mise/dotnet-root/dotnet','arm64')
    if not target.IsValid():raise ValueError('non-running decode target invalid')
    for path in sorted(source.glob('body-*-raw.json')):
        item=json.loads(path.read_text());raw=bytes.fromhex(item['Hex']);address=int(item['Address'],16)
        instructions=target.GetInstructions(lldb.SBAddress(address,target),raw)
        if instructions.GetSize()*4!=len(raw):raise ValueError('buffer decode truncated')
        decoded=[]
        for i,inst in enumerate(instructions):
            if not inst.IsValid() or inst.GetByteSize()!=4:raise ValueError('invalid buffer instruction')
            data=inst.GetData(target);observed=[]
            for j in range(4):
                error=lldb.SBError();observed.append(data.GetUnsignedInt8(error,j))
                if not error.Success():raise ValueError('byte read failed')
            if bytes(observed)!=raw[4*i:4*i+4]:raise ValueError('byte mismatch')
            decoded.append({'Offset':4*i,'Hex':bytes(observed).hex().upper(),'Mnemonic':inst.GetMnemonic(target),'Operands':inst.GetOperands(target),'ControlFlowKind':int(inst.GetControlFlowKind(target))})
        rows.append({'Input':str(path),'InputSha256':hashlib.sha256(path.read_bytes()).hexdigest().upper(),'Rows':decoded})
    with output.open('x') as stream:json.dump({'Kind':'offline-buffer-decoder-probe','LLDB':debugger.GetVersionString(),'PolicyExecuted':False,'RuntimeAdmitted':False,'Settings':settings,'Rows':rows},stream,indent=2)
    result.AppendMessage('retained '+str(len(rows))+' buffer decodes; no process launched')

def __lldb_init_module(debugger,_dict):
    debugger.HandleCommand('command script add -f hidden-switch-compiled-cfg-decoder-probe.probe hs-cfg-probe')
