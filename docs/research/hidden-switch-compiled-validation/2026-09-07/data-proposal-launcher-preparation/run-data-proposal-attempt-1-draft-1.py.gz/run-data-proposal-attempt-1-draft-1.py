"""One owned metadata-only child; exact source pins, first outcome and guarded cleanup."""
from pathlib import Path
import datetime
import json
import os
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'src/Research.FSharp.Cli'))
from hidden_switch_retained_artifacts import regular_bytes, sha, strict_json
from inventory_hidden_switch_transfers import encode, exclusive_bytes, failure

source = 'a80211d357d548d97caf850f367543abfbf91638'
base = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07'
attempt = root / '.git/hidden-switch-data-proposal-attempt-1'
prefix = root / '.git/hidden-switch-data-proposal-attempt-1'
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
def identity(path, limit=4 * 1024 * 1024):
    raw = regular_bytes(path, limit)
    return {'File': str(path), 'Bytes': len(raw), 'Sha256': sha(raw)}

prep_path = base / 'data-proposal-wrapper-preparation/manifest.json'
prep_raw = regular_bytes(prep_path, 512 * 1024)
prep = strict_json(prep_raw)
assert prep['SourceCommit'] == source and len(prep['SourcePins']) == 16
for pin in prep['SourcePins']:
    raw = regular_bytes(root / pin['File'], 256 * 1024)
    assert len(raw) == pin['Bytes'] and sha(raw) == pin['Sha256']
    assert raw == subprocess.check_output(['git', 'show', source + ':' + pin['File']], cwd=root, timeout=10)
argv = [sys.executable, str(root / 'src/Research.FSharp.Cli/propose_hidden_switch_data_ranges.py'), str(base), str(attempt), source]
invocation = {'SourceCommit': source, 'ExecutionHead': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True, timeout=10).strip(),
              'Arguments': argv, 'WorkingDirectory': str(root), 'StartedAtUtc': utc(), 'TimeoutSeconds': 60,
              'PolledStreamByteLimit': 65536, 'Python': identity(Path(sys.executable).resolve()), 'OuterHarness': identity(Path(__file__).resolve()),
              'Preparation': {'File': str(prep_path), 'Bytes': len(prep_raw), 'Sha256': sha(prep_raw)}, 'SourcePins': prep['SourcePins'],
              'RuntimeAdmitted': False, 'BodyResolved': False, 'ClosureAdmitted': False}
exclusive_bytes(Path(str(prefix) + '-invocation.json'), encode(invocation, 128 * 1024))
child = None; streams = []; primary = None; cleanup = []; unchanged = False; started = time.monotonic(); pid = None; code = None
try:
    for suffix in ['.stdout.log', '.stderr.log']:
        streams.append(Path(str(prefix) + suffix).open('xb'))
    child = subprocess.Popen(argv, cwd=root, stdout=streams[0], stderr=streams[1]); pid = child.pid
    while child.poll() is None:
        if time.monotonic() - started >= 60:
            raise TimeoutError('owned metadata child exceeded sixty seconds')
        if any(os.fstat(stream.fileno()).st_size > 65536 for stream in streams):
            raise ValueError('owned metadata output exceeded polled stream limit')
        time.sleep(0.01)
    code = child.wait(timeout=5)
    if any(os.fstat(stream.fileno()).st_size > 65536 for stream in streams):
        raise ValueError('closed metadata output exceeded stream limit')
    for pin in prep['SourcePins']:
        raw = regular_bytes(root / pin['File'], 256 * 1024)
        if len(raw) != pin['Bytes'] or sha(raw) != pin['Sha256']:
            raise ValueError('source identity changed after metadata invocation')
    unchanged = True
except Exception as error:
    primary = failure('metadata-proposal-launch', error)
finally:
    if child is not None:
        try:
            if child.poll() is None:
                child.kill()
            code = child.wait(timeout=5)
        except Exception as error:
            cleanup.append(failure('owned-child-kill-join', error))
    for stream in streams:
        try:
            stream.close()
        except Exception as error:
            cleanup.append(failure('owned-output-close', error))
    completion = {'FinishedAtUtc': utc(), 'ElapsedSeconds': time.monotonic() - started, 'ProcessId': pid, 'ExitCode': code,
                  'OuterFailure': primary, 'CleanupFailures': cleanup, 'SourcePinsUnchanged': unchanged,
                  'DirectChildClosed': child is not None and code is not None and not any(row['Stage'] == 'owned-child-kill-join' for row in cleanup)}
    exclusive_bytes(Path(str(prefix) + '-completion.json'), encode(completion, 65536))
print(json.dumps(completion))
