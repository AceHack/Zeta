"""Execute only the exact launcher's extracted cleanup/publication functions, never its child path."""
import ast
import contextlib
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root / 'src/Research.FSharp.Cli'))
from inventory_hidden_switch_transfers import encode, exclusive_bytes, failure

source = (root / '.git/run-data-proposal-attempt-1.py').read_bytes()
tree = ast.parse(source)
functions = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in {'cleanup_owned', 'publish_completion'}]
assert len(functions) == 2
scope = {'Path': Path, 'encode': encode, 'exclusive_bytes': exclusive_bytes, 'failure': failure}
exec(compile(ast.Module(body=functions, type_ignores=[]), 'retained-launcher-functions', 'exec'), scope)


class LaunchFixtures(unittest.TestCase):
    def test_poll_and_kill_errors_do_not_skip_join_or_real_file_closes(self):
        events = []; errors = []
        class Child:
            def poll(self): events.append('poll'); raise OSError('poll refusal')
            def kill(self): events.append('kill'); raise OSError('kill refusal')
            def wait(self, timeout): events.append('join'); return 7
        class Stream:
            def __init__(self, file, name): self.file = file; self.name = name
            def close(self):
                events.append(self.name); self.file.close()
                raise OSError(self.name + ' after real close')
        with tempfile.TemporaryDirectory() as directory:
            files = [(Path(directory) / name).open('xb') for name in ['out', 'err']]
            streams = [Stream(file, name) for file, name in zip(files, ['out', 'err'], strict=True)]
            code, joined = scope['cleanup_owned'](Child(), streams, errors)
            self.assertEqual((code, joined), (7, True))
            self.assertTrue(all(file.closed for file in files))
        self.assertEqual(events, ['poll', 'kill', 'join', 'out', 'err'])
        self.assertEqual([row['Stage'] for row in errors], ['owned-child-poll', 'owned-child-kill', 'owned-output-close', 'owned-output-close'])

    def test_join_failure_still_closes_and_never_claims_closed(self):
        class Child:
            def poll(self): return 0
            def wait(self, timeout): raise TimeoutError('join refusal')
            def kill(self): raise AssertionError('already terminal')
        errors = []
        with tempfile.TemporaryDirectory() as directory:
            file = (Path(directory) / 'out').open('xb')
            self.assertEqual(scope['cleanup_owned'](Child(), [file], errors), (None, False))
            self.assertTrue(file.closed)
        self.assertEqual(errors[0]['Stage'], 'owned-child-join')

    def test_completed_write_then_failure_keeps_first_and_publishes_independently(self):
        first = failure('original', ValueError('first computation refusal'))
        report = {'OuterFailure': first, 'CleanupFailures': []}
        def write(path, raw):
            exclusive_bytes(path, raw)
            if path.name.endswith('-completion.json'):
                raise OSError('after completed original write')
        with tempfile.TemporaryDirectory() as directory, contextlib.redirect_stdout(io.StringIO()) as console:
            prefix = Path(directory) / 'attempt'
            with patch.dict(scope, {'exclusive_bytes': write}):
                actual = scope['publish_completion'](prefix, report)
            original = json.loads(Path(str(prefix) + '-completion.json').read_bytes())
            fallback = json.loads(Path(str(prefix) + '-completion-failed.json').read_bytes())
            self.assertEqual(original['OuterFailure'], first)
            self.assertNotIn('TerminalPublicationFailure', original)
            self.assertEqual(fallback['OuterFailure'], first)
            self.assertEqual(json.loads(console.getvalue()), actual)
            self.assertEqual(actual['TerminalPublicationFailure']['Detail'], 'after completed original write')

    def test_main_fallback_and_console_errors_preserve_first_in_last_independent_record(self):
        first = failure('original', ValueError('first failure'))
        def write(path, raw):
            if 'completion' in path.name:
                raise OSError(path.name)
            exclusive_bytes(path, raw)
        with tempfile.TemporaryDirectory() as directory:
            prefix = Path(directory) / 'attempt'
            with patch.dict(scope, {'exclusive_bytes': write}), patch('builtins.print', side_effect=OSError('console refusal')):
                actual = scope['publish_completion'](prefix, {'OuterFailure': first, 'CleanupFailures': []})
            retained = json.loads(Path(str(prefix) + '-console-failed.json').read_bytes())
            self.assertEqual(actual, retained)
            self.assertEqual(retained['OuterFailure'], first)
            self.assertEqual(retained['ConsoleFailure']['Detail'], 'console refusal')
            self.assertIn('SecondaryPublicationFailure', retained)


if __name__ == '__main__':
    unittest.main()
