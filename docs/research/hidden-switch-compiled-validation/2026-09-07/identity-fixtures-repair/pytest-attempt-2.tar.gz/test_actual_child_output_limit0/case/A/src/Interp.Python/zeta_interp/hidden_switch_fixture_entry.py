import os, sys, time
from pathlib import Path
sys.stdout.buffer.write(b'x'*2048)
sys.stdout.flush()
time.sleep(60)
