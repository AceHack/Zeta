import os, sys, time
from pathlib import Path
sys.stderr.buffer.write(b'x'*2048)
sys.stderr.flush()
time.sleep(60)
