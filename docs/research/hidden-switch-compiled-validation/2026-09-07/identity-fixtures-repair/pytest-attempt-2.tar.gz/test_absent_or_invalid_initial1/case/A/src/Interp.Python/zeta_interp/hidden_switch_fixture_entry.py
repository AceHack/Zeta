import os
from pathlib import Path
(Path(os.environ['ZETA_IDENTITY_ROOT'])/'child-trace.jsonl').write_bytes(b'{truncated')
raise RuntimeError('early crash')
