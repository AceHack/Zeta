"""Fixed owned collector entry; no recorder, policy or source generator."""
import dataclasses
import hashlib
import importlib
import json
import os
import sys
from pathlib import Path
from types import ModuleType
import zeta_interp

root = Path(os.environ["ZETA_IDENTITY_ROOT"])
first, second = root / "A", root / "B"
package = "src/Interp.Python/zeta_interp"
zeta_interp.__path__ = [str(first / package)]
from . import hidden_switch_compiled_python_identity as identity

case = os.environ["ZETA_IDENTITY_CASE"]
helper_name = "zeta_interp.hidden_switch_fixture_helper"
entry_name = "zeta_interp.hidden_switch_fixture_entry"
if case == "python/foreign-helper":
    zeta_interp.__path__ = [str(second / package)]
helper = importlib.import_module(helper_name)
zeta_interp.__path__ = [str(first / package)]
expected = json.loads((root / "expected.json").read_bytes())

def encode(value):
    if dataclasses.is_dataclass(value) and not isinstance(value, type):
        return {"Type": type(value).__module__ + "." + type(value).__qualname__,
                "Fields": {f.name: encode(getattr(value, f.name)) for f in dataclasses.fields(value)}}
    if isinstance(value, (tuple, list)):
        return [encode(v) for v in value]
    if isinstance(value, dict):
        return {k: encode(v) for k, v in value.items()}
    if type(value) is bytes:
        return {"BytesHex": value.hex().upper()}
    return value

def facts():
    result = []
    names = set(expected["Modules"])
    names.update(name for name in sys.modules if name.startswith("zeta_interp.hidden_switch"))
    for name in sorted(names):
        key = "__main__" if name == entry_name else name
        module = sys.modules.get(key)
        spec = getattr(module, "__spec__", None)
        loader = getattr(spec, "loader", None)
        filename = getattr(module, "__file__", None)
        raw = Path(filename).read_bytes() if type(filename) is str else None
        result.append({"Name": name, "RuntimeName": key,
                       "ModuleType": type(module).__name__, "File": filename,
                       "SpecOrigin": getattr(spec, "origin", None),
                       "LoaderName": getattr(loader, "name", None),
                       "LoaderPath": getattr(loader, "path", None),
                       "SourceSha256": None if raw is None else hashlib.sha256(raw).hexdigest().upper()})
    return result

before = facts()
if case == "python/missing-helper":
    del sys.modules[helper_name]
elif case == "python/unlisted-module":
    importlib.import_module("zeta_interp.hidden_switch_fixture_extra")
elif case == "python/dynamic-module":
    sys.modules[helper_name] = ModuleType(helper_name)
elif case == "python/changed-origin":
    helper.__spec__.origin = str(second / package / "hidden_switch_fixture_helper.py")
elif case == "python/changed-bytes":
    p = first / package / "hidden_switch_fixture_helper.py"
    original = p.read_bytes()
    with (root / "helper-before-mutation.py").open("xb") as backup:
        backup.write(original)
    with p.open("wb") as changed:
        changed.write(original.replace(b"7", b"8", 1))
after = facts()
with (root / "child-trace.jsonl").open("x", encoding="ascii") as trace:
    trace.write(json.dumps({"Kind": "collector-entry", "Entry": 1,
                           "CaseId": case, "Before": before, "After": after}, sort_keys=True) + "\n")
    trace.flush()
    raise RuntimeError('crash after collector entry')
    result = identity.admit_python_identity(expected["CloneRoot"], expected["Modules"], entry_module=expected["EntryModule"])
    encoded = encode(result)
    trace.write(json.dumps({"Kind": "collector-return", "Return": 1, "Result": encoded}, sort_keys=True) + "\n")
    trace.flush()
print(json.dumps({"CollectorEntries": 1, "CollectorReturns": 1, "Result": encoded}, sort_keys=True))
