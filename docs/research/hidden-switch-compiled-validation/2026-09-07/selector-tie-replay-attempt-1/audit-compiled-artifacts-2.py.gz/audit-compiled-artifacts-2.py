from pathlib import Path
import hashlib
import json
import zlib

from zeta_interp import hidden_switch_compiled_admission as admission

root = Path.cwd().parents[1]
base = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07'
fields = {'File', 'Bytes', 'Sha256', 'Encoding', 'StoredBytes', 'StoredSha256'}
records = []
failures = []

def visit(node, folder, manifest):
    if isinstance(node, dict):
        if fields <= node.keys():
            # Earlier instrument inventories retain an extra original provenance
            # path in File and put the actual preserved path in StoredFile. They
            # are not the final phase's exact six-field descriptor schema.
            descriptor = {key: node[key] for key in fields}
            descriptor['File'] = node.get('StoredFile', node['File'])
            for key in ('Sha256', 'StoredSha256'):
                descriptor[key] = descriptor[key].upper()
            file = folder / descriptor['File']
            try:
                assert 0 <= descriptor['Bytes'] <= 256 * 1024 * 1024
                stored = file.read_bytes()
                if descriptor['Encoding'] == 'gzip':
                    decoder = zlib.decompressobj(wbits=31)
                    raw = decoder.decompress(stored, descriptor['Bytes'] + 1)
                else:
                    raw = stored
                result = admission.bind_artifact_bytes(descriptor, stored, raw, str(file.relative_to(root)))
                assert isinstance(result, admission.Admitted), result
                records.append({'Manifest': str(manifest.relative_to(root)), 'File': str(file.relative_to(root)),
                                'StoredBytes': len(stored), 'Bytes': len(raw)})
            except (OSError, ValueError, zlib.error, AssertionError) as error:
                failures.append({'Manifest': str(manifest.relative_to(root)), 'File': str(file.relative_to(root)),
                                 'Error': str(error) or type(error).__name__})
        for value in node.values():
            visit(value, folder, manifest)
    elif isinstance(node, list):
        for value in node:
            visit(value, folder, manifest)

for manifest in sorted(base.rglob('*manifest*.json')):
    visit(json.loads(manifest.read_bytes()), manifest.parent, manifest)
result = {'Scope': 'stored/original byte and lossless relation checks only; explicit StoredFile projection for historical captures; no full graph, source, runtime or phase admission',
          'VerifiedRecords': len(records), 'DistinctFiles': len({row['File'] for row in records}),
          'Failures': failures, 'Records': records}
with (root / '.git/compiled-artifact-audit-2.json').open('x') as output:
    output.write(json.dumps(result, indent=2) + '\n')
print(json.dumps({'VerifiedRecords': len(records), 'DistinctFiles': result['DistinctFiles'],
                  'FailureCount': len(failures), 'FirstFailures': failures[:3]}))
raise SystemExit(1 if failures else 0)
