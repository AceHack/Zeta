from dataclasses import asdict
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

from zeta_interp import hidden_switch_compiled_admission as a
from zeta_interp import hidden_switch_compiled_certificate as c
from zeta_interp import hidden_switch_compiled_ieee as s
from zeta_interp import hidden_switch_compiled_outer_negatives as outer

root = Path.cwd().parents[1]
source = '16d2ac85bd00ce6664731470a3c5f8345f9df4fb'
input_path = Path('/Users/acehack/.zeta/agents/codex/Zeta-rendered-predictor-native-20260906/.git/hidden-switch-compiled-invocations-attempt-1/invocations.json')
expected_hash = '9EBBC621583A24BF45DB3AD50F665CCD3EF3D4A7070004F9CDF4E58D705FD78D'
dest = root / '.git/compiled-native-selector-replay-attempt-1'
dest.mkdir(exist_ok=False)

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

started = datetime.now(UTC).isoformat()
raw = input_path.read_bytes()
assert len(raw) == 7457 and sha(raw) == expected_hash
with (dest / 'native-invocations.json').open('xb') as output:
    output.write(raw)
parsed = a.strict_json(raw)
assert isinstance(parsed, a.Admitted), parsed
native = parsed.value
assert native['Complete'] is False and native['SlicesComplete'] is True
assert native['SourceDraws'] == 0
bindings = {'ProtocolSha256': c.PROTOCOL_SHA256, 'hand-validation': '0' * 64}
assert native['CertificateBindings'] == bindings
built = c.build_certificate(bindings)
assert isinstance(built, s.Success), built
certificate = c.verify_certificate(built.value, bindings)
assert isinstance(certificate, s.Success), certificate
assert certificate.value.NumericSha256 == native['NumericCertificateSha256']
result = outer.replay_selector_tie(native['SelectorWitness'], certificate.value)
sources = []
for name, module in sorted(sys.modules.copy().items()):
    if not name.startswith('zeta_interp.hidden_switch'):
        continue
    file = Path(module.__file__).resolve(strict=True)
    relative = file.relative_to(root).as_posix()
    observed = file.read_bytes()
    archived = subprocess.run(['git', 'show', source + ':' + relative], check=True, capture_output=True).stdout
    assert archived == observed, name
    sources.append({'Module': name, 'File': relative, 'Bytes': len(observed), 'Sha256': sha(observed)})
assert input_path.read_bytes() == raw
record = {'Schema': 'zeta.hidden-switch.compiled.native-selector-replay.v1',
          'StartedAtUtc': started, 'FinishedAtUtc': datetime.now(UTC).isoformat(),
          'NativeSourceCommit': '8aede9982fc3ce1eb891c5d630710f778b3eff63',
          'IndependentSourceCommit': source,
          'NativeInput': {'Bytes': len(raw), 'Sha256': sha(raw)},
          'PythonExecutable': sys.executable, 'PythonVersion': sys.version,
          'ObservedTaskSources': sources,
          'Result': {'Kind': 'accepted' if isinstance(result, s.Success) else 'refused',
                     'Value': asdict(result.value if isinstance(result, s.Success) else result)},
          'Scope': 'one actual native supplied-Q selector witness; no invocation-array, complete envelope, archive or runtime admission'}
with (dest / 'result.json').open('x') as output:
    output.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({'InputSha256': sha(raw), 'SourceFilesObserved': len(sources), 'Result': record['Result']}))
raise SystemExit(0 if isinstance(result, s.Success) else 1)
