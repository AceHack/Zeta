from pathlib import Path
import gzip
import hashlib
import json
import subprocess

root = Path.cwd()
dest = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/selector-tie-replay-attempt-1'
dest.mkdir(exist_ok=False)
source = '16d2ac85bd00ce6664731470a3c5f8345f9df4fb'
def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

inputs = [
    ('compiled-selector-tie-mypy-1.log', '.git/compiled-selector-tie-mypy-1.log'),
    ('compiled-selector-tie-mypy-2.log', '.git/compiled-selector-tie-mypy-2.log'),
    ('compiled-selector-tie-tests-1.log', '.git/compiled-selector-tie-tests-1.log'),
    ('compiled-selector-tie-tests-2.log', '.git/compiled-selector-tie-tests-2.log'),
    ('replay.stdout.log', '.git/compiled-native-selector-replay-1.stdout.log'),
    ('replay.stderr.log', '.git/compiled-native-selector-replay-1.stderr.log'),
    ('native-invocations.json', '.git/compiled-native-selector-replay-attempt-1/native-invocations.json'),
    ('result.json', '.git/compiled-native-selector-replay-attempt-1/result.json'),
    ('replay-native-selector-witness-1.py', '.git/replay-native-selector-witness-1.py'),
    ('compiled-artifact-audit-1.json', '.git/compiled-artifact-audit-1.json'),
    ('compiled-artifact-audit-2.json', '.git/compiled-artifact-audit-2.json'),
    ('audit-compiled-artifacts-2.py', '.git/audit-compiled-artifacts-2.py'),
    ('retain-compiled-selector-1.py', '.git/retain-compiled-selector-1.py'),
]
artifacts = []
for name, original in inputs:
    raw = (root / original).read_bytes()
    stored = gzip.compress(raw, mtime=0)
    with (dest / (name + '.gz')).open('xb') as output:
        output.write(stored)
    reread = (dest / (name + '.gz')).read_bytes()
    assert reread == stored and gzip.decompress(reread) == raw
    artifacts.append({'File': name + '.gz', 'Bytes': len(raw), 'Sha256': sha(raw), 'Encoding': 'gzip',
                      'StoredBytes': len(stored), 'StoredSha256': sha(stored)})
files = []
for relative in ['src/Interp.Python/zeta_interp/hidden_switch_compiled_outer_negatives.py',
                 'src/Interp.Python/tests/test_hidden_switch_compiled_outer_negatives.py']:
    raw = (root / relative).read_bytes()
    archived = subprocess.run(['git', 'show', source + ':' + relative], check=True, capture_output=True).stdout
    assert raw == archived
    files.append({'File': relative, 'Bytes': len(raw), 'Sha256': sha(raw)})
record = {'Schema': 'zeta.hidden-switch.compiled.selector-tie-validation.v1', 'SourceCommit': source,
          'SourceFiles': files, 'InventoryAuditTree': '4f2f70d6e', 'Artifacts': artifacts,
          'Scope': 'one actual supplied-Q witness and separately scoped inventory audit; no full hand/outer/runtime admission'}
with (dest / 'manifest.json').open('x') as output:
    output.write(json.dumps(record, indent=2) + '\n')
print(json.dumps({'VerifiedArtifacts': len(artifacts), 'SourceFiles': len(files)}))
