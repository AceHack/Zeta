

.class public auto ansi sealed beforefieldinit Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand extends [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandBase
{
  .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 01 64 53 1D 0E 07 41 6C 69 61 73 65 73 01 00 00 00 0A 72 65 61 64 6D 65 6D 6F 72 79 53 0E 04 48 65 6C 70 16 44 75 6D 70 73 20 6D 65 6D 6F 72 79 20 63 6F 6E 74 65 6E 74 73 2E ) // ....S..Name.dS...Aliases.....readmemoryS..Help.Dumps.memory.contents.
  .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 02 64 62 53 0E 0E 44 65 66 61 75 6C 74 4F 70 74 69 6F 6E 73 5C 2D 2D 61 73 63 69 69 3A 74 72 75 65 20 20 2D 2D 75 6E 69 63 6F 64 65 3A 66 61 6C 73 65 20 2D 2D 61 73 63 69 69 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 63 3A 31 32 38 20 2D 6C 3A 31 20 20 2D 77 3A 31 36 53 0E 04 48 65 6C 70 16 44 75 6D 70 73 20 6D 65 6D 6F 72 79 20 61 73 20 62 79 74 65 73 2E ) // ....S..Name.dbS..DefaultOptions...ascii.true....unicode.false...ascii.string.false...unicode.string.false..c.128..l.1...w.16S..Help.Dumps.memory.as.bytes.
  .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 02 64 63 53 0E 0E 44 65 66 61 75 6C 74 4F 70 74 69 6F 6E 73 5B 2D 2D 61 73 63 69 69 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 3A 74 72 75 65 20 20 2D 2D 61 73 63 69 69 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 63 3A 36 34 20 20 2D 6C 3A 32 20 20 2D 77 3A 38 53 0E 04 48 65 6C 70 16 44 75 6D 70 73 20 6D 65 6D 6F 72 79 20 61 73 20 63 68 61 72 73 2E ) // ....S..Name.dcS..DefaultOptions...ascii.false...unicode.true....ascii.string.false...unicode.string.false..c.64...l.2...w.8S..Help.Dumps.memory.as.chars.
  .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 02 64 61 53 0E 0E 44 65 66 61 75 6C 74 4F 70 74 69 6F 6E 73 5B 2D 2D 61 73 63 69 69 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 3A 66 61 6C 73 65 20 2D 2D 61 73 63 69 69 2D 73 74 72 69 6E 67 3A 74 72 75 65 20 20 2D 2D 75 6E 69 63 6F 64 65 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 63 3A 31 32 38 20 2D 6C 3A 31 20 20 2D 77 3A 30 53 0E 04 48 65 6C 70 2D 44 75 6D 70 73 20 6D 65 6D 6F 72 79 20 61 73 20 7A 65 72 6F 2D 74 65 72 6D 69 6E 61 74 65 64 20 62 79 74 65 20 73 74 72 69 6E 67 73 2E ) // ....S..Name.daS..DefaultOptions...ascii.false...unicode.false...ascii.string.true....unicode.string.false..c.128..l.1...w.0S..Help.Dumps.memory.as.zero.terminated.byte.strings.
  .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 02 64 75 53 0E 0E 44 65 66 61 75 6C 74 4F 70 74 69 6F 6E 73 5B 2D 2D 61 73 63 69 69 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 3A 66 61 6C 73 65 20 2D 2D 61 73 63 69 69 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 2D 73 74 72 69 6E 67 3A 74 72 75 65 20 20 2D 63 3A 31 32 38 20 2D 6C 3A 32 20 20 2D 77 3A 30 53 0E 04 48 65 6C 70 2D 44 75 6D 70 73 20 6D 65 6D 6F 72 79 20 61 73 20 7A 65 72 6F 2D 74 65 72 6D 69 6E 61 74 65 64 20 63 68 61 72 20 73 74 72 69 6E 67 73 2E ) // ....S..Name.duS..DefaultOptions...ascii.false...unicode.false...ascii.string.false...unicode.string.true...c.128..l.2...w.0S..Help.Dumps.memory.as.zero.terminated.char.strings.
  .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 02 64 77 53 0E 0E 44 65 66 61 75 6C 74 4F 70 74 69 6F 6E 73 5B 2D 2D 61 73 63 69 69 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 3A 66 61 6C 73 65 20 2D 2D 61 73 63 69 69 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 63 3A 31 32 38 20 2D 6C 3A 32 20 20 2D 77 3A 30 53 0E 04 48 65 6C 70 1F 44 75 6D 70 73 20 6D 65 6D 6F 72 79 20 61 73 20 77 6F 72 64 73 20 28 75 73 68 6F 72 74 29 2E ) // ....S..Name.dwS..DefaultOptions...ascii.false...unicode.false...ascii.string.false...unicode.string.false..c.128..l.2...w.0S..Help.Dumps.memory.as.words..ushort..
  .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 02 64 64 53 0E 0E 44 65 66 61 75 6C 74 4F 70 74 69 6F 6E 73 5B 2D 2D 61 73 63 69 69 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 3A 66 61 6C 73 65 20 2D 2D 61 73 63 69 69 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 63 3A 36 34 20 20 2D 6C 3A 34 20 20 2D 77 3A 30 53 0E 04 48 65 6C 70 1E 44 75 6D 70 73 20 6D 65 6D 6F 72 79 20 61 73 20 64 77 6F 72 64 73 20 28 75 69 6E 74 29 2E ) // ....S..Name.ddS..DefaultOptions...ascii.false...unicode.false...ascii.string.false...unicode.string.false..c.64...l.4...w.0S..Help.Dumps.memory.as.dwords..uint..
  .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 02 64 70 53 0E 0E 44 65 66 61 75 6C 74 4F 70 74 69 6F 6E 73 5B 2D 2D 61 73 63 69 69 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 3A 66 61 6C 73 65 20 2D 2D 61 73 63 69 69 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 63 3A 33 32 20 20 2D 6C 3A 2D 31 20 2D 77 3A 30 53 0E 04 48 65 6C 70 19 44 75 6D 70 73 20 6D 65 6D 6F 72 79 20 61 73 20 70 6F 69 6E 74 65 72 73 2E ) // ....S..Name.dpS..DefaultOptions...ascii.false...unicode.false...ascii.string.false...unicode.string.false..c.32...l..1..w.0S..Help.Dumps.memory.as.pointers.
  .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 02 64 71 53 0E 0E 44 65 66 61 75 6C 74 4F 70 74 69 6F 6E 73 5B 2D 2D 61 73 63 69 69 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 3A 66 61 6C 73 65 20 2D 2D 61 73 63 69 69 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 2D 75 6E 69 63 6F 64 65 2D 73 74 72 69 6E 67 3A 66 61 6C 73 65 20 2D 63 3A 33 32 20 20 2D 6C 3A 38 20 20 2D 77 3A 30 53 0E 04 48 65 6C 70 1F 44 75 6D 70 73 20 6D 65 6D 6F 72 79 20 61 73 20 71 77 6F 72 64 73 20 28 75 6C 6F 6E 67 29 2E ) // ....S..Name.dqS..DefaultOptions...ascii.false...unicode.false...ascii.string.false...unicode.string.false..c.32...l.8...w.0S..Help.Dumps.memory.as.qwords..ulong..

  .field private static int32 '<Count>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private static int32 '<Length>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private static int32 '<Width>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private static bool '<Ascii>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private static bool '<Unicode>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private static bool '<AsciiString>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private static bool '<UnicodeString>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private bool '<HexPrefix>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private bool '<ShowAddress>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService '<MemoryService>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ITarget '<Target>k__BackingField'
  .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....

  .field private class [netstandard]System.Nullable`1<System.UInt64> _address

  .field private class [netstandard]System.Nullable`1<System.UInt64> _endAddress

  .field private static uint64 _lastAddress

  .method public hidebysig specialname instance default string get_AddressValue() cil managed
  {
    // Method begins at Relative Virtual Address (RVA) 0x4F14
    // Code size 31 (0x1F)
    .maxstack 2
    .locals init(uint64 V_0)
    IL_0000: ldarg.0
    IL_0001: ldflda class [netstandard]System.Nullable`1<System.UInt64> Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_address
    IL_0006: dup
    IL_0007: call instance bool class [netstandard]System.Nullable`1<System.UInt64>::get_HasValue()
    IL_000c: brtrue.s     IL_0011
    IL_000e: pop
    IL_000f: ldnull
    IL_0010: ret
    IL_0011: call instance var class [netstandard]System.Nullable`1<System.UInt64>::GetValueOrDefault()
    IL_0016: stloc.0
    IL_0017: ldloca.s class V_0
    IL_0019: call instance string class uint64::ToString()
    IL_001e: ret
  } // End of method System.String Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_AddressValue()

  .method public hidebysig specialname instance default void set_AddressValue(string 'value') cil managed
  {
    // Method begins at Relative Virtual Address (RVA) 0x4F3F
    // Code size 14 (0xE)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldarg.0
    IL_0002: ldarg.1
    IL_0003: call instance [netstandard]System.Nullable`1<System.UInt64> class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandBase::ParseAddress(string)
    IL_0008: stfld class [netstandard]System.Nullable`1<System.UInt64> Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_address
    IL_000d: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_AddressValue(System.String)

  .method public hidebysig specialname instance default string get_EndAddressValue() cil managed
  {
    // Method begins at Relative Virtual Address (RVA) 0x4F50
    // Code size 31 (0x1F)
    .maxstack 2
    .locals init(uint64 V_0)
    IL_0000: ldarg.0
    IL_0001: ldflda class [netstandard]System.Nullable`1<System.UInt64> Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_endAddress
    IL_0006: dup
    IL_0007: call instance bool class [netstandard]System.Nullable`1<System.UInt64>::get_HasValue()
    IL_000c: brtrue.s     IL_0011
    IL_000e: pop
    IL_000f: ldnull
    IL_0010: ret
    IL_0011: call instance var class [netstandard]System.Nullable`1<System.UInt64>::GetValueOrDefault()
    IL_0016: stloc.0
    IL_0017: ldloca.s class V_0
    IL_0019: call instance string class uint64::ToString()
    IL_001e: ret
  } // End of method System.String Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_EndAddressValue()

  .method public hidebysig specialname instance default void set_EndAddressValue(string 'value') cil managed
  {
    // Method begins at Relative Virtual Address (RVA) 0x4F7B
    // Code size 14 (0xE)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldarg.0
    IL_0002: ldarg.1
    IL_0003: call instance [netstandard]System.Nullable`1<System.UInt64> class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandBase::ParseAddress(string)
    IL_0008: stfld class [netstandard]System.Nullable`1<System.UInt64> Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_endAddress
    IL_000d: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_EndAddressValue(System.String)

  .method public hidebysig specialname static default int32 get_Count() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4F8A
    // Code size 6 (0x6)
    .maxstack 8
    IL_0000: ldsfld int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Count>k__BackingField'
    IL_0005: ret
  } // End of method System.Int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Count()

  .method public hidebysig specialname static default void set_Count(int32 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4F91
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: stsfld int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Count>k__BackingField'
    IL_0006: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Count(System.Int32)

  .method public hidebysig specialname static default int32 get_Length() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4F99
    // Code size 6 (0x6)
    .maxstack 8
    IL_0000: ldsfld int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Length>k__BackingField'
    IL_0005: ret
  } // End of method System.Int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Length()

  .method public hidebysig specialname static default void set_Length(int32 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FA0
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: stsfld int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Length>k__BackingField'
    IL_0006: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Length(System.Int32)

  .method public hidebysig specialname static default int32 get_Width() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FA8
    // Code size 6 (0x6)
    .maxstack 8
    IL_0000: ldsfld int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Width>k__BackingField'
    IL_0005: ret
  } // End of method System.Int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Width()

  .method public hidebysig specialname static default void set_Width(int32 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FAF
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: stsfld int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Width>k__BackingField'
    IL_0006: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Width(System.Int32)

  .method public hidebysig specialname static default bool get_Ascii() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FB7
    // Code size 6 (0x6)
    .maxstack 8
    IL_0000: ldsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Ascii>k__BackingField'
    IL_0005: ret
  } // End of method System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Ascii()

  .method public hidebysig specialname static default void set_Ascii(bool 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FBE
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: stsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Ascii>k__BackingField'
    IL_0006: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Ascii(System.Boolean)

  .method public hidebysig specialname static default bool get_Unicode() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FC6
    // Code size 6 (0x6)
    .maxstack 8
    IL_0000: ldsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Unicode>k__BackingField'
    IL_0005: ret
  } // End of method System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Unicode()

  .method public hidebysig specialname static default void set_Unicode(bool 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FCD
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: stsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Unicode>k__BackingField'
    IL_0006: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Unicode(System.Boolean)

  .method public hidebysig specialname static default bool get_AsciiString() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FD5
    // Code size 6 (0x6)
    .maxstack 8
    IL_0000: ldsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<AsciiString>k__BackingField'
    IL_0005: ret
  } // End of method System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_AsciiString()

  .method public hidebysig specialname static default void set_AsciiString(bool 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FDC
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: stsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<AsciiString>k__BackingField'
    IL_0006: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_AsciiString(System.Boolean)

  .method public hidebysig specialname static default bool get_UnicodeString() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FE4
    // Code size 6 (0x6)
    .maxstack 8
    IL_0000: ldsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<UnicodeString>k__BackingField'
    IL_0005: ret
  } // End of method System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_UnicodeString()

  .method public hidebysig specialname static default void set_UnicodeString(bool 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FEB
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: stsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<UnicodeString>k__BackingField'
    IL_0006: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_UnicodeString(System.Boolean)

  .method public hidebysig specialname instance default bool get_HexPrefix() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FF3
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<HexPrefix>k__BackingField'
    IL_0006: ret
  } // End of method System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_HexPrefix()

  .method public hidebysig specialname instance default void set_HexPrefix(bool 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x4FFB
    // Code size 8 (0x8)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldarg.1
    IL_0002: stfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<HexPrefix>k__BackingField'
    IL_0007: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_HexPrefix(System.Boolean)

  .method public hidebysig specialname instance default bool get_ShowAddress() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x5004
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<ShowAddress>k__BackingField'
    IL_0006: ret
  } // End of method System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_ShowAddress()

  .method public hidebysig specialname instance default void set_ShowAddress(bool 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x500C
    // Code size 8 (0x8)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldarg.1
    IL_0002: stfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<ShowAddress>k__BackingField'
    IL_0007: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_ShowAddress(System.Boolean)

  .method public hidebysig specialname instance default [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService get_MemoryService() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x5015
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldfld class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<MemoryService>k__BackingField'
    IL_0006: ret
  } // End of method Microsoft.Diagnostics.DebugServices.IMemoryService Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_MemoryService()

  .method public hidebysig specialname instance default void set_MemoryService(class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x501D
    // Code size 8 (0x8)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldarg.1
    IL_0002: stfld class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<MemoryService>k__BackingField'
    IL_0007: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_MemoryService(Microsoft.Diagnostics.DebugServices.IMemoryService)

  .method public hidebysig specialname instance default [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ITarget get_Target() cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x5026
    // Code size 7 (0x7)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldfld class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ITarget Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Target>k__BackingField'
    IL_0006: ret
  } // End of method Microsoft.Diagnostics.DebugServices.ITarget Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Target()

  .method public hidebysig specialname instance default void set_Target(class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ITarget 'value') cil managed
  {
    .custom instance void class [netstandard]System.Runtime.CompilerServices.CompilerGeneratedAttribute::.ctor() = ( 01 00 00 00 ) // ....
    // Method begins at Relative Virtual Address (RVA) 0x502E
    // Code size 8 (0x8)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldarg.1
    IL_0002: stfld class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ITarget Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Target>k__BackingField'
    IL_0007: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Target(Microsoft.Diagnostics.DebugServices.ITarget)

  .method public hidebysig virtual instance default void Invoke() cil managed
  {
    // Method begins at Relative Virtual Address (RVA) 0x5038
    // Code size 862 (0x35E)
    .maxstack 6
    .locals init(int32 V_0, int32 V_1, class [netstandard]System.Text.StringBuilder V_2, char V_3, valuetype [netstandard]System.Threading.CancellationToken V_4, int32 V_5, int32 V_6, uint64 V_7, class [netstandard]System.Text.StringBuilder V_8, int32 V_9, int32 V_10, byte[] V_11, int32 V_12, int32 V_13, int32 V_14, char V_15)
    IL_0000: ldarg.0
    IL_0001: ldflda class [netstandard]System.Nullable`1<System.UInt64> Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_address
    IL_0006: call instance bool class [netstandard]System.Nullable`1<System.UInt64>::get_HasValue()
    IL_000b: brfalse.s     IL_001d
    IL_000d: ldarg.0
    IL_000e: ldflda class [netstandard]System.Nullable`1<System.UInt64> Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_address
    IL_0013: call instance var class [netstandard]System.Nullable`1<System.UInt64>::get_Value()
    IL_0018: stsfld uint64 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_lastAddress
    IL_001d: call int32 class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Length()
    IL_0022: stloc.0
    IL_0023: ldloc.0
    IL_0024: ldc.i4.0
    IL_0025: bge.s     IL_0033
    IL_0027: ldarg.0
    IL_0028: call instance [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_MemoryService()
    IL_002d: callvirt instance int32 class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService::get_PointerSize()
    IL_0032: stloc.0
    IL_0033: ldloc.0
    IL_0034: ldc.i4.1
    IL_0035: sub
    IL_0036: ldc.i4.1
    IL_0037: ble.un.s     IL_0043
    IL_0039: ldloc.0
    IL_003a: ldc.i4.4
    IL_003b: beq.s     IL_0043
    IL_003d: ldloc.0
    IL_003e: ldc.i4.8
    IL_003f: beq.s     IL_0043
    IL_0041: ldc.i4.4
    IL_0042: stloc.0
    IL_0043: ldloc.0
    IL_0044: call void class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Length(int32)
    IL_0049: ldarg.0
    IL_004a: ldflda class [netstandard]System.Nullable`1<System.UInt64> Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_endAddress
    IL_004f: call instance bool class [netstandard]System.Nullable`1<System.UInt64>::get_HasValue()
    IL_0054: brfalse.s     IL_008e
    IL_0056: ldarg.0
    IL_0057: ldflda class [netstandard]System.Nullable`1<System.UInt64> Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_endAddress
    IL_005c: call instance var class [netstandard]System.Nullable`1<System.UInt64>::get_Value()
    IL_0061: ldsfld uint64 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_lastAddress
    IL_0066: bgt.un.s     IL_0073
    IL_0068: ldstr "Cannot dump a negative range"
    IL_006d: newobj instance void class [netstandard]System.ArgumentException::.ctor(string)
    IL_0072: throw
    IL_0073: ldarg.0
    IL_0074: ldflda class [netstandard]System.Nullable`1<System.UInt64> Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_endAddress
    IL_0079: call instance var class [netstandard]System.Nullable`1<System.UInt64>::get_Value()
    IL_007e: ldsfld uint64 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_lastAddress
    IL_0083: sub.ovf.un
    IL_0084: conv.ovf.i4.un
    IL_0085: stloc.1
    IL_0086: ldloc.1
    IL_0087: ldloc.0
    IL_0088: div
    IL_0089: call void class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Count(int32)
    IL_008e: call bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_AsciiString()
    IL_0093: brtrue.s     IL_009c
    IL_0095: call bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_UnicodeString()
    IL_009a: brfalse.s     IL_0107
    IL_009c: newobj instance void class [netstandard]System.Text.StringBuilder::.ctor()
    IL_00a1: stloc.2
    IL_00a2: ldarg.0
    IL_00a3: ldsfld uint64 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_lastAddress
    IL_00a8: call bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_UnicodeString()
    IL_00ad: ldc.i4.1
    IL_00ae: call instance char class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::ReadChar(uint64, bool, bool)
    IL_00b3: stloc.3
    IL_00b4: ldsfld uint64 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_lastAddress
    IL_00b9: call bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_UnicodeString()
    IL_00be: brtrue.s     IL_00c3
    IL_00c0: ldc.i4.1
    IL_00c1: br.s     IL_00c4
    IL_00c3: ldc.i4.2
    IL_00c4: conv.ovf.u8
    IL_00c5: add.ovf.un
    IL_00c6: stsfld uint64 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_lastAddress
    IL_00cb: ldloc.3
    IL_00cc: brfalse.s     IL_00ec
    IL_00ce: ldloc.2
    IL_00cf: ldloc.3
    IL_00d0: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Append(char)
    IL_00d5: pop
    IL_00d6: ldarg.0
    IL_00d7: call instance [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IConsoleService class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandBase::get_Console()
    IL_00dc: callvirt instance valuetype [netstandard]System.Threading.CancellationToken class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IConsoleService::get_CancellationToken()
    IL_00e1: stloc.s class V_4
    IL_00e3: ldloca.s class V_4
    IL_00e5: call instance void class valuetype [netstandard]System.Threading.CancellationToken::ThrowIfCancellationRequested()
    IL_00ea: br.s     IL_00a2
    IL_00ec: ldarg.0
    IL_00ed: ldstr "Text: '{0}'"
    IL_00f2: ldc.i4.1
    IL_00f3: newarr class System.Object
    IL_00f8: dup
    IL_00f9: ldc.i4.0
    IL_00fa: ldloc.2
    IL_00fb: callvirt instance string class [netstandard]System.Object::ToString()
    IL_0100: stelem.ref
    IL_0101: call instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandBase::WriteLine(string, [netstandard]System.Object[])
    IL_0106: ret
    IL_0107: call int32 class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Count()
    IL_010c: ldc.i4.0
    IL_010d: bgt.s     IL_0113
    IL_010f: ldc.i4.s 32
    IL_0111: br.s     IL_0118
    IL_0113: call int32 class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Count()
    IL_0118: stloc.s class V_5
    IL_011a: ldloc.s class V_5
    IL_011c: call void class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Count(int32)
    IL_0121: call int32 class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Width()
    IL_0126: ldc.i4.0
    IL_0127: bgt.s     IL_012f
    IL_0129: ldc.i4.s 32
    IL_012b: ldloc.0
    IL_012c: div
    IL_012d: br.s     IL_0134
    IL_012f: call int32 class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Width()
    IL_0134: stloc.s class V_6
    IL_0136: ldloc.s class V_6
    IL_0138: call void class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Width(int32)
    IL_013d: ldloc.s class V_5
    IL_013f: ldloc.0
    IL_0140: mul.ovf
    IL_0141: stloc.s class V_5
    IL_0143: ldsfld uint64 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_lastAddress
    IL_0148: stloc.s class V_7
    IL_014a: newobj instance void class [netstandard]System.Text.StringBuilder::.ctor()
    IL_014f: stloc.s class V_8
    IL_0151: br     IL_034e
    IL_0156: ldarg.0
    IL_0157: call instance bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_ShowAddress()
    IL_015c: brfalse.s     IL_0172
    IL_015e: ldloc.s class V_8
    IL_0160: ldstr "{0:x16}:"
    IL_0165: ldloc.s class V_7
    IL_0167: box class System.UInt64
    IL_016c: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::AppendFormat(string, [netstandard]System.Object)
    IL_0171: pop
    IL_0172: ldc.i4.0
    IL_0173: stloc.s class V_9
    IL_0175: br     IL_02b3
    IL_017a: ldloc.s class V_9
    IL_017c: ldloc.0
    IL_017d: mul.ovf
    IL_017e: stloc.s class V_10
    IL_0180: ldloc.s class V_8
    IL_0182: ldc.i4.s 32
    IL_0184: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Append(char)
    IL_0189: pop
    IL_018a: ldloc.s class V_10
    IL_018c: ldloc.s class V_5
    IL_018e: bge     IL_028b
    IL_0193: ldloc.0
    IL_0194: newarr class System.Byte
    IL_0199: stloc.s class V_11
    IL_019b: ldarg.0
    IL_019c: call instance [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_MemoryService()
    IL_01a1: ldloc.s class V_7
    IL_01a3: ldloc.s class V_10
    IL_01a5: conv.ovf.u8
    IL_01a6: add.ovf.un
    IL_01a7: ldloc.s class V_11
    IL_01a9: ldloc.0
    IL_01aa: ldloca.s class V_12
    IL_01ac: call bool class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.MemoryServiceExtensions::ReadMemory([Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService, uint64, byte[], int32, byreference)
    IL_01b1: brtrue.s     IL_01ba
    IL_01b3: call !!0[] class [netstandard]System.Array::Empty<byte>()
    IL_01b8: stloc.s class V_11
    IL_01ba: ldloc.s class V_12
    IL_01bc: ldloc.0
    IL_01bd: blt     IL_0267
    IL_01c2: ldarg.0
    IL_01c3: call instance bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_HexPrefix()
    IL_01c8: brfalse.s     IL_01d7
    IL_01ca: ldloc.s class V_8
    IL_01cc: ldstr "0x"
    IL_01d1: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Append(string)
    IL_01d6: pop
    IL_01d7: ldloc.0
    IL_01d8: ldc.i4.1
    IL_01d9: sub
    IL_01da: switch class Mono.Cecil.Cil.Instruction[]
    IL_01ef: ldloc.0
    IL_01f0: ldc.i4.8
    IL_01f1: beq.s     IL_024b
    IL_01f3: br     IL_02ad
    IL_01f8: ldloc.s class V_8
    IL_01fa: ldstr "{0:x2}"
    IL_01ff: ldloc.s class V_11
    IL_0201: ldc.i4.0
    IL_0202: ldelem.u1
    IL_0203: box class System.Byte
    IL_0208: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::AppendFormat(string, [netstandard]System.Object)
    IL_020d: pop
    IL_020e: br     IL_02ad
    IL_0213: ldloc.s class V_8
    IL_0215: ldstr "{0:x4}"
    IL_021a: ldloc.s class V_11
    IL_021c: ldc.i4.0
    IL_021d: call uint16 class [netstandard]System.BitConverter::ToUInt16(byte[], int32)
    IL_0222: box class System.UInt16
    IL_0227: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::AppendFormat(string, [netstandard]System.Object)
    IL_022c: pop
    IL_022d: br.s     IL_02ad
    IL_022f: ldloc.s class V_8
    IL_0231: ldstr "{0:x8}"
    IL_0236: ldloc.s class V_11
    IL_0238: ldc.i4.0
    IL_0239: call uint32 class [netstandard]System.BitConverter::ToUInt32(byte[], int32)
    IL_023e: box class System.UInt32
    IL_0243: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::AppendFormat(string, [netstandard]System.Object)
    IL_0248: pop
    IL_0249: br.s     IL_02ad
    IL_024b: ldloc.s class V_8
    IL_024d: ldstr "{0:x16}"
    IL_0252: ldloc.s class V_11
    IL_0254: ldc.i4.0
    IL_0255: call uint64 class [netstandard]System.BitConverter::ToUInt64(byte[], int32)
    IL_025a: box class System.UInt64
    IL_025f: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::AppendFormat(string, [netstandard]System.Object)
    IL_0264: pop
    IL_0265: br.s     IL_02ad
    IL_0267: ldarg.0
    IL_0268: call instance bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_HexPrefix()
    IL_026d: brfalse.s     IL_027c
    IL_026f: ldloc.s class V_8
    IL_0271: ldstr "  "
    IL_0276: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Append(string)
    IL_027b: pop
    IL_027c: ldloc.s class V_8
    IL_027e: ldc.i4.s 63
    IL_0280: ldloc.0
    IL_0281: ldc.i4.2
    IL_0282: mul.ovf
    IL_0283: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Append(char, int32)
    IL_0288: pop
    IL_0289: br.s     IL_02ad
    IL_028b: ldarg.0
    IL_028c: call instance bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_HexPrefix()
    IL_0291: brfalse.s     IL_02a0
    IL_0293: ldloc.s class V_8
    IL_0295: ldstr "  "
    IL_029a: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Append(string)
    IL_029f: pop
    IL_02a0: ldloc.s class V_8
    IL_02a2: ldc.i4.s 32
    IL_02a4: ldloc.0
    IL_02a5: ldc.i4.2
    IL_02a6: mul.ovf
    IL_02a7: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Append(char, int32)
    IL_02ac: pop
    IL_02ad: ldloc.s class V_9
    IL_02af: ldc.i4.1
    IL_02b0: add.ovf
    IL_02b1: stloc.s class V_9
    IL_02b3: ldloc.s class V_9
    IL_02b5: ldloc.s class V_6
    IL_02b7: blt     IL_017a
    IL_02bc: call bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Ascii()
    IL_02c1: brtrue.s     IL_02ca
    IL_02c3: call bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Unicode()
    IL_02c8: brfalse.s     IL_0312
    IL_02ca: ldloc.s class V_8
    IL_02cc: ldstr "  "
    IL_02d1: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Append(string)
    IL_02d6: pop
    IL_02d7: ldc.i4.0
    IL_02d8: stloc.s class V_13
    IL_02da: br.s     IL_030c
    IL_02dc: ldloc.s class V_13
    IL_02de: ldloc.0
    IL_02df: mul.ovf
    IL_02e0: stloc.s class V_14
    IL_02e2: ldloc.s class V_14
    IL_02e4: ldloc.s class V_5
    IL_02e6: bge.s     IL_0306
    IL_02e8: ldarg.0
    IL_02e9: ldloc.s class V_7
    IL_02eb: ldloc.s class V_14
    IL_02ed: conv.ovf.u8
    IL_02ee: add.ovf.un
    IL_02ef: call bool class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Unicode()
    IL_02f4: ldc.i4.0
    IL_02f5: call instance char class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::ReadChar(uint64, bool, bool)
    IL_02fa: stloc.s class V_15
    IL_02fc: ldloc.s class V_8
    IL_02fe: ldloc.s class V_15
    IL_0300: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Append(char)
    IL_0305: pop
    IL_0306: ldloc.s class V_13
    IL_0308: ldc.i4.1
    IL_0309: add.ovf
    IL_030a: stloc.s class V_13
    IL_030c: ldloc.s class V_13
    IL_030e: ldloc.s class V_6
    IL_0310: blt.s     IL_02dc
    IL_0312: ldloc.s class V_7
    IL_0314: ldloc.s class V_6
    IL_0316: ldloc.0
    IL_0317: mul.ovf
    IL_0318: conv.ovf.u8
    IL_0319: add.ovf.un
    IL_031a: stloc.s class V_7
    IL_031c: ldloc.s class V_5
    IL_031e: ldloc.s class V_6
    IL_0320: ldloc.0
    IL_0321: mul.ovf
    IL_0322: sub.ovf
    IL_0323: stloc.s class V_5
    IL_0325: ldarg.0
    IL_0326: ldloc.s class V_8
    IL_0328: callvirt instance string class [netstandard]System.Object::ToString()
    IL_032d: call instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandBase::WriteLine(string)
    IL_0332: ldloc.s class V_8
    IL_0334: callvirt instance [netstandard]System.Text.StringBuilder class [netstandard]System.Text.StringBuilder::Clear()
    IL_0339: pop
    IL_033a: ldarg.0
    IL_033b: call instance [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IConsoleService class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandBase::get_Console()
    IL_0340: callvirt instance valuetype [netstandard]System.Threading.CancellationToken class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IConsoleService::get_CancellationToken()
    IL_0345: stloc.s class V_4
    IL_0347: ldloca.s class V_4
    IL_0349: call instance void class valuetype [netstandard]System.Threading.CancellationToken::ThrowIfCancellationRequested()
    IL_034e: ldloc.s class V_5
    IL_0350: ldc.i4.0
    IL_0351: bgt     IL_0156
    IL_0356: ldloc.s class V_7
    IL_0358: stsfld uint64 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::_lastAddress
    IL_035d: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::Invoke()

  .method private hidebysig instance default char ReadChar(uint64 address, bool unicode, bool zeroOk) cil managed
  {
    // Method begins at Relative Virtual Address (RVA) 0x53A4
    // Code size 96 (0x60)
    .maxstack 5
    .locals init(char V_0, int32 V_1, byte[] V_2, int32 V_3, bool V_4)
    IL_0000: ldarg.2
    IL_0001: brtrue.s     IL_0006
    IL_0003: ldc.i4.1
    IL_0004: br.s     IL_0007
    IL_0006: ldc.i4.2
    IL_0007: stloc.1
    IL_0008: ldloc.1
    IL_0009: newarr class System.Byte
    IL_000e: stloc.2
    IL_000f: ldarg.0
    IL_0010: call instance [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_MemoryService()
    IL_0015: ldarg.1
    IL_0016: ldloc.2
    IL_0017: ldloc.1
    IL_0018: ldloca.s class V_3
    IL_001a: call bool class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.MemoryServiceExtensions::ReadMemory([Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService, uint64, byte[], int32, byreference)
    IL_001f: brfalse.s     IL_0038
    IL_0021: ldloc.3
    IL_0022: ldloc.1
    IL_0023: blt.s     IL_0038
    IL_0025: ldarg.2
    IL_0026: brfalse.s     IL_0032
    IL_0028: ldloc.2
    IL_0029: ldc.i4.0
    IL_002a: call char class [netstandard]System.BitConverter::ToChar(byte[], int32)
    IL_002f: stloc.0
    IL_0030: br.s     IL_003b
    IL_0032: ldloc.2
    IL_0033: ldc.i4.0
    IL_0034: ldelem.u1
    IL_0035: stloc.0
    IL_0036: br.s     IL_003b
    IL_0038: ldc.i4.s 63
    IL_003a: stloc.0
    IL_003b: ldloc.0
    IL_003c: ldc.i4.0
    IL_003d: ceq
    IL_003f: ldarg.3
    IL_0040: and
    IL_0041: brfalse.s     IL_0045
    IL_0043: ldloc.0
    IL_0044: ret
    IL_0045: ldloc.0
    IL_0046: ldc.i4.s 32
    IL_0048: blt.s     IL_004f
    IL_004a: ldloc.0
    IL_004b: ldc.i4.s 126
    IL_004d: ble.s     IL_0054
    IL_004f: ldc.i4.1
    IL_0050: stloc.s class V_4
    IL_0052: br.s     IL_0057
    IL_0054: ldc.i4.0
    IL_0055: stloc.s class V_4
    IL_0057: ldloc.s class V_4
    IL_0059: brfalse.s     IL_005e
    IL_005b: ldc.i4.s 46
    IL_005d: stloc.0
    IL_005e: ldloc.0
    IL_005f: ret
  } // End of method System.Char Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::ReadChar(System.UInt64,System.Boolean,System.Boolean)

  .method public hidebysig specialname rtspecialname instance default void .ctor() cil managed
  {
    // Method begins at Relative Virtual Address (RVA) 0x5410
    // Code size 14 (0xE)
    .maxstack 8
    IL_0000: ldarg.0
    IL_0001: ldc.i4.1
    IL_0002: stfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<ShowAddress>k__BackingField'
    IL_0007: ldarg.0
    IL_0008: call instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.CommandBase::.ctor()
    IL_000d: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::.ctor()

  .method private hidebysig specialname rtspecialname static default void .cctor() cil managed
  {
    // Method begins at Relative Virtual Address (RVA) 0x541F
    // Code size 44 (0x2C)
    .maxstack 8
    IL_0000: ldc.i4.s 32
    IL_0002: stsfld int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Count>k__BackingField'
    IL_0007: ldc.i4.0
    IL_0008: stsfld int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Length>k__BackingField'
    IL_000d: ldc.i4.0
    IL_000e: stsfld int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Width>k__BackingField'
    IL_0013: ldc.i4.0
    IL_0014: stsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Ascii>k__BackingField'
    IL_0019: ldc.i4.0
    IL_001a: stsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<Unicode>k__BackingField'
    IL_001f: ldc.i4.0
    IL_0020: stsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<AsciiString>k__BackingField'
    IL_0025: ldc.i4.0
    IL_0026: stsfld bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::'<UnicodeString>k__BackingField'
    IL_002b: ret
  } // End of method System.Void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::.cctor()

  .property instance string AddressValue ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ArgumentAttribute::.ctor() = ( 01 00 02 00 53 0E 04 4E 61 6D 65 07 61 64 64 72 65 73 73 53 0E 04 48 65 6C 70 10 41 64 64 72 65 73 73 20 74 6F 20 64 75 6D 70 2E ) // ....S..Name.addressS..Help.Address.to.dump.
    .get instance default string Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_AddressValue ()
    .set instance default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_AddressValue (string 'value')
  } // End of property System.String Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::AddressValue()

  .property instance string EndAddressValue ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 05 2D 2D 65 6E 64 53 1D 0E 07 41 6C 69 61 73 65 73 01 00 00 00 02 2D 65 53 0E 04 48 65 6C 70 17 45 6E 64 69 6E 67 20 61 64 64 72 65 73 73 20 74 6F 20 64 75 6D 70 2E ) // ....S..Name...endS...Aliases......eS..Help.Ending.address.to.dump.
    .get instance default string Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_EndAddressValue ()
    .set instance default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_EndAddressValue (string 'value')
  } // End of property System.String Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::EndAddressValue()

  .property int32 Count ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 07 2D 2D 63 6F 75 6E 74 53 1D 0E 07 41 6C 69 61 73 65 73 01 00 00 00 02 2D 63 53 0E 04 48 65 6C 70 1B 4E 75 6D 62 65 72 20 6F 66 20 65 6C 65 6D 65 6E 74 73 20 74 6F 20 64 75 6D 70 2E ) // ....S..Name...countS...Aliases......cS..Help.Number.of.elements.to.dump.
    .get default int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Count ()
    .set default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Count (int32 'value')
  } // End of property System.Int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::Count()

  .property int32 Length ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 08 2D 2D 6C 65 6E 67 74 68 53 1D 0E 07 41 6C 69 61 73 65 73 01 00 00 00 02 2D 6C 53 0E 04 48 65 6C 70 19 53 69 7A 65 20 6F 66 20 65 6C 65 6D 65 6E 74 73 20 74 6F 20 64 75 6D 70 2E ) // ....S..Name...lengthS...Aliases......lS..Help.Size.of.elements.to.dump.
    .get default int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Length ()
    .set default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Length (int32 'value')
  } // End of property System.Int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::Length()

  .property int32 Width ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 07 2D 2D 77 69 64 74 68 53 1D 0E 07 41 6C 69 61 73 65 73 01 00 00 00 02 2D 77 53 0E 04 48 65 6C 70 23 4E 75 6D 62 65 72 20 6F 66 20 65 6C 65 6D 65 6E 74 73 20 74 6F 20 64 75 6D 70 20 70 65 72 20 72 6F 77 2E ) // ....S..Name...widthS...Aliases......wS..Help.Number.of.elements.to.dump.per.row.
    .get default int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Width ()
    .set default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Width (int32 'value')
  } // End of property System.Int32 Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::Width()

  .property bool Ascii ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 07 2D 2D 61 73 63 69 69 53 1D 0E 07 41 6C 69 61 73 65 73 01 00 00 00 02 2D 61 53 0E 04 48 65 6C 70 19 50 72 69 6E 74 20 61 73 63 69 69 20 64 75 6D 70 20 61 73 20 77 65 6C 6C 2E ) // ....S..Name...asciiS...Aliases......aS..Help.Print.ascii.dump.as.well.
    .get default bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Ascii ()
    .set default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Ascii (bool 'value')
  } // End of property System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::Ascii()

  .property bool Unicode ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 09 2D 2D 75 6E 69 63 6F 64 65 53 1D 0E 07 41 6C 69 61 73 65 73 01 00 00 00 02 2D 75 53 0E 04 48 65 6C 70 1B 50 72 69 6E 74 20 75 6E 69 63 6F 64 65 20 64 75 6D 70 20 61 73 20 77 65 6C 6C 2E ) // ....S..Name...unicodeS...Aliases......uS..Help.Print.unicode.dump.as.well.
    .get default bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Unicode ()
    .set default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Unicode (bool 'value')
  } // End of property System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::Unicode()

  .property bool AsciiString ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 02 00 53 0E 04 4E 61 6D 65 0E 2D 2D 61 73 63 69 69 2D 73 74 72 69 6E 67 53 0E 04 48 65 6C 70 1E 50 72 69 6E 74 20 61 73 20 61 73 63 69 69 20 73 74 72 69 6E 67 20 61 73 20 77 65 6C 6C 2E ) // ....S..Name...ascii.stringS..Help.Print.as.ascii.string.as.well.
    .get default bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_AsciiString ()
    .set default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_AsciiString (bool 'value')
  } // End of property System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::AsciiString()

  .property bool UnicodeString ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 02 00 53 0E 04 4E 61 6D 65 10 2D 2D 75 6E 69 63 6F 64 65 2D 73 74 72 69 6E 67 53 0E 04 48 65 6C 70 20 50 72 69 6E 74 20 61 73 20 75 6E 69 63 6F 64 65 20 73 74 72 69 6E 67 20 61 73 20 77 65 6C 6C 2E ) // ....S..Name...unicode.stringS..Help.Print.as.unicode.string.as.well.
    .get default bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_UnicodeString ()
    .set default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_UnicodeString (bool 'value')
  } // End of property System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::UnicodeString()

  .property instance bool HexPrefix ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 03 00 53 0E 04 4E 61 6D 65 0C 2D 2D 68 65 78 2D 70 72 65 66 69 78 53 1D 0E 07 41 6C 69 61 73 65 73 01 00 00 00 02 2D 68 53 0E 04 48 65 6C 70 2C 41 64 64 20 61 20 68 65 78 20 70 72 65 66 69 78 20 28 30 78 29 20 74 6F 20 74 68 65 20 64 61 74 61 20 64 69 73 70 6C 61 79 65 64 2E ) // ....S..Name...hex.prefixS...Aliases......hS..Help.Add.a.hex.prefix..0x..to.the.data.displayed.
    .get instance default bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_HexPrefix ()
    .set instance default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_HexPrefix (bool 'value')
  } // End of property System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::HexPrefix()

  .property instance bool ShowAddress ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.OptionAttribute::.ctor() = ( 01 00 02 00 53 0E 04 4E 61 6D 65 0E 2D 2D 73 68 6F 77 2D 61 64 64 72 65 73 73 53 0E 04 48 65 6C 70 24 44 69 73 70 6C 61 79 20 74 68 65 20 61 64 64 72 65 73 73 65 73 20 6F 66 20 64 61 74 61 20 66 6F 75 6E 64 2E ) // ....S..Name...show.addressS..Help.Display.the.addresses.of.data.found.
    .get instance default bool Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_ShowAddress ()
    .set instance default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_ShowAddress (bool 'value')
  } // End of property System.Boolean Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::ShowAddress()

  .property instance [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService MemoryService ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ServiceImportAttribute::.ctor() = ( 01 00 00 00 ) // ....
    .get instance default [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_MemoryService ()
    .set instance default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_MemoryService ([Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.IMemoryService 'value')
  } // End of property Microsoft.Diagnostics.DebugServices.IMemoryService Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::MemoryService()

  .property instance [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ITarget Target ()
  {
    .custom instance void class [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ServiceImportAttribute::.ctor() = ( 01 00 00 00 ) // ....
    .get instance default [Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ITarget Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::get_Target ()
    .set instance default void Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::set_Target ([Microsoft.Diagnostics.DebugServices]Microsoft.Diagnostics.DebugServices.ITarget 'value')
  } // End of property Microsoft.Diagnostics.DebugServices.ITarget Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand::Target()
} // End of class Microsoft.Diagnostics.Tools.Dump.ReadMemoryCommand
