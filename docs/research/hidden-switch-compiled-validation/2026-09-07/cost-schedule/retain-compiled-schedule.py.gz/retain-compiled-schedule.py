from dataclasses import asdict
import gzip
import hashlib
import json
from pathlib import Path

from zeta_interp import hidden_switch_compiled_admission as admission
from zeta_interp import hidden_switch_compiled_schedule as schedule

root = Path.cwd().parents[1]
dest = root / 'docs/research/hidden-switch-compiled-validation/2026-09-07/cost-schedule'
dest.mkdir(exist_ok=False)
source = '33f66f382767f36dfde9933b87f76aa1144cbdaa'
rows = [asdict(row) for row in schedule.cost_schedule()]
result = schedule.admit_cost_schedule(rows)
assert isinstance(result, admission.Admitted), result
record = {'Schema': 'zeta.hidden-switch.compiled.cost-schedule.fixture.v1',
          'SourceCommit': source, 'Schedule': rows, 'Counts': asdict(result.value),
          'ArtifactStatus': 'Python header fixture; no native or measurement execution'}
raw_record = (json.dumps(record, indent=2) + '\n').encode()

def sha(raw):
    return hashlib.sha256(raw).hexdigest().upper()

artifacts = []
for name, raw, compress in [
    ('schedule.json', raw_record, False),
    ('compiled-schedule-tests-1.log.gz', (root / '.git/compiled-schedule-tests-1.log').read_bytes(), True),
    ('retain-compiled-schedule.py.gz', (root / '.git/retain-compiled-schedule.py').read_bytes(), True),
]:
    stored = gzip.compress(raw, mtime=0) if compress else raw
    with (dest / name).open('xb') as output:
        output.write(stored)
    descriptor = {'File': name, 'Bytes': len(raw), 'Sha256': sha(raw),
                  'Encoding': 'gzip' if compress else 'identity',
                  'StoredBytes': len(stored), 'StoredSha256': sha(stored)}
    verified = admission.bind_artifact_bytes(descriptor, (dest / name).read_bytes(), raw, name)
    assert isinstance(verified, admission.Admitted), verified
    artifacts.append(descriptor)
manifest = {'SourceCommit': source, 'Artifacts': artifacts}
with (dest / 'manifest.json').open('x') as output:
    output.write(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'SourceCommit': source, 'VerifiedArtifacts': len(artifacts), 'Counts': asdict(result.value)}))
