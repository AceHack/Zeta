from pathlib import Path
from dataclasses import asdict
import gzip, hashlib, json
from zeta_interp import hidden_switch_compiled_certificate_cases as cases
from zeta_interp import hidden_switch_compiled_certificate as c
from zeta_interp import hidden_switch_compiled_ieee as s
root=Path.cwd().parents[1]
dest=root/'docs/research/hidden-switch-compiled-validation/2026-09-07/certificate-cases'
dest.mkdir(exist_ok=False)
(dest/'inputs').mkdir()
bindings={'ProtocolSha256':c.PROTOCOL_SHA256,'hand/source.py':'0'*64}
result=cases.certificate_cases(bindings)
assert isinstance(result,s.Success),result
corpus=result.value
def sha(data): return hashlib.sha256(data).hexdigest().upper()
def retain(name,raw):
 compressed=gzip.compress(raw,mtime=0)
 (dest/name).write_bytes(compressed)
 return {'File':name,'Bytes':len(raw),'Sha256':sha(raw),'Encoding':'gzip','StoredBytes':len(compressed),'StoredSha256':sha(compressed)}
rows=[]
for index,row in enumerate(corpus.Cases):
 rows.append({'CaseId':row.CaseId,'Input':retain(f'inputs/{index:02d}-{row.CaseId}.json.gz',row.Raw),'Python':asdict(row.Python)})
record={'Schema':'zeta.hidden-switch.compiled.certificate-cases.fixture.v1','SourceCommit':'60eeb0b868b973298cb1c6f48044ee7172ada369','Bindings':bindings,'BaselineSha256':corpus.BaselineSha256,'Cases':rows,'Scope':corpus.Scope,'NativeAdmission':corpus.NativeAdmission,'BindingAdmission':'placeholder hand binding; no actual source file admitted'}
(dest/'cases.json').write_text(json.dumps(record,indent=2)+'\n')
logs=[]
for file in ['emit-compiled-certificate-cases.py','compiled-certificate-cases-tests-1.log']:
 logs.append(retain(file+'.gz',(root/'.git'/file).read_bytes()))
manifest={'SourceCommit':record['SourceCommit'],'Artifacts':logs+[{'File':'cases.json','Bytes':len((dest/'cases.json').read_bytes()),'Sha256':sha((dest/'cases.json').read_bytes()),'Encoding':'identity','StoredBytes':len((dest/'cases.json').read_bytes()),'StoredSha256':sha((dest/'cases.json').read_bytes())}]+[r['Input'] for r in rows]}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for row in manifest['Artifacts']:
 stored=(dest/row['File']).read_bytes(); raw=gzip.decompress(stored) if row['Encoding']=='gzip' else stored
 assert len(stored)==row['StoredBytes'] and sha(stored)==row['StoredSha256']
 assert len(raw)==row['Bytes'] and sha(raw)==row['Sha256']
print(json.dumps({'Rows':len(rows),'NativeAdmission':record['NativeAdmission'],'BaselineSha256':record['BaselineSha256'],'VerifiedArtifacts':len(manifest['Artifacts'])}))
