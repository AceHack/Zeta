"""One fixed hand-semantic capture; no source generation or cost entry."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import xml.etree.ElementTree as ET

root = Path.cwd()
attempt = root / '.git/hidden-switch-compiled-semantic-attempt-1'
attempt.mkdir()
implementation = '7eaec2bf2312e04ff0fc936a4c28a09d1704b1f0'
project = root / 'src/Research.FSharp.Cli/HiddenSwitchCompiled.fsproj'
dll = project.parent / 'bin/Release/net10.0/Zeta.Research.HiddenSwitchCompiled.dll'
host = Path('/Users/acehack/.local/share/mise/dotnet-root/dotnet')
overrides = {'DOTNET_TieredCompilation': '0', 'DOTNET_TieredPGO': '0', 'DOTNET_ReadyToRun': '0'}
argv = [str(host), str(dll), 'hand-semantic', str(attempt / 'semantic.json')]

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def identity(path):
    raw = path.read_bytes()
    return {'File': str(path), 'Bytes': len(raw), 'Sha256': hashlib.sha256(raw).hexdigest().upper()}

def write(name, value):
    with (attempt / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

start = now()
child = None
failure = None
cleanup = []
inputs, outputs = [], []
write('stage.json', {'Stage': 'source-and-output-admission', 'StartedAtUtc': start, 'Arguments': argv,
                     'ImplementationCommit': implementation, 'RuntimeAdmitted': False})
try:
    source_paths = [project]
    source_paths += [(project.parent / item.attrib['Include']).resolve() for item in ET.parse(project).findall('.//Compile')]
    source_paths += [root / path for path in ['Directory.Build.props', 'Directory.Packages.props', 'global.json']]
    for path in source_paths:
        assert path.read_bytes() == subprocess.check_output(['git', 'show', implementation + ':' + str(path.relative_to(root))])
    inputs = [identity(path) for path in source_paths]
    outputs = [identity(path) for path in sorted(dll.parent.iterdir()) if path.suffix in {'.dll', '.json'}]
    outputs.append(identity(host))
    write('invocation.json', {'SourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
                            'ImplementationCommit': implementation, 'Arguments': argv, 'EnvironmentOverrides': overrides,
                            'StartedAtUtc': start, 'SourceFiles': inputs, 'BuildOutputs': outputs,
                            'Harness': identity(Path(__file__).resolve()), 'TimeoutSeconds': 60,
                            'SourceDraws': 0, 'RuntimeAdmitted': False, 'BodyResolved': False, 'ClosureAdmitted': False})
    with (attempt / 'stdout.log').open('xb') as stdout, (attempt / 'stderr.log').open('xb') as stderr:
        child = subprocess.Popen(argv, cwd=root, env=dict(os.environ, **overrides), stdout=stdout, stderr=stderr)
        write('process.json', {'Pid': child.pid, 'StartedAtUtc': now()})
        try:
            child.wait(timeout=60)
        except subprocess.TimeoutExpired:
            failure = {'Stage': 'hand-semantic-process', 'Code': 'timeout'}
            child.kill()
            child.wait(timeout=10)
        if child.returncode != 0 and failure is None:
            failure = {'Stage': 'hand-semantic-process', 'Code': 'exit', 'ExitCode': child.returncode}
except Exception as error:
    if failure is None:
        failure = {'Stage': 'hand-semantic-launch', 'Code': type(error).__name__, 'Detail': str(error)}
finally:
    if child is not None and child.poll() is None:
        try:
            child.kill()
            child.wait(timeout=10)
        except Exception as error:
            cleanup.append({'Code': type(error).__name__, 'Detail': str(error)})
    artifacts = []
    unchanged = True
    try:
        for path in [attempt / 'semantic.json', attempt / 'semantic.json.checkpoint.jsonl', attempt / 'stdout.log', attempt / 'stderr.log']:
            if path.exists():
                artifacts.append(identity(path))
        unchanged = all(identity(Path(row['File'])) == row for row in inputs + outputs)
        if not unchanged and failure is None:
            failure = {'Stage': 'hand-semantic-identity', 'Code': 'changed-input'}
    except Exception as error:
        unchanged = False
        cleanup.append({'Stage': 'final-identity', 'Code': type(error).__name__, 'Detail': str(error)})
    write('outcome.json', {'StartedAtUtc': start, 'FinishedAtUtc': now(), 'Pid': None if child is None else child.pid,
                           'ExitCode': None if child is None else child.returncode, 'Failure': failure, 'CleanupFailures': cleanup,
                           'InputsUnchanged': unchanged, 'Artifacts': artifacts, 'RuntimeAdmitted': False,
                           'BodyResolved': False, 'ClosureAdmitted': False,
                           'Scope': 'fixed explicit hand-only slices; process completion is not full admission'})
sys.exit(0 if failure is None and not cleanup else 2)
