module CertificateValidation

open System
open System.IO
open Zeta.Research

[<EntryPoint>]
let main args =
    let bindings = Map.ofList ["ProtocolSha256", "8BBDFE44A0844DD8CE4F6C5DD77B060A56E5B84EA94EA7A6FDBB482AEC9D738A"; "hand-validation", String.replicate 64 "0"]
    match HiddenSwitchCompiledCertificate.build bindings with
    | Error error -> eprintfn "%s" error.Detail; 2
    | Ok raw ->
        if args.Length = 1 then File.WriteAllBytes(args.[0], raw)
        match HiddenSwitchCompiledCertificate.verify raw bindings with
        | Error error -> eprintfn "%s" error.Detail; 2
        | Ok verified -> printfn "%s" (HiddenSwitchCompiledCertificate.numericSha256 verified); 0
