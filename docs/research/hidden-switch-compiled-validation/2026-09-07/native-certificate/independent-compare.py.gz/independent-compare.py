import hashlib
import json
import subprocess
from pathlib import Path

from zeta_interp import hidden_switch_compiled_certificate as c
from zeta_interp import hidden_switch_compiled_ieee as s

root = Path('../..').resolve()
folder = root / '.git/compiled-certificate-check'
raw = (folder / 'native-certificate-attempt-3.json').read_bytes()
bindings = {'ProtocolSha256': c.PROTOCOL_SHA256, 'hand-validation': '0' * 64}
expected = c.build_certificate(bindings)
assert isinstance(expected, s.Success), expected
encoded = json.dumps(expected.value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode('ascii')
assert raw == encoded
verified = c.verify_certificate(json.loads(raw), bindings)
assert isinstance(verified, s.Success), verified
assert raw == (folder / 'native-certificate-attempt-2.json').read_bytes()
result = {
    'Complete': True,
    'SourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'Scope': 'Final scratch native complete certificate versus independently reconstructed Python; not actual runtime or phase admission',
    'Bytes': len(raw),
    'Sha256': hashlib.sha256(raw).hexdigest().upper(),
    'ExactIndependentCanonicalBytes': True,
    'UnchangedNumericProofAfterUnicodeRefusalRepair': True,
    'Models': len(expected.value['Models']),
    'OrderedCandidates': [len(model['Candidates']) for model in expected.value['Models']],
}
(folder / 'independent-comparison-2.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
