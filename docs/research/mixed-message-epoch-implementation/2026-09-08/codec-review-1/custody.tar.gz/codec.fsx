open System.IO
open System.Text.Json
open System.Text
let values = [ "Zeta.Bayesian.BoundedModuleLearner+StepAttempt"; "café <x> & + \"" ]
for value in values do
    use s = new MemoryStream()
    use w = new Utf8JsonWriter(s)
    w.WriteStringValue(value)
    w.Flush()
    printfn "%s" (Encoding.UTF8.GetString(s.ToArray()))
