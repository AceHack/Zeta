import json
for value in ["Zeta.Bayesian.BoundedModuleLearner+StepAttempt", "café <x> & + \""]:
    print(json.dumps(value, ensure_ascii=False))
