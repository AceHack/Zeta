import datetime, hashlib, json, pathlib, subprocess, time
root = pathlib.Path(__file__).resolve().parent.parent
out = root / '.git/epoch-control-root-checkpoint-1'
out.mkdir(exist_ok=False)
paths = ['src/Bayesian/BoundedModuleLearner.fs', 'src/Bayesian/MixedMessageEpoch.fs', 'src/Bayesian/Bayesian.fsproj', 'tests/Bayesian.Tests/BoundedModuleLearner.Tests.fs', 'tests/Bayesian.Tests/MixedMessageEpoch.Tests.fs', 'tests/Bayesian.Tests/Bayesian.Tests.fsproj', 'docs/research/2026-09-08-mixed-message-frozen-nested-query-register.md', 'docs/research/2026-09-08-mixed-message-epoch-implementation-register.md']
rows = []
for index, rel in enumerate(paths):
    raw = (root / rel).read_bytes()
    name = f'source-{index:02d}'
    (out / name).write_bytes(raw)
    rows.append(dict(Path=rel, Copy=name, Bytes=len(raw), Sha256=hashlib.sha256(raw).hexdigest().upper()))
(out / 'sources.json').write_text(json.dumps(rows, indent=2) + '\n')
commands = [
    ['bun', 'run', 'preflight:quick'],
    ['/Users/acehack/.local/share/mise/dotnet-root/dotnet', 'build', 'src/Bayesian/Bayesian.fsproj', '-c', 'Release'],
]
for index, argv in enumerate(commands):
    folder = out / f'call-{index}'
    folder.mkdir()
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tick = time.monotonic()
    with (folder / 'stdout').open('wb') as stdout, (folder / 'stderr').open('wb') as stderr:
        result = subprocess.run(argv, cwd=root, stdout=stdout, stderr=stderr, check=False)
    record = dict(Argv=argv, Cwd=str(root), Started=start, Finished=datetime.datetime.now(datetime.timezone.utc).isoformat(), ElapsedSeconds=time.monotonic()-tick, ExitCode=result.returncode)
    (folder / 'completion.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record), flush=True)
after = []
for row in rows:
    raw = (root / row['Path']).read_bytes()
    after.append(dict(Path=row['Path'], Unchanged=len(raw)==row['Bytes'] and hashlib.sha256(raw).hexdigest().upper()==row['Sha256']))
(out / 'source-after.json').write_text(json.dumps(after, indent=2) + '\n')
if not all(row['Unchanged'] for row in after):
    raise RuntimeError('source changed during captured checks')
