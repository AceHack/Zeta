from pathlib import Path
import hashlib, json, subprocess, urllib.request
owner = Path("/Users/acehack/.zeta/agents/codex/Zeta-relational-identity-20260906")
source_repo = Path("/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906")
out = Path(__file__).parent
pin = "9928404da6cf7ab1c5e2b251ae7afe73bbe2eda0"
proposal = "docs/research/2026-09-08-mixed-message-learned-module-epoch-proposal.md"
census = "docs/research/2026-09-08-mixed-message-learned-module-epoch-source-pins.json"
def git(repo, *args):
    return subprocess.run(["git", "-C", str(repo), *args], check=True, capture_output=True).stdout
def identity(raw):
    return {"Bytes": len(raw), "Sha256": hashlib.sha256(raw).hexdigest().upper()}
inputs = []
for name in (proposal, census):
    raw = git(owner, "show", pin + ":" + name)
    assert raw == (owner / name).read_bytes()
    (out / Path(name).name).write_bytes(raw)
    inputs.append({"Path": name, **identity(raw)})
manifest = json.loads((out / Path(census).name).read_bytes())
assert len(manifest["Files"]) == 24
assert len({row["Path"] for row in manifest["Files"]}) == 24
checks = []
for row in manifest["Files"]:
    raw = git(source_repo, "show", manifest["SourceCommit"] + ":" + row["Path"])
    actual = identity(raw)
    blob = git(source_repo, "rev-parse", manifest["SourceCommit"] + ":" + row["Path"]).decode().strip()
    assert actual["Bytes"] == row["Bytes"] and actual["Sha256"] == row["Sha256"] and blob == row["GitBlob"]
    current = source_repo / row["Path"]
    checks.append({"Path": row["Path"], "GitBlob": blob, **actual, "CurrentRootBytesEqual": current.is_file() and current.read_bytes() == raw})
prior = manifest["PriorResultReport"]
url = "https://raw.githubusercontent.com/Lucent-Financial-Group/Zeta/" + prior["Commit"] + "/" + prior["Path"]
with urllib.request.urlopen(url, timeout=15) as response:
    raw = response.read(65537)
    assert len(raw) <= 65536
    resolved = response.url
(out / "prior-result-report.md").write_bytes(raw)
(out / "prior-report-retrieval.json").write_text(json.dumps({"RequestedUrl": url, "ResolvedUrl": resolved, "CapBytes": 65536, **identity(raw)}, indent=2) + "\n")
assert identity(raw) == {"Bytes": prior["Bytes"], "Sha256": prior["Sha256"]}
result = {"ProposalCommit": pin, "SourceCommit": manifest["SourceCommit"], "Inputs": inputs, "SourceFilesVerified": checks, "PriorReportIdentityVerified": {"Commit": prior["Commit"], "Path": prior["Path"], **identity(raw)}, "PriorRawResultsReplayed": False, "TargetModulesImported": False, "SolverOrTrainingRun": False}
(out / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"SourceFiles": len(checks), "CurrentRootMatches": sum(row["CurrentRootBytesEqual"] for row in checks), "SourceBytes": sum(row["Bytes"] for row in checks), "Proposal": inputs[0], "Census": inputs[1], "PriorReportBytes": len(raw)}))
