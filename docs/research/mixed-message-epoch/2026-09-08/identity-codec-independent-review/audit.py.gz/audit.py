"""Read-only finite note/custody audit; never execute either witness source."""

from pathlib import Path
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

ROOT = Path('/Users/acehack/.zeta/agents/codex/Zeta-projection-publication-20260908')
PIN = '02c2ac7249aba31cc8377c1804264c02fff35e47'
NOTE = 'docs/research/2026-09-08-mixed-message-epoch-identity-codec-conventions.md'
BASE = 'docs/research/mixed-message-epoch-implementation/2026-09-08/codec-review-1/'
OUT = Path(__file__).parent


def digest(raw):
    return hashlib.sha256(raw).hexdigest().upper()


def admitted_file(name, maximum):
    current = ROOT / name
    assert current.is_file() and current.stat().st_size <= maximum
    raw = current.read_bytes()
    immutable = subprocess.run(
        ['git', 'show', f'{PIN}:{name}'], cwd=ROOT, check=True, capture_output=True
    ).stdout
    assert raw == immutable
    return raw


note = admitted_file(NOTE, 8192)
assert len(note) == 6583
assert digest(note) == 'BB623AB96A329A075E8C9BC06953D7284DA62BA10766B0D06479D51A011F98C2'
manifest_raw = admitted_file(BASE + 'manifest.json', 8192)
manifest = json.loads(manifest_raw)
archive = admitted_file(BASE + 'custody.tar.gz', 4096)
assert len(archive) == manifest['ArchiveBytes'] == 830
assert digest(archive) == manifest['ArchiveSha256']
expanded = gzip.decompress(archive)
assert len(expanded) <= 32768
declared = manifest['Members']
assert len(declared) == 8 and len({x['Path'] for x in declared}) == 8
members = {}
with tarfile.open(fileobj=io.BytesIO(expanded), mode='r:') as tar:
    entries = tar.getmembers()
    assert len(entries) == 8
    for item, expected in zip(entries, declared, strict=True):
        assert item.isfile() and '/' not in item.name and item.name == expected['Path']
        assert item.size == expected['Bytes'] and item.size <= 4096
        stream = tar.extractfile(item)
        assert stream is not None
        raw = stream.read(item.size + 1)
        assert len(raw) == item.size and digest(raw) == expected['Sha256']
        original = ROOT / '.git/mixed-epoch-codec-review-1' / item.name
        assert original.is_file() and original.stat().st_size == len(raw)
        assert original.read_bytes() == raw
        members[item.name] = raw

dotnet_lines = members['stdout'].splitlines()
python_lines = members['python-stdout'].splitlines()
assert len(dotnet_lines) == len(python_lines) == 2
pairs = []
for native, python in zip(dotnet_lines, python_lines, strict=True):
    assert native != python and json.loads(native) == json.loads(python)
    pairs.append({'DotnetBytes': len(native), 'DotnetSha256': digest(native),
                  'PythonBytes': len(python), 'PythonSha256': digest(python),
                  'SameDecodedString': True, 'SameBytes': False})
assert b'\\u002B' in dotnet_lines[0] and b'+' in python_lines[0]
assert json.loads(dotnet_lines[0]) == 'Zeta.Bayesian.BoundedModuleLearner+StepAttempt'
calls = [json.loads(members[x]) for x in ['call.json', 'python-call.json']]
assert all(x['exit'] == 0 for x in calls)
assert members['stderr'] == members['python-stderr'] == b''

inputs = [('note.md', note), ('original-manifest.json', manifest_raw), ('custody.tar.gz', archive)]
for name, raw in inputs:
    with (OUT / name).open('xb') as stream:
        stream.write(raw)
result = {'Schema': 'zeta.mixed-epoch.codec-conventions-independent-review.v1',
          'SourceCommit': PIN, 'Inputs': [
              {'File': name, 'Bytes': len(raw), 'Sha256': digest(raw)} for name, raw in inputs],
          'StoredRawOriginalMembersVerified': len(members),
          'MemberOriginalBytes': sum(len(x) for x in members.values()),
          'ArchiveExpandedBytes': len(expanded), 'Pairs': pairs,
          'ReportedWitnessExits': [x['exit'] for x in calls],
          'ReportedWitnessStderrEmpty': True,
          'ReviewerExecutedWitnesses': False, 'ReviewerExecutedNumericalOrControlCalls': False}
with (OUT / 'result.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
