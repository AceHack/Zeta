from pathlib import Path
import gzip,hashlib,json,subprocess,stat
root=Path.cwd();pin="b097d56eccc630046cd3bf618a362b01edeba329"
def sha(x):return hashlib.sha256(x).hexdigest().upper()
results=[]
for name in ["core-checkpoint-1","core-checkpoint-repair-1"]:
 directory=root/"docs/research/mixed-message-epoch-implementation/2026-09-08"/name
 raw=(directory/"manifest.json").read_bytes();manifest=json.loads(raw)
 records=[]
 for r in manifest["Records"]:
  packed=(directory/r["File"]).read_bytes();assert len(packed)==r["StoredBytes"] and sha(packed)==r["StoredSha256"]
  original=gzip.decompress(packed);assert len(original)==r["Bytes"] and sha(original)==r["Sha256"]
  p=Path(r["Original"]);info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_size==len(original)
  assert p.read_bytes()==original
  records.append({"File":r["File"],"Bytes":len(original),"Sha256":sha(original),"OriginalMatched":True})
 sources=[]
 for r in manifest["SourceFiles"]:
  blob=subprocess.check_output(["git","show",pin+":"+r["Path"]])
  matches=len(blob)==r["Bytes"] and sha(blob)==r["Sha256"]
  if name=="core-checkpoint-repair-1":assert matches
  sources.append({"Path":r["Path"],"MatchesFinalPin":matches,"FinalBytes":len(blob),"FinalSha256":sha(blob)})
 results.append({"Manifest":str(directory.relative_to(root)/"manifest.json"),"ManifestSha256":sha(raw),"Records":records,"SourceComparisons":sources})
result={"Complete":True,"Scope":"Read-only lossless archive/original identities and immutable source comparisons; no source, learner, test or epoch execution","Pin":pin,"Archives":results}
(root/".git/mixed-message-core-checkpoint-independent-audit-1/result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"Complete":True,"RecordCounts":[len(x["Records"]) for x in results]}))
