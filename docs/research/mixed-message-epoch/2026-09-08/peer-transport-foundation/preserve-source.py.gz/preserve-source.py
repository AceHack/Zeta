from pathlib import Path
import gzip, hashlib, json
base=Path('docs/research/mixed-message-epoch/2026-09-08/peer-transport-foundation')
base.mkdir(parents=True,exist_ok=False)
records=[]
directories=[
 'mixed-message-peer-transport-build-1','mixed-message-peer-transport-build-2',
 'mixed-message-peer-transport-checks-draft-1','mixed-message-peer-transport-checks-2',
 'mixed-message-peer-transport-checks-3','mixed-message-peer-transport-checks-4',
 'mixed-message-peer-transport-checks-5']
for directory in directories:
 source=Path('.git')/directory
 names=['MixedMessageEpochReplay.fsx','invocation.json','stdout','stderr','completion.json']
 if 'checks' in directory: names+=['checks.fsx','run.py']
 if directory.endswith('checks-4') or directory.endswith('checks-5'): names+=['fixture.bin','stat-source.json']
 for name in names:
  original=source/name
  raw=original.read_bytes();stored=gzip.compress(raw,mtime=0)
  target=f'{len(records)+1:03d}-'+directory.removeprefix('mixed-message-peer-transport-')+'-'+name+'.gz'
  (base/target).write_bytes(stored)
  records.append({'File':target,'Encoding':'gzip','Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper(),'OriginalPath':str(original)})
raw=Path(__file__).read_bytes();stored=gzip.compress(raw,mtime=0);target='preserve-source.py.gz';(base/target).write_bytes(stored)
records.append({'File':target,'Encoding':'gzip','Bytes':len(raw),'Sha256':hashlib.sha256(raw).hexdigest().upper(),'StoredBytes':len(stored),'StoredSha256':hashlib.sha256(stored).hexdigest().upper(),'OriginalPath':str(Path(__file__))})
source=Path('src/Research.FSharp/MixedMessageEpochReplay.fsx').read_bytes()
assert source==(Path('.git')/directories[-1]/'MixedMessageEpochReplay.fsx').read_bytes()
manifest={'Schema':'zeta.mixed-message-epoch.peer-transport-foundation.v1','CompletePeer':False,'CoreInvoked':False,'NamedControlsRun':False,'Records':records,'CurrentSource':{'Path':'src/Research.FSharp/MixedMessageEpochReplay.fsx','Bytes':len(source),'Sha256':hashlib.sha256(source).hexdigest().upper()},'Validation':[{'Directory':d,'Completion':json.loads((Path('.git')/d/'completion.json').read_text())} for d in directories]}
(base/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'Records':len(records),'OriginalBytes':sum(r['Bytes'] for r in records),'StoredBytes':sum(r['StoredBytes'] for r in records),'Source':manifest['CurrentSource']},indent=2))
