#if INTERACTIVE
#r "../Core/bin/Release/net10.0/Zeta.Core.dll"
#r "../Core.Abstractions/bin/Release/net10.0/Zeta.Core.Abstractions.dll"
#r "../Bayesian/bin/Release/net10.0/Zeta.Bayesian.dll"
#else
namespace Zeta.Research
#endif

/// One finite, sequential peer. The standard streams are borrowed: an outstanding
/// timed-out read/write retains its buffer and is never raced by stream disposal.
/// The owning coordinator observes and closes the direct process separately.
module MixedMessageEpochReplay =
    open System
    open System.Collections.Generic
    open System.Diagnostics
    open System.IO
    open System.Security.Cryptography
    open System.Text
    open System.Text.Json
    open System.Threading.Tasks

    [<Literal>]
    let Schema = "zeta.mixed-epoch.peer.v1"
    [<Literal>]
    let StartCap = 1024 * 1024
    [<Literal>]
    let SmallCap = 64 * 1024
    [<Literal>]
    let RequestCap = 256 * 1024
    [<Literal>]
    let ResponseCap = 12 * 1024 * 1024
    [<Literal>]
    let ResultCap = 16 * 1024 * 1024
    [<Literal>]
    let TerminalCap = 1024 * 1024
    [<Literal>]
    let TranscriptCap = 64 * 1024 * 1024
    [<Literal>]
    let FrameCap = 16384

    type PeerFailure = { Stage: string; Code: string; Message: string }
    type ByteIdentity = { Bytes: int; Sha256: string }

    /// Raw records are available local observations, not successful publication.
    /// For a failed write Raw is the attempted frame; the sent byte count is unknown.
    type FrameObservation =
        { Direction: string
          Raw: byte array
          Identity: ByteIdentity
          Complete: bool
          Failure: PeerFailure option }

    /// Mutable state is confined to one sequential peer invocation. It preserves
    /// actual prefixes before fallible parsing, encoding or callback judgment.
    type Transport = private
        { Input: Stream
          Output: Stream
          Clock: Stopwatch
          DeadlineSeconds: float
          Frames: ResizeArray<FrameObservation>
          mutable ChargedBytes: int
          mutable ReadBytes: int
          mutable CompletedWriteBytes: int
          mutable ChargedFrames: int
          mutable NextSequence: int
          mutable Failure: PeerFailure option
          mutable PendingRead: Task option
          mutable PendingWrite: Task option }

    type TransportSnapshot =
        { ChargedBytes: int
          ReadBytes: int
          CompletedWriteBytes: int
          ChargedFrames: int
          NextSequence: int
          Failure: PeerFailure option
          PendingRead: bool
          PendingWrite: bool
          Frames: FrameObservation array }

    let private utf8 = UTF8Encoding(false, true)

    let private failure stage code (message: string) =
        let text = if isNull message then "" else message
        { Stage = stage; Code = code
          Message = if text.Length <= 1024 then text else text.Substring(0, 1024) }

    let private identity (raw: byte array) =
        { Bytes = raw.Length; Sha256 = Convert.ToHexString(SHA256.HashData raw) }

    let private rememberFailure state error =
        if state.Failure.IsNone then state.Failure <- Some error
        error

    /// Streams are borrowed. A small timeout is an explicit development seam;
    /// production supplies the source-fixed 300 second cooperative allowance.
    let createTransport input output deadlineSeconds =
        if isNull input || isNull output || not (Double.IsFinite deadlineSeconds)
           || deadlineSeconds <= 0.0 || deadlineSeconds > 300.0 then
            Error(failure "admit" "TransportArguments" "streams and deadline in (0,300] required")
        else
            Ok { Input = input; Output = output; Clock = Stopwatch.StartNew()
                 DeadlineSeconds = deadlineSeconds; Frames = ResizeArray()
                 ChargedBytes = 0; ReadBytes = 0; CompletedWriteBytes = 0
                 ChargedFrames = 0; NextSequence = 1; Failure = None
                 PendingRead = None; PendingWrite = None }

    let snapshot state =
        { ChargedBytes = state.ChargedBytes; ReadBytes = state.ReadBytes
          CompletedWriteBytes = state.CompletedWriteBytes
          ChargedFrames = state.ChargedFrames; NextSequence = state.NextSequence
          Failure = state.Failure
          PendingRead = state.PendingRead |> Option.exists (fun t -> not t.IsCompleted)
          PendingWrite = state.PendingWrite |> Option.exists (fun t -> not t.IsCompleted)
          Frames = state.Frames.ToArray() }

    let private remainingTime state stage =
        let seconds = state.DeadlineSeconds - state.Clock.Elapsed.TotalSeconds
        if seconds <= 0.0 then
            Error(rememberFailure state (failure stage "Deadline" "cooperative peer deadline reached"))
        else Ok(TimeSpan.FromSeconds seconds)

    let private ordinaryRoom state = TranscriptCap - TerminalCap - state.ChargedBytes

    let private record state direction raw complete error =
        state.Frames.Add
            { Direction = direction; Raw = raw; Identity = identity raw
              Complete = complete; Failure = error }

    /// Reads one LF-terminated frame in bounded chunks. A conforming counterpart
    /// cannot have a second response ready before this peer's next request.
    /// Extra bytes after LF in the same read are retained and refused.
    let readFrame state stage maximum : Task<Result<byte array, PeerFailure>> =
        task {
            match state.Failure with
            | Some error -> return Error error
            | None ->
                let limit = min maximum (ordinaryRoom state)
                if maximum <= 0 || maximum > ResultCap || limit <= 0
                   || state.ChargedFrames >= FrameCap - 1 then
                    return Error(rememberFailure state (failure stage "FrameBudget" "no bounded input-frame allowance"))
                else
                    state.ChargedFrames <- state.ChargedFrames + 1
                    use accumulated = new MemoryStream(min limit 4096)
                    let mutable complete = false
                    let mutable problem = None
                    while not complete && problem.IsNone do
                        match remainingTime state stage with
                        | Error error -> problem <- Some error
                        | Ok duration ->
                            // At most one extra byte establishes a size refusal.
                            let count = min 4096 (limit - int accumulated.Length + 1)
                            let buffer = Array.zeroCreate<byte> count
                            let pending = state.Input.ReadAsync(buffer.AsMemory()).AsTask()
                            state.PendingRead <- Some(pending :> Task)
                            try
                                let! received = pending.WaitAsync(duration).ConfigureAwait(false)
                                state.PendingRead <- None
                                if received = 0 then
                                    problem <- Some(failure stage "UnexpectedEof" "complete LF-terminated input required")
                                else
                                    state.ReadBytes <- state.ReadBytes + received
                                    state.ChargedBytes <- state.ChargedBytes + received
                                    accumulated.Write(buffer, 0, received)
                                    if accumulated.Length > int64 limit then
                                        problem <- Some(failure stage "FrameBound" "input exceeded its admitted frame/transcript allowance")
                                    else
                                        let lf = Array.IndexOf(buffer, 10uy, 0, received)
                                        if lf >= 0 then
                                            if lf <> received - 1 then
                                                problem <- Some(failure stage "UnexpectedTrailingBytes" "bytes followed the single outstanding input frame")
                                            else complete <- true
                            with error ->
                                // A pending operation retains buffer ownership. Do not close
                                // the borrowed stream or start another read after this failure.
                                problem <- Some(failure stage "ReadFailure" (error.GetType().FullName + ": " + error.Message))
                    let raw = accumulated.ToArray()
                    record state "in" raw complete problem
                    match problem with
                    | Some error -> return Error(rememberFailure state error)
                    | None -> return Ok raw
        }

    /// Reserves the whole original frame before I/O and never refunds failure.
    /// CompletedWriteBytes counts only completed writes and flushes; it does not
    /// guess how much a failing Stream.WriteAsync transmitted.
    let writeFrame state stage maximum terminal (raw: byte array) : Task<Result<unit, PeerFailure>> =
        task {
            let room = if terminal then TranscriptCap - state.ChargedBytes else ordinaryRoom state
            let allowedFrames = if terminal then FrameCap else FrameCap - 1
            if isNull raw || raw.Length = 0 || raw.[raw.Length - 1] <> 10uy
               || maximum <= 0 || maximum > ResultCap || raw.Length > maximum
               || raw.Length > room || state.ChargedFrames >= allowedFrames then
                return Error(rememberFailure state (failure stage "FrameBudget" "complete original output exceeds its frame/transcript allowance"))
            elif state.PendingWrite |> Option.exists (fun t -> not t.IsCompleted) then
                return Error(rememberFailure state (failure stage "PendingWrite" "cannot race an outstanding output write"))
            else
                match remainingTime state stage with
                | Error error -> return Error error
                | Ok duration ->
                    state.ChargedBytes <- state.ChargedBytes + raw.Length
                    state.ChargedFrames <- state.ChargedFrames + 1
                    let mutable problem = None
                    try
                        let pending = state.Output.WriteAsync(raw.AsMemory()).AsTask()
                        state.PendingWrite <- Some pending
                        do! pending.WaitAsync(duration).ConfigureAwait(false)
                        match remainingTime state stage with
                        | Error error -> problem <- Some error
                        | Ok flushDuration ->
                            let flushing = state.Output.FlushAsync()
                            state.PendingWrite <- Some flushing
                            do! flushing.WaitAsync(flushDuration).ConfigureAwait(false)
                            state.CompletedWriteBytes <- state.CompletedWriteBytes + raw.Length
                            state.PendingWrite <- None
                    with error ->
                        problem <- Some(failure stage "WriteFailure" (error.GetType().FullName + ": " + error.Message))
                    record state "out" raw problem.IsNone problem
                    match problem with
                    | Some error -> return Error(rememberFailure state error)
                    | None -> return Ok()
        }

    /// Prewalk bounds metadata and rejects duplicate/deferred-invalid strings
    /// before cloning a passive JSON tree. The tree cannot instantiate a type.
    let strictJson stage maximum (raw: byte array) : Result<JsonElement, PeerFailure> =
        try
            if isNull raw || raw.Length = 0 || raw.Length > maximum then
                Error(failure stage "JsonBound" "bounded UTF8 JSON bytes required")
            else
                let options = JsonReaderOptions(MaxDepth = 128, CommentHandling = JsonCommentHandling.Disallow)
                let mutable reader = Utf8JsonReader(ReadOnlySpan<byte>(raw), options)
                let objects = Stack<HashSet<string>>()
                let mutable tokens = 0
                let mutable invalid = None
                while invalid.IsNone && reader.Read() do
                    tokens <- tokens + 1
                    if tokens > 100000 then invalid <- Some "JSON token bound exceeded"
                    else
                        match reader.TokenType with
                        | JsonTokenType.StartObject -> objects.Push(HashSet(StringComparer.Ordinal))
                        | JsonTokenType.EndObject -> objects.Pop() |> ignore
                        | JsonTokenType.PropertyName ->
                            let key = reader.GetString()
                            if isNull key || not (objects.Peek().Add key) then invalid <- Some "duplicate JSON key"
                        | JsonTokenType.String -> reader.GetString() |> ignore
                        | _ -> ()
                match invalid with
                | Some message -> Error(failure stage "JsonShape" message)
                | None ->
                    // Explicit strict UTF8 validation covers malformed byte sequences
                    // even in otherwise passive string values.
                    utf8.GetString raw |> ignore
                    use document = JsonDocument.Parse(ReadOnlyMemory<byte>(raw), JsonDocumentOptions(MaxDepth = 128))
                    if document.RootElement.ValueKind <> JsonValueKind.Object then
                        Error(failure stage "JsonShape" "object frame required")
                    else Ok(document.RootElement.Clone())
        with error -> Error(failure stage "JsonShape" (error.GetType().FullName + ": " + error.Message))

    let exactKeys stage (names: string array) (root: JsonElement) =
        let actual = root.EnumerateObject() |> Seq.map (fun p -> p.Name) |> Set.ofSeq
        if actual = Set.ofArray names then Ok()
        else Error(failure stage "FrameKeys" "exact frame member roster required")

    let stringField stage key (root: JsonElement) =
        match root.TryGetProperty key with
        | true, value when value.ValueKind = JsonValueKind.String ->
            try Ok(value.GetString())
            with error -> Error(failure stage "FrameString" error.Message)
        | _ -> Error(failure stage "FrameString" ("string member required: " + key))

    let integerField stage key (root: JsonElement) =
        match root.TryGetProperty key with
        | true, value when value.ValueKind = JsonValueKind.Number ->
            match value.TryGetInt32() with
            | true, number -> Ok number
            | _ -> Error(failure stage "FrameInteger" ("exact int32 required: " + key))
        | _ -> Error(failure stage "FrameInteger" ("exact integer member required: " + key))
