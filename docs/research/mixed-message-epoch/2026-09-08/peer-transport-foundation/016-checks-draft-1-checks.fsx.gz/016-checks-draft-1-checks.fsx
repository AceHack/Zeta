#load "../../src/Research.FSharp/MixedMessageEpochReplay.fsx"
open System
open System.IO
open System.Text
open System.Threading
open System.Threading.Tasks
open MixedMessageEpochReplay.MixedMessageEpochReplay
let raw (s:string) = Encoding.UTF8.GetBytes s
let awaitResult (t:Task<'T>) = t.GetAwaiter().GetResult()
let transport input output = match createTransport input output 5.0 with Ok x -> x | Error e -> failwithf "%A" e
let isError = function Error _ -> true | Ok _ -> false
// A real MemoryStream retains a partial write before the declared failure.
type PartialOutput() =
    inherit MemoryStream()
    let mutable attempts = 0
    member _.Attempts = attempts
    override this.WriteAsync(buffer:ReadOnlyMemory<byte>, _token:CancellationToken) =
        attempts <- attempts + 1
        if attempts = 1 then
            this.Write(buffer.Span.Slice(0, 1))
            ValueTask(Task.FromException(IOException("synthetic failure after actual one-byte write")))
        else
            this.Write(buffer.Span)
            ValueTask.CompletedTask
use input = new MemoryStream()
use output = new PartialOutput()
let state = transport input output
let first = writeFrame state "first" SmallCap false (raw "{}\n") |> awaitResult
let terminal = writeFrame state "terminal" TerminalCap true (raw "{}\n") |> awaitResult
let passed = isError first && isError terminal && output.Attempts = 1 && output.Length = 1L
printfn "First=%A Terminal=%A Attempts=%d ActualOutputHex=%s" first terminal output.Attempts (Convert.ToHexString(output.ToArray()))
printfn "Passed=%b" passed
if not passed then Environment.Exit 1
