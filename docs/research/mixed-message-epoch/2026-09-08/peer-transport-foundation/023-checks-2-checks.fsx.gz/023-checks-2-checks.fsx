#load "../../src/Research.FSharp/MixedMessageEpochReplay.fsx"
open System
open System.IO
open System.Text
open System.Text.Json
open System.Threading
open System.Threading.Tasks
open MixedMessageEpochReplay.MixedMessageEpochReplay
let raw (s:string) = Encoding.UTF8.GetBytes s
let awaitResult (t:Task<'T>) = t.GetAwaiter().GetResult()
let transport input output seconds = match createTransport input output seconds with Ok x -> x | Error e -> failwithf "%A" e
let isError = function Error _ -> true | Ok _ -> false
let require condition message = if not condition then failwith message
let get = function Ok x -> x | Error e -> failwithf "%A" e
let rows = ResizeArray<obj>()
let mutable failed = 0
let check name action =
    try action(); rows.Add(box {|Name=name; Passed=true; Detail=""|})
    with e -> failed <- failed+1; rows.Add(box {|Name=name; Passed=false; Detail=e.ToString()|})
// Real MemoryStream with a controlled partial physical write.
type PartialOutput() =
    inherit MemoryStream()
    let mutable attempts = 0
    member _.Attempts = attempts
    override this.WriteAsync(buffer:ReadOnlyMemory<byte>, _token:CancellationToken) =
        attempts <- attempts+1
        this.Write(buffer.Span.Slice(0,1))
        ValueTask(Task.FromException(IOException("synthetic failure after actual one-byte write")))
type FlushOutput() =
    inherit MemoryStream()
    override _.FlushAsync(_token:CancellationToken) = Task.FromException(IOException("synthetic flush failure"))
type ChunkInput(bytes:byte[], chunk:int) =
    inherit MemoryStream(bytes)
    override this.ReadAsync(buffer:Memory<byte>, _token:CancellationToken) =
        ValueTask<int>(this.Read(buffer.Span.Slice(0,min chunk buffer.Length)))
type ThrowInput() =
    inherit MemoryStream()
    override _.ReadAsync(_buffer:Memory<byte>, _token:CancellationToken) : ValueTask<int> =
        raise (IOException("synthetic synchronous read failure"))
type PendingInput() =
    inherit MemoryStream()
    let completion = TaskCompletionSource<int>(TaskCreationOptions.RunContinuationsAsynchronously)
    let mutable buffer = Memory<byte>.Empty
    let mutable closes=0
    member _.Complete(bytes:byte[]) = bytes.CopyTo(buffer); completion.SetResult(bytes.Length)
    member _.Closes=closes
    override _.ReadAsync(next:Memory<byte>, _token:CancellationToken) = buffer<-next; ValueTask<int>(completion.Task)
    override this.Dispose(disposing:bool) = closes<-closes+1; base.Dispose(disposing)
let run () =
    check "partial-output-refuses-any-later-frame" (fun () ->
        use input=new MemoryStream()
        use output=new PartialOutput()
        let state=transport input output 5.0
        require (writeFrame state "first" SmallCap false (raw "{}\n") |> awaitResult |> isError) "first must refuse"
        require (writeFrame state "terminal" TerminalCap true (raw "{}\n") |> awaitResult |> isError) "terminal must refuse"
        require (output.Attempts=1 && output.Length=1L) "later physical append occurred"
        let seen=snapshot state
        require (seen.OutputFailed && seen.CompletedWriteBytes=0 && seen.ChargedBytes=3 && seen.Frames.Length=1) "actual partial prefix/reservation lost"
        require (seen.Frames.[0].Raw=raw "{}\n" && seen.Failure.Value.Code="WriteFailure") "original attempted bytes/first failure lost")
    check "flush-failure-is-not-completed-output" (fun () ->
        use input=new MemoryStream()
        use output=new FlushOutput()
        let state=transport input output 5.0
        require (writeFrame state "out" SmallCap false (raw "{}\n") |> awaitResult |> isError) "flush must refuse"
        require (output.ToArray()=raw "{}\n" && (snapshot state).CompletedWriteBytes=0 && (snapshot state).OutputFailed) "completed bytes invented")
    check "chunked-frame-exact-prefix" (fun () ->
        use input=new ChunkInput(raw "{\"a\":1}\n",2)
        use output=new MemoryStream()
        let state=transport input output 5.0
        let value=readFrame state "read" SmallCap |> awaitResult |> get
        let seen=snapshot state
        require (value=raw "{\"a\":1}\n" && seen.ReadBytes=value.Length && seen.ChargedFrames=1 && seen.Frames.[0].Complete) "chunk identity differs")
    check "premature-eof-retains-prefix" (fun () ->
        use input=new MemoryStream(raw "{\"a\":")
        use output=new MemoryStream()
        let state=transport input output 5.0
        require (readFrame state "read" SmallCap |> awaitResult |> isError) "EOF must refuse"
        let seen=snapshot state
        require (seen.Frames.[0].Raw=raw "{\"a\":" && seen.Failure.Value.Code="UnexpectedEof") "prefix missing"
        require (writeFrame state "ordinary" SmallCap false (raw "{}\n") |> awaitResult |> isError) "continued ordinary work"
        writeFrame state "terminal" TerminalCap true (raw "{}\n") |> awaitResult |> get)
    check "trailing-second-frame-refused-retained" (fun () ->
        use input=new MemoryStream(raw "{}\n{}\n")
        use output=new MemoryStream()
        let state=transport input output 5.0
        require (readFrame state "read" SmallCap |> awaitResult |> isError) "extra must refuse"
        require ((snapshot state).Frames.[0].Raw=raw "{}\n{}\n") "extra bytes omitted")
    check "frame-bound-reads-at-most-cap-plus-one" (fun () ->
        use input=new MemoryStream(raw "123456789\n")
        use output=new MemoryStream()
        let state=transport input output 5.0
        require (readFrame state "read" 4 |> awaitResult |> isError) "oversize must refuse"
        require ((snapshot state).ReadBytes=5 && input.Position=5L) "unbounded read")
    check "pending-read-owned-and-late-bytes-retained" (fun () ->
        use input=new PendingInput()
        use output=new MemoryStream()
        let state=transport input output 0.01
        require (readFrame state "read" SmallCap |> awaitResult |> isError) "timeout must refuse"
        require ((snapshot state).PendingRead && input.Closes=0) "pending stream was disposed"
        input.Complete(raw "{}\n")
        let seen=snapshot state
        require (seen.LateReadBytes=Some(raw "{}\n") && seen.ReadBytes=0 && not seen.PendingRead && input.Closes=0) "late observation relabeled as admitted")
    check "synchronous-read-throw-is-typed" (fun () ->
        use input=new ThrowInput()
        use output=new MemoryStream()
        let state=transport input output 5.0
        require (readFrame state "read" SmallCap |> awaitResult |> isError) "throw escaped"
        require ((snapshot state).Frames.Length=1 && (snapshot state).Frames.[0].Raw.Length=0) "empty reached prefix lost")
    check "strict-duplicate-key" (fun () -> require (strictJson "json" SmallCap (raw "{\"a\":0,\"a\":1}") |> isError) "duplicate accepted")
    check "strict-nested-duplicate-key" (fun () -> require (strictJson "json" SmallCap (raw "{\"a\":{\"b\":0,\"b\":1}}") |> isError) "nested duplicate accepted")
    check "strict-deferred-surrogate" (fun () -> require (strictJson "json" SmallCap (raw "{\"a\":\"\\ud800\"}") |> isError) "surrogate accepted")
    check "strict-invalid-utf8" (fun () -> require (strictJson "json" SmallCap [|123uy;34uy;97uy;34uy;58uy;34uy;255uy;34uy;125uy|] |> isError) "invalid UTF8 accepted")
    check "strict-overflow-number" (fun () -> require (strictJson "json" SmallCap (raw "{\"a\":[1e400]}") |> isError) "infinite exponent accepted")
    check "bounded-large-integer-remains-passive" (fun () -> strictJson "json" SmallCap (raw ("{\"n\":"+String('9',4096)+"}")) |> get |> ignore)
    check "too-large-integer-refused-before-clone" (fun () -> require (strictJson "json" SmallCap (raw ("{\"n\":"+String('9',4097)+"}")) |> isError) "integer cap missed")
    check "array-root-refused" (fun () -> require (strictJson "json" SmallCap (raw "[]") |> isError) "array root accepted")
    check "typed-field-helpers-refuse-nonobject" (fun () ->
        use doc=JsonDocument.Parse "[]"
        require (exactKeys "shape" [|"x"|] doc.RootElement |> isError) "keys threw/accepted"
        require (stringField "shape" "x" doc.RootElement |> isError) "string threw/accepted"
        require (integerField "shape" "x" doc.RootElement |> isError) "integer threw/accepted")
    check "boolean-is-not-protocol-integer" (fun () ->
        let doc=strictJson "json" SmallCap (raw "{\"n\":true}") |> get
        require (integerField "shape" "n" doc |> isError) "bool admitted")
    check "depth-bound" (fun () -> require (strictJson "json" SmallCap (raw ("{\"a\":"+String('[',129)+"0"+String(']',129)+"}")) |> isError) "depth accepted")
    check "invalid-transport-arguments" (fun () ->
        use input=new MemoryStream()
        use output=new MemoryStream()
        require (createTransport input output Double.NaN |> isError) "NaN deadline accepted"
        require (createTransport input output 301.0 |> isError) "deadline expanded")
    printfn "%s" (JsonSerializer.Serialize {|Passed=rows.Count-failed;Failed=failed;Checks=rows.ToArray();Scope="deterministic transport and passive JSON only"|})
    if failed<>0 then Environment.Exit 1
run()
