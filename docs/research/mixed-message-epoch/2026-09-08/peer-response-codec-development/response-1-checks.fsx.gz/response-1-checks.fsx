#load "../../src/Research.FSharp/MixedMessageEpochReplay.fsx"
open System
open System.Text
open System.Text.Json
open MixedMessageEpochReplay.MixedMessageEpochReplay
let raw (s:string)=Encoding.UTF8.GetBytes s
let rows=ResizeArray<obj>()
let mutable failures=0
let check name f =
    try f();rows.Add(box {|Name=name;Passed=true;Detail=""|})
    with e -> failures<-failures+1;rows.Add(box {|Name=name;Passed=false;Detail=e.ToString()|})
let require c m = if not c then failwith m
let h=String.replicate 64 "A"
let ready=raw ("{\"PlanSha256\":\""+h+"\",\"ServiceSha256\":\""+h+"\"}")
let frame=framePayload ReadyFrame "fixture/session" SmallCap ready
let expected=raw ("{\"Kind\":\"Ready\",\"PlanSha256\":\""+h+"\",\"Schema\":\"zeta.mixed-epoch.peer.v1\",\"ServiceSha256\":\""+h+"\",\"SessionId\":\"fixture/session\"}\n")
check "ready-exact-fixed-canonical-envelope-and-LF" (fun () ->
    require (frame.Failure.IsNone && frame.Raw=Some expected && frame.CanonicalReturn.IsSome) "exact bytes/return lost")
check "complete-bound-includes-delimiter" (fun () ->
    let exact=framePayload ReadyFrame "fixture/session" expected.Length ready
    let small=framePayload ReadyFrame "fixture/session" (expected.Length-1) ready
    require (exact.Raw=Some expected && small.Failure.Value.Code="FrameBound" && small.CanonicalReturn.IsNone) "off-by-one expansion")
check "zero-allowance-before-payload-prewalk" (fun () ->
    let actual=framePayload ReadyFrame "fixture" 0 (raw "malformed")
    require (actual.Failure.Value.Code="FrameArguments" && actual.CanonicalReturn.IsNone && actual.Payload=raw "malformed") "bound/payload retention")
check "null-payload-typed" (fun () -> require ((framePayload ReadyFrame "fixture" 1 null).Failure.IsSome) "null accepted")
check "invalid-session-refuses-before-core" (fun () ->
    let a=framePayload ReadyFrame "fixture\"" SmallCap ready
    require (a.Failure.IsSome && a.CanonicalReturn.IsNone) "bad identity")
check "unknown-payload-member-refused" (fun () ->
    let a=framePayload ReadyFrame "fixture" SmallCap (raw "{\"PlanSha256\":\"a\",\"ServiceSha256\":\"b\",\"Extra\":0}")
    require (a.Failure.Value.Code="FrameKeys" && a.CanonicalReturn.IsNone) "unknown key")
check "reserved-envelope-key-refused" (fun () ->
    let a=framePayload ReadyFrame "fixture" SmallCap (raw "{\"Kind\":\"Ready\",\"PlanSha256\":\"a\",\"ServiceSha256\":\"b\"}")
    require (a.Failure.Value.Code="FrameKeys") "envelope collision")
check "duplicate-payload-member-refused" (fun () ->
    let a=framePayload ReadyFrame "fixture" SmallCap (raw "{\"PlanSha256\":\"a\",\"PlanSha256\":\"a\",\"ServiceSha256\":\"b\"}")
    require (a.Failure.Value.Code="JsonShape" && a.CanonicalReturn.IsNone) "duplicate key")
check "float-integer-only-core-refusal-retained" (fun () ->
    let a=framePayload EpochReturnFrame "fixture" SmallCap (raw "{\"Sequence\":1,\"Result\":{\"Bad\":1.5},\"ResultSha256\":\"a\"}")
    require (a.Failure.Value.Code="FrameEncoding" && a.CanonicalReturn.IsSome && Result.isError a.CanonicalReturn.Value && a.Raw.IsNone) "actual codec error lost")
check "returned-type-plus-and-unicode-remain-literal" (fun () ->
    let payload=raw "{\"Sequence\":1,\"Result\":{\"Type\":\"Zeta.Bayesian.BoundedModuleLearner+StepAttempt\",\"Text\":\"é😀<>&+\"},\"ResultSha256\":\"a\"}"
    let a=framePayload EpochReturnFrame "fixture" SmallCap payload
    let e=raw "{\"Kind\":\"EpochReturn\",\"Result\":{\"Text\":\"é😀<>&+\",\"Type\":\"Zeta.Bayesian.BoundedModuleLearner+StepAttempt\"},\"ResultSha256\":\"a\",\"Schema\":\"zeta.mixed-epoch.peer.v1\",\"Sequence\":1,\"SessionId\":\"fixture\"}\n"
    require (a.Raw=Some e && a.Payload=payload) "UTF8/default escaping mismatch")
check "ordinary-checkpoint-retains-small-cap" (fun () ->
    let p=raw ("{\"Sequence\":1,\"Observation\":{\"Fixture\":\""+String.replicate SmallCap "x"+"\"},\"LastRevision\":0,\"StateSha256\":\"a\"}")
    let a=framePayload (CheckpointFrame false) "fixture" ResultCap p
    let b=framePayload (CheckpointFrame true) "fixture" ResultCap p
    require (a.Failure.Value.Code="FrameBound" && a.CanonicalReturn.IsNone && b.Raw.IsSome) "checkpoint caps do not distinguish actual projection-bearing route")
check "raw-layout-is-not-an-extra-core-return" (fun () ->
    let a=framePayload ReadyFrame "fixture" SmallCap (raw " {} ")
    require (a.Failure.Value.Code="FrameBound" && a.CanonicalReturn.IsNone) "noncore braces admitted")

module ME=Zeta.Bayesian.MixedMessageEpoch
let get=function Ok x->x|Error e->failwithf "%A" e
let budget:ME.BudgetSnapshot={SnapshotIndex=2;CompletedSessions=0;PriorWork=ME.zeroWork;Store={ReservedCombinedBytes=1000L;ReservedArtifactSlots=1};TranscriptBytes=1000L;TranscriptFrames=3;PeerLaunchAttempted=1;NativePreparationEntered=0;RemainingMilliseconds=299000}
let budgetText=Encoding.UTF8.GetString(ME.tryEncodeBudgetSnapshot budget |> get)
let hash (x:byte[])=Convert.ToHexString(Security.Cryptography.SHA256.HashData x)
let sent=raw "{\"fixture\":\"actual-sent-bytes\"}\n"
let sentHash=hash sent
let descriptor="{\"File\":\"fixture/0001.json\",\"Encoding\":\"identity\",\"Bytes\":"+string sent.Length+",\"Sha256\":\""+sentHash+"\",\"StoredBytes\":"+string sent.Length+",\"StoredSha256\":\""+sentHash+"\"}"
let ack session seq digest outcome=raw ("{\"Kind\":\"CheckpointAck\",\"Schema\":\"zeta.mixed-epoch.peer.v1\",\"SessionId\":\""+session+"\",\"Sequence\":"+string seq+",\"CheckpointSha256\":\""+digest+"\",\"Outcome\":"+outcome+",\"BudgetSnapshot\":"+budgetText+"}\n")
let stored="{\"Kind\":\"stored\",\"Artifact\":"+descriptor+"}"
let refused="{\"Kind\":\"refused\",\"Failure\":{\"Code\":\"Storage\",\"Stage\":\"publish\",\"Field\":null,\"Message\":\"actual fixture refusal\"}}"
check "actual-stored-ACK-decode-and-original-LF-hash" (fun () ->
    let received=ack "fixture" 1 sentHash stored
    let a=admitAcknowledgment "fixture" 1 sent received
    require (a.Failure.IsNone && a.Stored.IsSome && a.StoredReturn.IsSome && a.Raw=received && a.Stored.Value.Artifact.Encoding="identity") "matching original not retained")
check "stored-ACK-wrong-session-retains-actual-decoded-value" (fun () ->
    let a=admitAcknowledgment "fixture" 1 sent (ack "wrong" 1 sentHash stored)
    require (a.Failure.Value.Code="ResponseIdentity" && a.Stored.IsNone && Result.isOk a.StoredReturn.Value) "decoded candidate lost")
check "stored-ACK-wrong-sequence-retains-decoded-value" (fun () ->
    let a=admitAcknowledgment "fixture" 1 sent (ack "fixture" 2 sentHash stored)
    require (a.Failure.Value.Code="AckCorrespondence" && Result.isOk a.StoredReturn.Value) "sequence accepted")
check "stored-ACK-hash-without-LF-refused" (fun () ->
    let a=admitAcknowledgment "fixture" 1 sent (ack "fixture" 1 (hash sent[..sent.Length-2]) stored)
    require (a.Failure.Value.Code="AckCorrespondence") "LF omitted")
check "stored-ACK-gzip-assumption-refused-for-selected-identity-Store" (fun () ->
    let a=admitAcknowledgment "fixture" 1 sent (ack "fixture" 1 sentHash (stored.Replace("identity","gzip")))
    require (a.Failure.Value.Code="AckCorrespondence" && Result.isOk a.StoredReturn.Value) "wrong Store encoding accepted")
check "stored-ACK-stored-bytes-must-match-actual-identity-descriptor" (fun () ->
    let wrong=stored.Replace("\"StoredBytes\":"+string sent.Length,"\"StoredBytes\":1")
    let a=admitAcknowledgment "fixture" 1 sent (ack "fixture" 1 sentHash wrong)
    require (a.Failure.Value.Code="AckCorrespondence") "stored size accepted")
check "actual-refused-ACK-and-budget-retained" (fun () ->
    let a=admitAcknowledgment "fixture" 1 sent (ack "fixture" 1 sentHash refused)
    require (a.Failure.IsNone && a.Stored.IsNone && a.Refused.Value.Code="Storage" && a.BudgetReturn.IsSome) "refusal promoted or discarded")
check "refused-ACK-wrong-session-retains-original-refusal" (fun () ->
    let a=admitAcknowledgment "fixture" 1 sent (ack "other" 1 sentHash refused)
    require (a.Failure.Value.Code="ResponseIdentity" && a.Refused.Value.Message="actual fixture refusal" && a.BudgetReturn.IsSome) "original refusal lost")
check "refused-ACK-unknown-failure-code-refused" (fun () ->
    let a=admitAcknowledgment "fixture" 1 sent (ack "fixture" 1 sentHash (refused.Replace("Storage","Invented")))
    require (a.Failure.Value.Code="FailureShape" && Result.isOk a.Parsed) "unregistered code accepted")
check "ACK-null-original-typed-no-hash" (fun () ->
    let a=admitAcknowledgment "fixture" 1 null (ack "fixture" 1 sentHash stored)
    require (a.Failure.Value.Code="AckArguments" && a.StoredReturn.IsNone) "null sent accepted")
let peer:ME.PeerIdentity={SessionId="fixture";ServiceSha256=h}
let request:ME.ProjectionRequest={Sequence=3;RequestId="projection/3";InputRevision=0L;Base={PrecisionMean=0.;Precision=1.};TargetBits={Precision=1.;Location=0.;Linear=0.;ExponentialRate=1.};RawInputHex="00";InputSha256=h;CaseId="fixture/projection/3";BindingsSha256=h;Remaining={Work=ME.zeroWork;Store={CombinedBytes=1L;ArtifactSlots=1};TranscriptBytes=1L;TranscriptFrames=1;RemainingMilliseconds=1;SnapshotIndex=1}}
let response session seq inputHash failure=raw ("{\"Kind\":\"ProjectionResponse\",\"Schema\":\"zeta.mixed-epoch.peer.v1\",\"SessionId\":\""+session+"\",\"Sequence\":"+string seq+",\"RequestId\":\"projection/3\",\"InputSha256\":\""+inputHash+"\",\"BindingsSha256\":\""+h+"\",\"ServiceSha256\":\""+h+"\",\"Native\":null,\"Certificate\":null,\"Failure\":"+failure+",\"BudgetSnapshot\":"+budgetText+"}\n")
let serviceFailure="{\"Code\":\"Service\",\"Stage\":\"project\",\"Field\":null,\"Message\":\"synthetic service refusal\"}"
check "actual-response-decode-retains-service-refusal-without-promotion" (fun () ->
    let a=admitProjectionResponse peer request (response "fixture" 3 h serviceFailure)
    require (a.Failure.IsNone && a.Response.Value.Failure.Value.Code="Service" && a.DecodedReturn.IsSome) "refusal discarded")
check "response-wrong-input-retains-actual-return" (fun () ->
    let a=admitProjectionResponse peer request (response "fixture" 3 (String.replicate 64 "B") serviceFailure)
    require (a.Failure.Value.Code="ProjectionCorrespondence" && Result.isOk a.DecodedReturn.Value && a.Response.IsNone) "input mismatch accepted")
check "response-wrong-session-retains-actual-return" (fun () ->
    let a=admitProjectionResponse peer request (response "other" 3 h serviceFailure)
    require (a.Failure.Value.Code="ResponseIdentity" && Result.isOk a.DecodedReturn.Value) "session mismatch accepted")
check "response-unknown-failure-retains-decoded-candidate" (fun () ->
    let a=admitProjectionResponse peer request (response "fixture" 3 h (serviceFailure.Replace("project","invented")))
    require (a.Failure.Value.Code="FailureShape" && Result.isOk a.DecodedReturn.Value && a.Response.IsNone) "unknown stage accepted")
check "response-null-request-typed-no-core-decode" (fun () ->
    let a=admitProjectionResponse peer Unchecked.defaultof<ME.ProjectionRequest> (response "fixture" 3 h serviceFailure)
    require (a.Failure.Value.Code="ResponseArguments" && a.DecodedReturn.IsNone) "null request accepted")
let summary={|Scope="Synthetic fixed frame/ACK/response bytes with actual core codecs; no storage, scheduler, learner, kernel, projection or named M4/M5 operation";Passed=rows.Count-failures;Failed=failures;Checks=rows.ToArray()|}
printfn "%s" (JsonSerializer.Serialize summary)
Environment.Exit(if failures=0 then 0 else 1)
