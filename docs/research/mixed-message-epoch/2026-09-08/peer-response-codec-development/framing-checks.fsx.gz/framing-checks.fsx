#load "../../src/Research.FSharp/MixedMessageEpochReplay.fsx"
open System
open System.Text
open System.Text.Json
open MixedMessageEpochReplay.MixedMessageEpochReplay
let raw (s:string)=Encoding.UTF8.GetBytes s
let rows=ResizeArray<obj>()
let mutable failures=0
let check name f =
    try f();rows.Add(box {|Name=name;Passed=true;Detail=""|})
    with e -> failures<-failures+1;rows.Add(box {|Name=name;Passed=false;Detail=e.ToString()|})
let require c m = if not c then failwith m
let h=String.replicate 64 "A"
let ready=raw ("{\"PlanSha256\":\""+h+"\",\"ServiceSha256\":\""+h+"\"}")
let frame=framePayload ReadyFrame "fixture/session" SmallCap ready
let expected=raw ("{\"Kind\":\"Ready\",\"PlanSha256\":\""+h+"\",\"Schema\":\"zeta.mixed-epoch.peer.v1\",\"ServiceSha256\":\""+h+"\",\"SessionId\":\"fixture/session\"}\n")
check "ready-exact-fixed-canonical-envelope-and-LF" (fun () ->
    require (frame.Failure.IsNone && frame.Raw=Some expected && frame.CanonicalReturn.IsSome) "exact bytes/return lost")
check "complete-bound-includes-delimiter" (fun () ->
    let exact=framePayload ReadyFrame "fixture/session" expected.Length ready
    let small=framePayload ReadyFrame "fixture/session" (expected.Length-1) ready
    require (exact.Raw=Some expected && small.Failure.Value.Code="FrameBound" && small.CanonicalReturn.IsNone) "off-by-one expansion")
check "zero-allowance-before-payload-prewalk" (fun () ->
    let actual=framePayload ReadyFrame "fixture" 0 (raw "malformed")
    require (actual.Failure.Value.Code="FrameArguments" && actual.CanonicalReturn.IsNone && actual.Payload=raw "malformed") "bound/payload retention")
check "null-payload-typed" (fun () -> require ((framePayload ReadyFrame "fixture" 1 null).Failure.IsSome) "null accepted")
check "invalid-session-refuses-before-core" (fun () ->
    let a=framePayload ReadyFrame "fixture\"" SmallCap ready
    require (a.Failure.IsSome && a.CanonicalReturn.IsNone) "bad identity")
check "unknown-payload-member-refused" (fun () ->
    let a=framePayload ReadyFrame "fixture" SmallCap (raw "{\"PlanSha256\":\"a\",\"ServiceSha256\":\"b\",\"Extra\":0}")
    require (a.Failure.Value.Code="FrameKeys" && a.CanonicalReturn.IsNone) "unknown key")
check "reserved-envelope-key-refused" (fun () ->
    let a=framePayload ReadyFrame "fixture" SmallCap (raw "{\"Kind\":\"Ready\",\"PlanSha256\":\"a\",\"ServiceSha256\":\"b\"}")
    require (a.Failure.Value.Code="FrameKeys") "envelope collision")
check "duplicate-payload-member-refused" (fun () ->
    let a=framePayload ReadyFrame "fixture" SmallCap (raw "{\"PlanSha256\":\"a\",\"PlanSha256\":\"a\",\"ServiceSha256\":\"b\"}")
    require (a.Failure.Value.Code="JsonShape" && a.CanonicalReturn.IsNone) "duplicate key")
check "float-integer-only-core-refusal-retained" (fun () ->
    let a=framePayload EpochReturnFrame "fixture" SmallCap (raw "{\"Sequence\":1,\"Result\":{\"Bad\":1.5},\"ResultSha256\":\"a\"}")
    require (a.Failure.Value.Code="FrameEncoding" && a.CanonicalReturn.IsSome && Result.isError a.CanonicalReturn.Value && a.Raw.IsNone) "actual codec error lost")
check "returned-type-plus-and-unicode-remain-literal" (fun () ->
    let payload=raw "{\"Sequence\":1,\"Result\":{\"Type\":\"Zeta.Bayesian.BoundedModuleLearner+StepAttempt\",\"Text\":\"é😀<>&+\"},\"ResultSha256\":\"a\"}"
    let a=framePayload EpochReturnFrame "fixture" SmallCap payload
    let e=raw "{\"Kind\":\"EpochReturn\",\"Result\":{\"Text\":\"é😀<>&+\",\"Type\":\"Zeta.Bayesian.BoundedModuleLearner+StepAttempt\"},\"ResultSha256\":\"a\",\"Schema\":\"zeta.mixed-epoch.peer.v1\",\"Sequence\":1,\"SessionId\":\"fixture\"}\n"
    require (a.Raw=Some e && a.Payload=payload) "UTF8/default escaping mismatch")
check "ordinary-checkpoint-retains-small-cap" (fun () ->
    let p=raw ("{\"Sequence\":1,\"Observation\":{\"Fixture\":\""+String.replicate SmallCap "x"+"\"},\"LastRevision\":0,\"StateSha256\":\"a\"}")
    let a=framePayload (CheckpointFrame false) "fixture" ResultCap p
    let b=framePayload (CheckpointFrame true) "fixture" ResultCap p
    require (a.Failure.Value.Code="FrameBound" && a.CanonicalReturn.IsNone && b.Raw.IsSome) "checkpoint caps do not distinguish actual projection-bearing route")
check "raw-layout-is-not-an-extra-core-return" (fun () ->
    let a=framePayload ReadyFrame "fixture" SmallCap (raw " {} ")
    require (a.Failure.Value.Code="FrameBound" && a.CanonicalReturn.IsNone) "noncore braces admitted")
let summary={|Scope="Synthetic fixed-frame payloads and actual core canonical codec only; no scheduler, learner, kernel, projection or named M4/M5 control";Passed=rows.Count-failures;Failed=failures;Checks=rows.ToArray()|}
printfn "%s" (JsonSerializer.Serialize summary)
Environment.Exit(if failures=0 then 0 else 1)
