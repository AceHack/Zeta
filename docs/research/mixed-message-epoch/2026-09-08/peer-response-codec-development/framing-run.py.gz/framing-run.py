from pathlib import Path
import subprocess,json,hashlib,datetime
p=Path(__file__).resolve().parent;root=p.parent.parent
source=root/'src/Research.FSharp/MixedMessageEpochReplay.fsx';raw=source.read_bytes();args=['dotnet','fsi','--quiet','--exec',str(p/'checks.fsx')]
(p/'invocation.json').write_text(json.dumps({'Argv':args,'SourceBytes':len(raw),'SourceSha256':hashlib.sha256(raw).hexdigest().upper(),'StartedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'Scope':'Synthetic framing and actual core canonical codec; no numerical/epoch operation'},indent=2)+'\n')
with (p/'stdout').open('xb') as o,(p/'stderr').open('xb') as e:result=subprocess.run(args,cwd=root,stdout=o,stderr=e,timeout=60)
(p/'completion.json').write_text(json.dumps({'ExitCode':result.returncode,'FinishedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
print(result.returncode);print((p/'stdout').read_text());print((p/'stderr').read_text());raise SystemExit(result.returncode)
