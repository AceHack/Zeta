from pathlib import Path
import gzip,hashlib,json,stat
root=Path.cwd();out=root/'docs/research/mixed-message-epoch/2026-09-08/peer-response-codec-development';out.mkdir(parents=True)
def sha(raw):return hashlib.sha256(raw).hexdigest().upper()
selected=[]
for prefix,folder,names in [
 ('framing','.git/mixed-message-peer-frame-codec-checks-1',['MixedMessageEpochReplay.fsx','checks.fsx','run.py','invocation.json','stdout','stderr','completion.json']),
 ('response-1','.git/mixed-message-peer-response-codec-checks-1',['MixedMessageEpochReplay.fsx','checks.fsx','run.py','invocation.json','stdout','stderr','completion.json']),
 ('response-2','.git/mixed-message-peer-response-codec-checks-2',['MixedMessageEpochReplay.fsx','checks.fsx','run.py','invocation.json','stdout','stderr','completion.json']),
 ('static-correction','.git/mixed-message-peer-ack-static-correction-1',['MixedMessageEpochReplay.fsx','finding.json']),
 ('quick','.git/mixed-message-peer-response-codec-gate-1',['invocation.json','stdout','stderr','completion.json'])]:
 for name in names:selected.append((prefix+'-'+name,folder+'/'+name))
selected.append(('preserve.py','.git/mixed-message-peer-response-codec-preservation-1/preserve.py'))
records=[]
for name,relative in selected:
 p=root/relative;info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_size<=4*1024*1024
 raw=p.read_bytes();assert len(raw)==info.st_size
 packed=gzip.compress(raw,mtime=0);filename=name+'.gz'
 with (out/filename).open('xb') as f:f.write(packed)
 records.append({'File':filename,'Encoding':'gzip','Bytes':len(raw),'Sha256':sha(raw),'StoredBytes':len(packed),'StoredSha256':sha(packed),'OriginalPath':relative})
source=(root/'src/Research.FSharp/MixedMessageEpochReplay.fsx').read_bytes()
assert source==(root/'.git/mixed-message-peer-response-codec-checks-2/MixedMessageEpochReplay.fsx').read_bytes()
assert json.loads((root/'.git/mixed-message-peer-response-codec-checks-1/completion.json').read_bytes())['ExitCode']==1
for folder,count in [('.git/mixed-message-peer-frame-codec-checks-1',12),('.git/mixed-message-peer-response-codec-checks-2',27)]:
 assert json.loads((root/folder/'completion.json').read_bytes())['ExitCode']==0
 actual=json.loads((root/folder/'stdout').read_text());assert actual['Passed']==count and actual['Failed']==0
assert json.loads((root/'.git/mixed-message-peer-response-codec-gate-1/completion.json').read_bytes())['ExitCode']==0
manifest={'Schema':'zeta.mixed-message.peer-response-codec-development.v1','CompletePeer':False,'NamedControlsRun':False,'ActualCoreCodecs':True,'StorageSchedulerLearnerKernelProjectionInvoked':False,'CurrentSource':{'Bytes':len(source),'Sha256':sha(source)},'Records':records}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'Records':len(records),'OriginalBytes':sum(r['Bytes'] for r in records),'StoredBytes':sum(r['StoredBytes'] for r in records),'Source':manifest['CurrentSource']}))
