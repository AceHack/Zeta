#load "../../src/Research.FSharp/MixedMessageEpochReplay.fsx"
open System
open System.IO
open System.Text
open System.Text.Json
open System.Threading
open System.Threading.Tasks
open MixedMessageEpochReplay.MixedMessageEpochReplay
let raw (s:string) = Encoding.UTF8.GetBytes s
let awaitResult (t:Task<'T>) = t.GetAwaiter().GetResult()
let transport input output seconds = match createTransport input output seconds with Ok x -> x | Error e -> failwithf "%A" e
let isError = function Error _ -> true | Ok _ -> false
let require condition message = if not condition then failwith message
let get = function Ok x -> x | Error e -> failwithf "%A" e
let rows = ResizeArray<obj>()
let mutable failed = 0
let check name action =
    try action(); rows.Add(box {|Name=name; Passed=true; Detail=""|})
    with e -> failed <- failed+1; rows.Add(box {|Name=name; Passed=false; Detail=e.ToString()|})
// Real MemoryStream with a controlled partial physical write.
type PartialOutput() =
    inherit MemoryStream()
    let mutable attempts = 0
    member _.Attempts = attempts
    override this.WriteAsync(buffer:ReadOnlyMemory<byte>, _token:CancellationToken) =
        attempts <- attempts+1
        this.Write(buffer.Span.Slice(0,1))
        ValueTask(Task.FromException(IOException("synthetic failure after actual one-byte write")))
type FlushOutput() =
    inherit MemoryStream()
    override _.FlushAsync(_token:CancellationToken) = Task.FromException(IOException("synthetic flush failure"))
type ChunkInput(bytes:byte[], chunk:int) =
    inherit MemoryStream(bytes)
    override this.ReadAsync(buffer:Memory<byte>, _token:CancellationToken) =
        ValueTask<int>(this.Read(buffer.Span.Slice(0,min chunk buffer.Length)))
type ThrowInput() =
    inherit MemoryStream()
    override _.ReadAsync(_buffer:Memory<byte>, _token:CancellationToken) : ValueTask<int> =
        raise (IOException("synthetic synchronous read failure"))
type PendingInput() =
    inherit MemoryStream()
    let completion = TaskCompletionSource<int>(TaskCreationOptions.RunContinuationsAsynchronously)
    let mutable buffer = Memory<byte>.Empty
    let mutable closes=0
    member _.Complete(bytes:byte[]) = bytes.CopyTo(buffer); completion.SetResult(bytes.Length)
    member _.Closes=closes
    override _.ReadAsync(next:Memory<byte>, _token:CancellationToken) = buffer<-next; ValueTask<int>(completion.Task)
    override this.Dispose(disposing:bool) = closes<-closes+1; base.Dispose(disposing)
let run () =
    check "partial-output-refuses-any-later-frame" (fun () ->
        use input=new MemoryStream()
        use output=new PartialOutput()
        let state=transport input output 5.0
        require (writeFrame state "first" SmallCap false (raw "{}\n") |> awaitResult |> isError) "first must refuse"
        require (writeFrame state "terminal" TerminalCap true (raw "{}\n") |> awaitResult |> isError) "terminal must refuse"
        require (output.Attempts=1 && output.Length=1L) "later physical append occurred"
        let seen=snapshot state
        require (seen.OutputFailed && seen.CompletedWriteBytes=0 && seen.ChargedBytes=3 && seen.Frames.Length=1) "actual partial prefix/reservation lost"
        require (seen.Frames.[0].Raw=raw "{}\n" && seen.Failure.Value.Code="WriteFailure") "original attempted bytes/first failure lost")
    check "flush-failure-is-not-completed-output" (fun () ->
        use input=new MemoryStream()
        use output=new FlushOutput()
        let state=transport input output 5.0
        require (writeFrame state "out" SmallCap false (raw "{}\n") |> awaitResult |> isError) "flush must refuse"
        require (output.ToArray()=raw "{}\n" && (snapshot state).CompletedWriteBytes=0 && (snapshot state).OutputFailed) "completed bytes invented")
    check "chunked-frame-exact-prefix" (fun () ->
        use input=new ChunkInput(raw "{\"a\":1}\n",2)
        use output=new MemoryStream()
        let state=transport input output 5.0
        let value=readFrame state "read" SmallCap |> awaitResult |> get
        let seen=snapshot state
        require (value=raw "{\"a\":1}\n" && seen.ReadBytes=value.Length && seen.ChargedFrames=1 && seen.Frames.[0].Complete) "chunk identity differs")
    check "premature-eof-retains-prefix" (fun () ->
        use input=new MemoryStream(raw "{\"a\":")
        use output=new MemoryStream()
        let state=transport input output 5.0
        require (readFrame state "read" SmallCap |> awaitResult |> isError) "EOF must refuse"
        let seen=snapshot state
        require (seen.Frames.[0].Raw=raw "{\"a\":" && seen.Failure.Value.Code="UnexpectedEof") "prefix missing"
        require (writeFrame state "ordinary" SmallCap false (raw "{}\n") |> awaitResult |> isError) "continued ordinary work"
        writeFrame state "terminal" TerminalCap true (raw "{}\n") |> awaitResult |> get)
    check "trailing-second-frame-refused-retained" (fun () ->
        use input=new MemoryStream(raw "{}\n{}\n")
        use output=new MemoryStream()
        let state=transport input output 5.0
        require (readFrame state "read" SmallCap |> awaitResult |> isError) "extra must refuse"
        require ((snapshot state).Frames.[0].Raw=raw "{}\n{}\n") "extra bytes omitted")
    check "frame-bound-reads-at-most-cap-plus-one" (fun () ->
        use input=new MemoryStream(raw "123456789\n")
        use output=new MemoryStream()
        let state=transport input output 5.0
        require (readFrame state "read" 4 |> awaitResult |> isError) "oversize must refuse"
        require ((snapshot state).ReadBytes=5 && input.Position=5L) "unbounded read")
    check "pending-read-owned-and-late-bytes-retained" (fun () ->
        use input=new PendingInput()
        use output=new MemoryStream()
        let state=transport input output 0.01
        require (readFrame state "read" SmallCap |> awaitResult |> isError) "timeout must refuse"
        require ((snapshot state).PendingRead && input.Closes=0) "pending stream was disposed"
        input.Complete(raw "{}\n")
        let seen=snapshot state
        require (seen.LateReadBytes=Some(raw "{}\n") && seen.ReadBytes=0 && not seen.PendingRead && input.Closes=0) "late observation relabeled as admitted")
    check "synchronous-read-throw-is-typed" (fun () ->
        use input=new ThrowInput()
        use output=new MemoryStream()
        let state=transport input output 5.0
        require (readFrame state "read" SmallCap |> awaitResult |> isError) "throw escaped"
        require ((snapshot state).Frames.Length=1 && (snapshot state).Frames.[0].Raw.Length=0) "empty reached prefix lost")
    check "strict-duplicate-key" (fun () -> require (strictJson "json" SmallCap (raw "{\"a\":0,\"a\":1}") |> isError) "duplicate accepted")
    check "strict-nested-duplicate-key" (fun () -> require (strictJson "json" SmallCap (raw "{\"a\":{\"b\":0,\"b\":1}}") |> isError) "nested duplicate accepted")
    check "strict-deferred-surrogate" (fun () -> require (strictJson "json" SmallCap (raw "{\"a\":\"\\ud800\"}") |> isError) "surrogate accepted")
    check "strict-invalid-utf8" (fun () -> require (strictJson "json" SmallCap [|123uy;34uy;97uy;34uy;58uy;34uy;255uy;34uy;125uy|] |> isError) "invalid UTF8 accepted")
    check "strict-overflow-number" (fun () -> require (strictJson "json" SmallCap (raw "{\"a\":[1e400]}") |> isError) "infinite exponent accepted")
    check "bounded-large-integer-remains-passive" (fun () -> strictJson "json" SmallCap (raw ("{\"n\":"+String('9',4096)+"}")) |> get |> ignore)
    check "too-large-integer-refused-before-clone" (fun () -> require (strictJson "json" SmallCap (raw ("{\"n\":"+String('9',4097)+"}")) |> isError) "integer cap missed")
    check "array-root-refused" (fun () -> require (strictJson "json" SmallCap (raw "[]") |> isError) "array root accepted")
    check "typed-field-helpers-refuse-nonobject" (fun () ->
        use doc=JsonDocument.Parse "[]"
        require (exactKeys "shape" [|"x"|] doc.RootElement |> isError) "keys threw/accepted"
        require (stringField "shape" "x" doc.RootElement |> isError) "string threw/accepted"
        require (integerField "shape" "x" doc.RootElement |> isError) "integer threw/accepted")
    check "boolean-is-not-protocol-integer" (fun () ->
        let doc=strictJson "json" SmallCap (raw "{\"n\":true}") |> get
        require (integerField "shape" "n" doc |> isError) "bool admitted")
    check "depth-bound" (fun () -> require (strictJson "json" SmallCap (raw ("{\"a\":"+String('[',129)+"0"+String(']',129)+"}")) |> isError) "depth accepted")
    check "invalid-transport-arguments" (fun () ->
        use input=new MemoryStream()
        use output=new MemoryStream()
        require (createTransport input output Double.NaN |> isError) "NaN deadline accepted"
        require (createTransport input output 301.0 |> isError) "deadline expanded")
    check "empty-eof-does-not-mint-frame-position" (fun () ->
        use input=new MemoryStream()
        use output=new MemoryStream()
        let state=transport input output 5.0
        require (readFrame state "read" SmallCap |> awaitResult |> isError) "empty EOF accepted"
        let seen=snapshot state
        require (seen.ReadFrames=0 && seen.ChargedFrames=0 && seen.GlobalChargedFrames=0 && seen.Frames.Length=1) "empty read miscounted")
    check "budget-rebase-does-not-double-sum-prefix" (fun () ->
        use input=new ChunkInput(raw "{}\n{}\n",3)
        use output=new MemoryStream()
        let state=transport input output 5.0
        readFrame state "start" SmallCap |> awaitResult |> get |> ignore
        observeBudgetPrefix state 0 100 5 5000 |> get
        writeFrame state "ready" SmallCap false (raw "{}\n") |> awaitResult |> get
        readFrame state "ack" SmallCap |> awaitResult |> get |> ignore
        observeBudgetPrefix state 1 106 7 4000 |> get
        let seen=snapshot state
        require (seen.ChargedBytes=9 && seen.GlobalChargedBytes=109 && seen.ChargedFrames=3 && seen.GlobalChargedFrames=8) "global prefix added twice"
        require (seen.ReadBytes=6 && seen.ReadFrames=2 && seen.ReservedWriteBytes=3 && seen.ReservedWriteFrames=1 && seen.CompletedWriteFrames=1) "separate positions differ")
    check "budget-refuses-missing-known-positions" (fun () ->
        use input=new ChunkInput(raw "{}\n{}\n",3)
        use output=new MemoryStream()
        let state=transport input output 5.0
        readFrame state "start" SmallCap |> awaitResult |> get |> ignore
        observeBudgetPrefix state 0 100 5 5000 |> get
        writeFrame state "ready" SmallCap false (raw "{}\n") |> awaitResult |> get
        readFrame state "ack" SmallCap |> awaitResult |> get |> ignore
        require (observeBudgetPrefix state 1 100 5 4000 |> isError) "missing positions accepted"
        require ((snapshot state).GlobalChargedBytes=109 && (snapshot state).Frames.Length=3) "observed prefix was erased")
    check "budget-refuses-reusing-carrier" (fun () ->
        use input=new MemoryStream(raw "{}\n")
        use output=new MemoryStream()
        let state=transport input output 5.0
        readFrame state "start" SmallCap |> awaitResult |> get |> ignore
        observeBudgetPrefix state 0 100 5 5000 |> get
        require (observeBudgetPrefix state 1 103 6 4000 |> isError) "same carrier accepted twice")
    check "prior-session-global-budget-restricts-local-output" (fun () ->
        use input=new MemoryStream(raw "{}\n")
        use output=new MemoryStream()
        let state=transport input output 5.0
        readFrame state "start" SmallCap |> awaitResult |> get |> ignore
        observeBudgetPrefix state 0 (61*1024*1024) 100 5000 |> get
        let tooLarge=Array.create<byte> (3*1024*1024) 32uy
        tooLarge.[tooLarge.Length-1]<-10uy
        require (writeFrame state "out" ResultCap false tooLarge |> awaitResult |> isError) "fresh local quota ignored global prefix"
        require (output.Length=0L && (snapshot state).ReservedWriteBytes=0) "oversize output entered"
        writeFrame state "terminal" TerminalCap true (raw "{}\n") |> awaitResult |> get)
    check "same-descriptor-regular-file-observation" (fun () ->
        let path=Path.Combine(__SOURCE_DIRECTORY__,"fixture.bin")
        let actual=observeFile path 1024
        let bytes=File.ReadAllBytes path
        let expected=System.Security.Cryptography.SHA256.HashData bytes |> Convert.ToHexString
        require (actual.Complete && actual.Bytes=Some(int64 bytes.Length) && actual.ReadBytes=bytes.Length && actual.Sha256=Some expected && actual.ExtraRead=Some -1 && actual.Cleanup=[]) "source identity differs")
    check "file-size-refusal-precedes-content-read" (fun () ->
        let actual=observeFile (Path.Combine(__SOURCE_DIRECTORY__,"fixture.bin")) 1
        require (not actual.Complete && actual.ReadBytes=0 && actual.Sha256=None && actual.Failure.Value.Code="FileBound") "oversize content read")
    check "source-leaf-symlink-refused" (fun () ->
        let actual=observeFile (Path.Combine(__SOURCE_DIRECTORY__,"fixture-link")) 1024
        require (not actual.Complete && actual.ReadBytes=0 && actual.Failure.Value.Code="FileOpen") "symlink followed")
    check "source-directory-refused-before-read" (fun () ->
        let actual=observeFile (Path.Combine(__SOURCE_DIRECTORY__,"fixture-dir")) 1024
        require (not actual.Complete && actual.ReadBytes=0 && actual.Failure.Value.Code="FileKind") "directory read")
    check "source-fifo-nonblocking-refusal" (fun () ->
        let actual=observeFile (Path.Combine(__SOURCE_DIRECTORY__,"fixture-fifo")) 1024
        require (not actual.Complete && actual.ReadBytes=0 && actual.Failure.Value.Code="FileKind") "FIFO read/blocked")
    let repository=Path.GetFullPath(Path.Combine(__SOURCE_DIRECTORY__,"..",".."))
    let paths=[PeerRepositoryPath;"src/Core/bin/Release/net10.0/Zeta.Core.dll";"src/Core.Abstractions/bin/Release/net10.0/Zeta.Core.Abstractions.dll";"src/Bayesian/bin/Release/net10.0/Zeta.Bayesian.dll"]
    let sourceBindings=paths |> List.map (fun path ->
        let full=Path.Combine(repository,path)
        require (FileInfo(full).Length<=32L*1024L*1024L) "fixture direct file exceeds bound"
        path,Convert.ToHexString(System.Security.Cryptography.SHA256.HashData(File.ReadAllBytes full))) |> Map.ofList
    let observed label bindings =
        let actual=observeDirectSources bindings
        printfn "DIRECT_SOURCE_RESULT %s %A" label actual
        actual
    check "source-executing-script-and-three-actual-assemblies" (fun () ->
        let actual=observed "complete" sourceBindings
        require (actual.Complete && actual.Failure=None && actual.Observations.Length=4) "source admission failed"
        require (actual.Observations |> List.map (fun r -> r.RepositoryPath) = paths) "direct order differs"
        require (actual.Observations.Head.AssemblyName=None && (actual.Observations.Tail |> List.forall (fun r -> r.AssemblyName.IsSome))) "actual load identities missing")
    check "changed-second-source-hash-retains-read-prefix" (fun () ->
        let actual=observed "wrong-second-hash" (Map.add paths[1] (String('0',64)) sourceBindings)
        require (not actual.Complete && actual.Observations.Length=2 && actual.Failure.Value.Code="SourceHash") "wrong hash passed or read later file"
        require (actual.Observations.Head.File.Value.Complete && actual.Observations[1].File.Value.Sha256=Some sourceBindings[paths[1]]) "actual file identity lost")
    check "missing-third-source-retains-locator-before-refusal" (fun () ->
        let actual=observed "missing-third" (Map.remove paths[2] sourceBindings)
        require (not actual.Complete && actual.Observations.Length=3 && actual.Failure.Value.Code="SourceBindingMissing") "missing source admitted"
        require (actual.Observations[2].ActualPath.IsSome && actual.Observations[2].AssemblyName.IsSome && actual.Observations[2].File=None) "actual locator lost or file unnecessarily read")
    check "changed-script-hash-refuses-before-dll-observations" (fun () ->
        let actual=observed "wrong-script-hash" (Map.add paths[0] (String('0',64)) sourceBindings)
        require (not actual.Complete && actual.Observations.Length=1 && actual.Failure.Value.Code="SourceHash") "script mismatch passed")
    check "empty-source-map-refuses-before-files" (fun () ->
        let actual=observed "empty-map" Map.empty
        require (not actual.Complete && actual.Observations.IsEmpty && actual.Failure.Value.Code="SourceBindings") "empty map accessed files")
    check "null-source-map-refuses-before-files" (fun () ->
        let actual=observed "null-map" Unchecked.defaultof<Map<string,string>>
        require (not actual.Complete && actual.Observations.IsEmpty && actual.Failure.Value.Code="SourceBindings") "null map threw or accessed files")
    check "malformed-hash-refuses-before-files" (fun () ->
        let actual=observed "bad-hash" (Map.add paths[1] "bad" sourceBindings)
        require (not actual.Complete && actual.Observations.IsEmpty && actual.Failure.Value.Code="SourceBindings") "bad hash accessed files")
    check "source-roster-cap-before-files" (fun () ->
        let excessive=[for i in 0..128 -> string i,String('A',64)] |> Map.ofList
        let actual=observed "excess-roster" excessive
        require (not actual.Complete && actual.Observations.IsEmpty && actual.Failure.Value.Code="SourceBindings") "oversize map accessed files")
    printfn "%s" (JsonSerializer.Serialize {|Passed=rows.Count-failed;Failed=failed;Checks=rows.ToArray();Scope="deterministic transport, passive JSON and actual direct-file metadata only"|})
    if failed<>0 then Environment.Exit 1
run()
