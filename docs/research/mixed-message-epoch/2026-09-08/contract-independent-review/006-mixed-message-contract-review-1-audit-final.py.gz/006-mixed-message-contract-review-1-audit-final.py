from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

owner=Path("/Users/acehack/.zeta/agents/codex/Zeta-relational-identity-20260906")
root=Path("/Users/acehack/.zeta/agents/codex/Zeta-rendered-catch-reference-20260906")
pin=sys.argv[1]
out=Path(sys.argv[2]);out.mkdir(exist_ok=False)
source_pin="15c634e096674c757f3656c0b8ff9aaa0b5cf203"
paths=["docs/DECISIONS/2026-09-08-checked-mixed-message-module-epochs.md","docs/research/2026-09-08-checked-mixed-message-module-epoch-source-contract.md"]

def git(where,*args):
    return subprocess.run(["git",*args],cwd=where,capture_output=True,check=True,timeout=30).stdout

def identity(raw):
    return {"Bytes":len(raw),"Sha256":hashlib.sha256(raw).hexdigest().upper()}

rows=[]
for path in paths:
    raw=git(owner,"show",pin+":"+path)
    assert len(raw)<=128*1024
    (out/Path(path).name).write_bytes(raw)
    row={"Path":path,**identity(raw),"GitBlob":git(owner,"rev-parse",pin+":"+path).decode().strip(),"CurrentEqualsPinned":(owner/path).read_bytes()==raw}
    rows.append(row);assert row["CurrentEqualsPinned"]
text=(out/Path(paths[1]).name).read_text()
additional=[]
for path,count,digest in re.findall(r"^\| `(src/[^`]+|tests/[^`]+)` \| (\d+) \| `([A-F0-9]{64})` \|$",text,re.M):
    raw=git(root,"show",source_pin+":"+path)
    row={"Path":path,**identity(raw),"ExpectedBytes":int(count),"ExpectedSha256":digest,"GitBlob":git(root,"rev-parse",source_pin+":"+path).decode().strip(),"CurrentEqualsPinned":(root/path).read_bytes()==raw}
    additional.append(row)
    assert row["Bytes"]==int(count) and row["Sha256"]==digest and row["CurrentEqualsPinned"]
assert len(additional)==9
(out/"owner-commit.txt").write_bytes(git(owner,"show","--no-patch","--format=fuller",pin))
(out/"original-to-final.diff").write_bytes(git(owner,"diff","31b29e17e7d43a86bc02d88f217dd1cd442c3148",pin,"--",*paths))
result={"Schema":"zeta.mixed-epoch.contract-identity-review.v1","ReviewedCommit":pin,"OriginalCommit":"31b29e17e7d43a86bc02d88f217dd1cd442c3148","SourceCommit":source_pin,"Documents":rows,"AdditionalSources":additional,"AllMatch":True,"ImplementationOrNumericalExecution":False}
(out/"result.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"AllMatch":True,"Documents":len(rows),"AdditionalSources":len(additional),"AdditionalSourceBytes":sum(r["Bytes"] for r in additional)}))
