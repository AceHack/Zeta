from pathlib import Path
import gzip,hashlib,json,stat
root=Path.cwd()
out=root/'docs/research/mixed-message-epoch/2026-09-08/peer-core-admission-development'
out.mkdir(parents=True,exist_ok=False)
def sha(raw):return hashlib.sha256(raw).hexdigest().upper()
selected=[]
for prefix,folder,names in [
 ('development','.git/mixed-message-peer-core-admission-checks-1',['MixedMessageEpochReplay.fsx','checks.fsx','run.py','invocation.json','stdout','stderr','completion.json','fixture.bin']),
 ('build','.git/mixed-message-peer-core-codec-build-1',['invocation.json','stdout','stderr','completion.json']),
 ('quick','.git/mixed-message-peer-core-admission-gate-1',['invocation.json','stdout','stderr','completion.json']),
 ('import','.git/mixed-message-peer-core-checkpoint-import-1',['result.json'])]:
 for name in names:selected.append((prefix+'-'+name,folder+'/'+name))
selected.append(('preserve.py','.git/mixed-message-peer-core-admission-preservation-1/preserve.py'))
records=[]
for name,relative in selected:
 p=root/relative; info=p.lstat();assert stat.S_ISREG(info.st_mode) and info.st_size<=4*1024*1024
 raw=p.read_bytes();assert len(raw)==info.st_size
 packed=gzip.compress(raw,mtime=0);file=name+'.gz'
 (out/file).write_bytes(packed)
 records.append({'File':file,'Encoding':'gzip','Bytes':len(raw),'Sha256':sha(raw),'StoredBytes':len(packed),'StoredSha256':sha(packed),'OriginalPath':relative})
source=(root/'src/Research.FSharp/MixedMessageEpochReplay.fsx').read_bytes()
assert source==(root/'.git/mixed-message-peer-core-admission-checks-1/MixedMessageEpochReplay.fsx').read_bytes()
for folder in ['.git/mixed-message-peer-core-admission-checks-1','.git/mixed-message-peer-core-admission-gate-1','.git/mixed-message-peer-core-codec-build-1']:
 assert json.loads((root/folder/'completion.json').read_bytes())['ExitCode']==0
stdout=(root/'.git/mixed-message-peer-core-admission-checks-1/stdout').read_text()
result=json.loads(stdout.splitlines()[-1]);assert result['Passed']==61 and result['Failed']==0
manifest={'Schema':'zeta.mixed-message.peer-core-admission-development.v1','CompletePeer':False,'ActualCoreCodecsAndPreliminaryAdmission':True,'SchedulerLearnerKernelProjectionInvoked':False,'NamedControlsRun':False,'CoreOriginalCommit':'b097d56eccc630046cd3bf618a362b01edeba329','CoreImportCommit':'243e4689ba1380e5b00e241d295426d2b25c7b07','CurrentSource':{'Bytes':len(source),'Sha256':sha(source)},'ScopeLabelCorrection':'Raw final harness Scope retained the earlier metadata-only wording; eight new checks actually call compiled codecs/preliminary admission on a synthetic zero-operation plan. Invocation scope and report correct that label.','Records':records}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'Records':len(records),'OriginalBytes':sum(r['Bytes'] for r in records),'StoredBytes':sum(r['StoredBytes'] for r in records),'Source':manifest['CurrentSource']}))
