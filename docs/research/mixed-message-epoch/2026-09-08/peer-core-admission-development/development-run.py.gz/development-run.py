import datetime, hashlib, json, pathlib, subprocess
p=pathlib.Path(__file__).resolve().parent
cwd=p.parent.parent
source=cwd/'src/Research.FSharp/MixedMessageEpochReplay.fsx'
raw=source.read_bytes()
args=['dotnet','fsi','--quiet','--exec',str(p/'checks.fsx')]
(p/'invocation.json').write_text(json.dumps({'Argv':args,'Cwd':str(cwd),'StartedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'SourceBytes':len(raw),'SourceSha256':hashlib.sha256(raw).hexdigest().upper(),'Scope':'Sixty-one deterministic transport, JSON, owned-file and actual direct-source and passive Start plus actual zero-operation core codec/admission calls; no scheduler/learner/kernel/projection invocation'},indent=2)+'\n')
with (p/'stdout').open('xb') as out, (p/'stderr').open('xb') as err:
    result=subprocess.run(args,cwd=cwd,stdout=out,stderr=err,timeout=60)
(p/'completion.json').write_text(json.dumps({'ExitCode':result.returncode,'FinishedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat()})+'\n')
print(result.returncode)
print((p/'stdout').read_text())
print((p/'stderr').read_text())

raise SystemExit(result.returncode)
