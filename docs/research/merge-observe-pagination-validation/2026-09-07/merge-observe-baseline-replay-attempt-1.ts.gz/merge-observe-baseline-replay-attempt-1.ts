import { mkdtempSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { mapMergeObserve as currentMap } from '../src/Core.TypeScript/forge-host/github/github-merge-observe.ts';
const base = '9fae5f8c3c499d424bc773fa4a13c057d7990495';
const snapshot = mkdtempSync(resolve('.git/merge-observe-baseline-'));
const paths = ['src/Core.TypeScript/forge-host/github/github-merge-observe.ts',
  'src/Core.TypeScript/forge-host/result.ts', 'src/Core.TypeScript/observe/merge-receipt.ts',
  'src/Core.TypeScript/workflow-engine/agent-loop/work-lifecycle-state-machine.ts'];
const source = paths.map(File => {
  const bytes = execFileSync('git', ['show', `${base}:${File}`]);
  const target = join(snapshot, File); mkdirSync(dirname(target), {recursive:true}); writeFileSync(target, bytes, {flag:'wx'});
  const stored=readFileSync(target); if (!stored.equals(bytes)) throw Error('snapshot bytes differ');
  return {File,Bytes:bytes.length,Sha256:createHash('sha256').update(bytes).digest('hex').toUpperCase()};
});
const { mapMergeObserve } = await import(pathToFileURL(join(snapshot, paths[0]!)).href);
const { authorizeMerge } = await import(pathToFileURL(join(snapshot, paths[2]!)).href);
const head='a'.repeat(40);
const good=Array.from({length:100},(_,i)=>({id:`check-${i}`,__typename:'CheckRun',name:`good-${i}`,status:'COMPLETED',conclusion:'SUCCESS'}));
const resolved=Array.from({length:100},(_,i)=>({id:`thread-${i}`,isResolved:true,isOutdated:false}));
const conn=(nodes:unknown[],totalCount:number)=>({nodes,totalCount,pageInfo:{hasNextPage:nodes.length<totalCount,endCursor:nodes.length?`cursor-${nodes.length}`:null}});
const envelope=(checks:unknown[],checkCount:number,threads:unknown[],threadCount:number,mergeStateStatus='CLEAN')=>({data:{repository:{pullRequest:{
  number:1,state:'OPEN',headRefOid:head,mergeStateStatus,autoMergeRequest:null,mergeCommit:null,
  reviewThreads:conn(threads,threadCount),commits:{nodes:[{commit:{oid:head,statusCheckRollup:{contexts:conn(checks,checkCount)}}}]},
}}});
const pairs=[
  {Name:'unresolved-thread-101',Prefix:envelope(good,100,resolved,101),Complete:envelope(good,100,[...resolved,{id:'thread-100',isResolved:false}],101)},
  {Name:'failure-101-blocked',Prefix:envelope(good,101,[],0,'BLOCKED'),Complete:envelope([...good,{id:'check-100',__typename:'CheckRun',name:'failure',status:'COMPLETED',conclusion:'FAILURE'}],101,[],0,'BLOCKED')},
  {Name:'pending-101-clean',Prefix:envelope(good,101,[],0),Complete:envelope([...good,{id:'check-100',__typename:'CheckRun',name:'running',status:'IN_PROGRESS',conclusion:null}],101,[],0)},
];
const rows=[];
for (const pair of pairs) {
 const results=[];
 for (const [label,input] of [['Prefix',pair.Prefix],['Complete',pair.Complete]] as const) {
  const text=JSON.stringify(input); const before=mapMergeObserve(text),after=currentMap(text);
  if (!before.ok || (label==='Complete'&&!after.ok) || (label==='Prefix'&&after.ok)) throw Error('admission discriminator failed');
  const verdict=await authorizeMerge(1,'well-shaped baseline witness',async()=>({ok:true,gate:before.value}));
  results.push({Kind:label,Input:input,Baseline:{Gate:before.value.gate,Checks:before.value.checks,Unresolved:before.value.unresolvedThreads,NextAction:before.value.nextAction,Permitted:verdict.permitted},CorrectedMapperAdmitted:after.ok});
 }
 rows.push({Name:pair.Name,Results:results});
}
const out={Scope:'Pure functions loaded from byte-verified original git objects in a private snapshot, complete synthetic API shapes also admitted by the corrected mapper. No forge mutation or scientific run.',BaselineCommit:base,CorrectedSourceCommit:'e5b6bf5b1913f3df1cf55d1dd4c608fbfd5376fd',SourceFiles:source,Rows:rows};
writeFileSync('.git/merge-observe-baseline-replay-result.json',JSON.stringify(out,null,2)+'\n',{flag:'wx'});
console.log(JSON.stringify({BaselineCommit:base,SourceFiles:source,Rows:rows.map(x=>({Name:x.Name,Results:x.Results.map(({Input,...r})=>r)}))},null,2));
