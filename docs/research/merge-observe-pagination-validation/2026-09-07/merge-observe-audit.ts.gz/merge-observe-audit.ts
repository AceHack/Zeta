import { readFileSync, writeFileSync } from "node:fs";
import { mapMergeObserve } from "../src/Core.TypeScript/forge-host/github/github-merge-observe.ts";
import { authorizeMerge } from "../src/Core.TypeScript/observe/merge-receipt.ts";
const good=Array.from({length:100},(_,i)=>({__typename:"CheckRun",name:`good-${i}`,status:"COMPLETED",conclusion:"SUCCESS"}));
const resolved=Array.from({length:100},(_,i)=>({id:`thread-${i}`,isResolved:true}));
function envelope(checks:any[],threads:any[],mergeStateStatus="CLEAN") {return {data:{repository:{pullRequest:{number:1,state:"OPEN",mergeStateStatus,autoMergeRequest:null,mergeCommit:null,reviewThreads:{nodes:threads,totalCount:101,pageInfo:{hasNextPage:threads.length===100,endCursor:"100"}},commits:{nodes:[{commit:{statusCheckRollup:{contexts:{nodes:checks,totalCount:101,pageInfo:{hasNextPage:checks.length===100,endCursor:"100"}}}}}]}}}}};}
const rows=[];
for(const [name,short,full] of [
 ["unresolved-thread-101",envelope(good,resolved),envelope(good,[...resolved,{id:"thread-100",isResolved:false}])],
 ["failure-101-blocked",envelope(good,[],"BLOCKED"),envelope([...good,{__typename:"CheckRun",name:"last-failure",status:"COMPLETED",conclusion:"FAILURE"}],[],"BLOCKED")],
 ["pending-101-clean",envelope(good,[]),envelope([...good,{__typename:"CheckRun",name:"last-running",status:"IN_PROGRESS",conclusion:null}],[])],
] as const){const results=[];for(const value of [short,full]){const mapped=mapMergeObserve(JSON.stringify(value));if(!mapped.ok)throw Error(mapped.error.message);const auth=await authorizeMerge(1,"bounded audit",async()=>({ok:true,gate:mapped.value}));results.push({gate:mapped.value.gate,checks:mapped.value.checks,unresolved:mapped.value.unresolvedThreads,nextAction:mapped.value.nextAction,permitted:auth.permitted,why:auth.why});}rows.push({name,prefix:results[0],complete:results[1]});}
const first=JSON.parse(readFileSync(".git/merge-observe-live-first.json","utf8"));const second=JSON.parse(readFileSync(".git/merge-observe-live-second.json","utf8"));
const combined=structuredClone(first);combined.data.repository.pullRequest.commits.nodes[0].commit.statusCheckRollup.contexts.nodes.push(...second.data.repository.pullRequest.commits.nodes[0].commit.statusCheckRollup.contexts.nodes);
const live=[first,combined].map(x=>mapMergeObserve(JSON.stringify(x)));
const out={source:"9fae5f8c3",scope:"Pure existing mapper and authorizer; no forge mutation. Live pages are sequential observations, not atomic check-state proof.",rows,live};writeFileSync(".git/merge-observe-audit-result.json",JSON.stringify(out,null,2)+"\n");console.log(JSON.stringify(out,null,2));
