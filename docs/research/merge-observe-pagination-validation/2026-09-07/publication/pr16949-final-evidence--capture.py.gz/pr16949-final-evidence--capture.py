import subprocess,pathlib,json,hashlib,gzip
from datetime import datetime,timezone
p=pathlib.Path(__file__).resolve().parent
root='repos/Lucent-Financial-Group/Zeta'
rows=[]
for name,path in [('drift-job.json',root+'/actions/jobs/101800111064'),('drift.log',root+'/actions/jobs/101800111064/logs'),('pr.json',root+'/pulls/16949'),('merge.json',root+'/commits/7fafe1f883599840c5e65c08ce5ebcaec3a0365d')]:
    argv=['gh','api','--allow-escape-sequences',path]
    result=subprocess.run(argv,capture_output=True)
    (p/(name+'.attempt-2.stderr')).write_bytes(result.stderr)
    if result.returncode: raise RuntimeError((name,result.returncode,result.stderr.decode()))
    raw=result.stdout;stored=gzip.compress(raw,mtime=0)
    target=p/(name+'.attempt-2.gz')
    with target.open('xb') as f: f.write(stored)
    rows.append({'File':target.name,'Bytes':len(stored),'Sha256':hashlib.sha256(stored).hexdigest(),'OriginalBytes':len(raw),'OriginalSha256':hashlib.sha256(raw).hexdigest(),'Arguments':argv})
pr=json.loads(gzip.decompress((p/'pr.json.attempt-2.gz').read_bytes()))
merge=json.loads(gzip.decompress((p/'merge.json.attempt-2.gz').read_bytes()))
assert pr['head']['sha']=='4f8cde2af19c5c3bc5960ebd253280088cb340a3'
assert pr['merged'] and pr['merge_commit_sha']==merge['sha']=='7fafe1f883599840c5e65c08ce5ebcaec3a0365d'
(p/'manifest.json').write_text(json.dumps({'CapturedAtUtc':datetime.now(timezone.utc).isoformat(),'HeadSha':pr['head']['sha'],'MergeSha':merge['sha'],'OriginalCaptureRefusal':'First gh API log capture refused terminal escape bytes; exact stderr retained at drift.log.stderr. The second capture opts in only while capturing bytes directly, never emitting the raw log to the terminal.','Files':rows},indent=2)+'\n')
log=gzip.decompress((p/'drift.log.attempt-2.gz').read_bytes()).decode()
interesting=[line for line in log.splitlines() if ('gate lane' in line.lower() or 'clean streak' in line.lower() or 'last completed' in line.lower() or 'Error:' in line or 'Process completed' in line)]
print(json.dumps({'Manifest':rows,'DriftSelectedLines':interesting},indent=2))
