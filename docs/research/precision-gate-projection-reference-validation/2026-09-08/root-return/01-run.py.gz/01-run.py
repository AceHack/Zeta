from pathlib import Path
import json,os,subprocess,time
root=Path.cwd();out=root/'.git/precision-gate-projection-root-return-regressions-1';cwd=root/'src/Interp.Python'
for name,path in [('source.py','zeta_interp/precision_gate_projection_reference.py'),('test.py','tests/test_precision_gate_projection_reference.py')]: (out/name).write_bytes((cwd/path).read_bytes())
argv=[str(cwd/'.venv/bin/python'),'-m','pytest','tests/test_precision_gate_projection_reference.py::test_normal_root_api_failure_preserved_before_certificate_packaging','-q','-s']
start=time.time();r=subprocess.run(argv,cwd=cwd,env={**os.environ,'PYTHONPATH':str(cwd)},capture_output=True)
(out/'stdout').write_bytes(r.stdout);(out/'stderr').write_bytes(r.stderr);(out/'command.json').write_text(json.dumps(dict(Argv=argv,Started=start,Finished=time.time(),ExitCode=r.returncode),indent=2)+'\n');print(r.stdout.decode()[-3500:]);r.check_returncode()
