from pathlib import Path
import gzip, hashlib, json
root=Path.cwd()
out=root/'docs/research/precision-gate-projection-reference-validation/2026-09-08/trace'
out.mkdir()
groups=[
'precision-gate-projection-trace-regressions-1',
'precision-gate-projection-trace-regressions-2',
'precision-gate-projection-trace-stage-regressions-1',
'precision-gate-projection-trace-stage-regressions-2',
'precision-gate-projection-certificate-attempt-7',
'precision-gate-projection-certificate-attempt-8',
]
records=[]
def retain(path,name):
    raw=path.read_bytes();packed=gzip.compress(raw,mtime=0)
    dest=out/name
    with dest.open('xb') as f:f.write(packed)
    records.append(dict(Original=str(path.relative_to(root)),Stored=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest(),StoredBytes=len(packed),StoredSha256=hashlib.sha256(packed).hexdigest()))
for index,group in enumerate(groups,1):
    for path in sorted((root/'.git'/group).iterdir()):
        assert path.is_file(),path
        retain(path,f'{index:02}-{path.name}.gz')
retain(Path(__file__).resolve(),'preserve.py.gz')
(out/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
pins=[]
for name in [
'src/Interp.Python/zeta_interp/precision_gate_projection_reference.py',
'src/Interp.Python/tests/test_precision_gate_projection_reference.py',
'src/Interp.Python/zeta_interp/precision_gate_projection_intervals.py',
'src/Interp.Python/zeta_interp/hidden_switch_compiled_ieee.py',
]:
    raw=(root/name).read_bytes();pins.append(dict(Path=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest()))
(out/'source-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
for row in records:
    stored=(out/row['Stored']).read_bytes();raw=gzip.decompress(stored)
    assert len(stored)==row['StoredBytes'] and hashlib.sha256(stored).hexdigest()==row['StoredSha256']
    assert len(raw)==row['Bytes'] and hashlib.sha256(raw).hexdigest()==row['Sha256']
    assert raw==(root/row['Original']).read_bytes()
print(json.dumps(dict(Records=len(records),RawBytes=sum(r['Bytes'] for r in records),StoredBytes=sum(r['StoredBytes'] for r in records),Pins=pins),indent=2))
