from pathlib import Path
import gzip, hashlib, json
root=Path.cwd()
out=root/'docs/research/precision-gate-projection-reference-validation/2026-09-08/publication'
out.mkdir()
groups=['precision-gate-projection-source-publication-attempt-1','precision-gate-projection-source-publication-attempt-2','precision-gate-projection-custody-audit-1']
records=[]
def retain(path,name):
    raw=path.read_bytes();stored=gzip.compress(raw,mtime=0)
    with (out/name).open('xb') as f:f.write(stored)
    records.append(dict(Original=str(path.relative_to(root)),Stored=name,Bytes=len(raw),Sha256=hashlib.sha256(raw).hexdigest(),StoredBytes=len(stored),StoredSha256=hashlib.sha256(stored).hexdigest()))
for i,group in enumerate(groups,1):
    for path in sorted((root/'.git'/group).iterdir()):
        assert path.is_file(),path
        retain(path,f'{i:02}-{path.name}.gz')
retain(Path(__file__).resolve(),'preserve.py.gz')
(out/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
for row in records:
    packed=(out/row['Stored']).read_bytes();raw=gzip.decompress(packed)
    assert len(packed)==row['StoredBytes'] and hashlib.sha256(packed).hexdigest()==row['StoredSha256']
    assert len(raw)==row['Bytes'] and hashlib.sha256(raw).hexdigest()==row['Sha256']
    assert raw==(root/row['Original']).read_bytes()
print(json.dumps(dict(Records=len(records),RawBytes=sum(r['Bytes'] for r in records),StoredBytes=sum(r['StoredBytes'] for r in records)),indent=2))
