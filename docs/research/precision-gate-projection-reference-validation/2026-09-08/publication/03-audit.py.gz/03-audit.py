from pathlib import Path
import gzip,hashlib,json
root=Path.cwd();out=root/'.git/precision-gate-projection-custody-audit-1';results=[]
for section in ('intervals','root','certificate'):
    base=root/'docs/research/precision-gate-projection-reference-validation/2026-09-08'/section
    manifest=json.loads((base/'manifest.json').read_bytes())
    records=manifest['Records'] if section=='intervals' else manifest
    assert isinstance(records,list)
    for row in records:
        packed=(base/row['Stored']).read_bytes();raw=gzip.decompress(packed)
        byte_key,sha_key=('RawBytes','RawSha256') if section=='intervals' else ('Bytes','Sha256')
        assert len(packed)==row['StoredBytes'] and hashlib.sha256(packed).hexdigest()==row['StoredSha256'],row['Stored']
        assert len(raw)==row[byte_key] and hashlib.sha256(raw).hexdigest()==row[sha_key],row['Stored']
        assert (root/row['Original']).read_bytes()==raw,row['Original']
    results.append(dict(Section=section,Records=len(records),StoredRawOriginalMatch=True))
base=root/'docs/research/precision-gate-projection-reference-validation/2026-09-08/certificate'
pins=json.loads((base/'source-pins.json').read_bytes())
for row in pins:
    raw=(root/row['Path']).read_bytes()
    assert len(raw)==row['Bytes'] and hashlib.sha256(raw).hexdigest()==row['Sha256'],row['Path']
result=dict(Sections=results,TotalRecords=sum(r['Records'] for r in results),CurrentSourcePins=len(pins),SourceCalls=0)
(out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
