from pathlib import Path
import hashlib,json,subprocess,time
root=Path.cwd();out=root/'.git/precision-gate-projection-source-publication-attempt-1'
records=[]
def command(name,argv):
    start=time.time();r=subprocess.run(argv,cwd=root,capture_output=True)
    (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
    records.append(dict(Name=name,Argv=argv,Started=start,Finished=time.time(),ExitCode=r.returncode))
    (out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name,r.returncode,r.stdout.decode()[-1500:],r.stderr.decode()[-1500:],flush=True)
    r.check_returncode();return r.stdout
head=command('head',['git','rev-parse','HEAD']).decode().strip()
assert head=='51a96fa11bd7590af3d5ed45b6fb6ebfdca414fe'
assert command('status',['git','status','--porcelain'])==b''
assert command('hook',['git','config','--get','core.hooksPath']).decode().strip()=='githooks'
command('before',['git','ls-remote','origin','refs/heads/codex/distributional-rooms-reference-20260908'])
command('push',['git','push','origin','HEAD:refs/heads/codex/distributional-rooms-reference-20260908'])
after=command('after',['git','ls-remote','origin','refs/heads/codex/distributional-rooms-reference-20260908']).decode().split()
assert after==[head,'refs/heads/codex/distributional-rooms-reference-20260908']
(out/'verified.json').write_text(json.dumps(dict(Head=head,RemoteExact=True,NormalHook=True),indent=2)+'\n')
