from pathlib import Path
import json,os,subprocess,time
root=Path.cwd();out=root/'.git/precision-gate-projection-root-review-regressions-1';cwd=root/'src/Interp.Python'
for name,path in [('source.py','zeta_interp/precision_gate_projection_reference.py'),('test.py','tests/test_precision_gate_projection_reference.py')]: (out/name).write_bytes((cwd/path).read_bytes())
argv=[str(cwd/'.venv/bin/python'),'-m','pytest','tests/test_precision_gate_projection_reference.py::test_second_context_refusal_uses_registered_failure_stage','tests/test_precision_gate_projection_reference.py::test_input_ceiling_precedes_hash_and_numeric_work','-q']
start=time.time();r=subprocess.run(argv,cwd=cwd,env={**os.environ,'PYTHONPATH':str(cwd)},capture_output=True)
(out/'stdout').write_bytes(r.stdout);(out/'stderr').write_bytes(r.stderr);(out/'command.json').write_text(json.dumps(dict(Argv=argv,Started=start,Finished=time.time(),ExitCode=r.returncode),indent=2)+'\n');print(r.stdout.decode());r.check_returncode()
