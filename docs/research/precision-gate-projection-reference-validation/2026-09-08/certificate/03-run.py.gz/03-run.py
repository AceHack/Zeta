from pathlib import Path
import hashlib, json, os, subprocess, sys, time
root=Path.cwd(); out=root/'.git/precision-gate-projection-certificate-attempt-3'
files=['src/Interp.Python/zeta_interp/precision_gate_projection_reference.py','src/Interp.Python/tests/test_precision_gate_projection_reference.py','docs/research/2026-09-08-precision-gate-projection-reference.md']
for i,name in enumerate(files):
    data=(root/name).read_bytes(); (out/f'source-{i}').write_bytes(data)
(out/'sources.json').write_text(json.dumps([{ 'Path':p,'Bytes':(root/p).stat().st_size,'Sha256':hashlib.sha256((root/p).read_bytes()).hexdigest()} for p in files],indent=2)+'\n')
python=str(root/'src/Interp.Python/.venv/bin/python'); cwd=root/'src/Interp.Python'
commands=[('pytest',[python,'-m','pytest','tests/test_precision_gate_projection_reference.py','-q']),('mypy',[python,'-m','mypy','--strict','zeta_interp/precision_gate_projection_reference.py','tests/test_precision_gate_projection_reference.py']),('ruff',[python,'-m','ruff','check','zeta_interp/precision_gate_projection_reference.py','tests/test_precision_gate_projection_reference.py']),('format',[python,'-m','ruff','format','--check','zeta_interp/precision_gate_projection_reference.py','tests/test_precision_gate_projection_reference.py'])]
records=[]
for name,argv in commands:
    start=time.time()
    result=subprocess.run(argv,cwd=cwd,env={**os.environ,'PYTHONPATH':str(cwd)},capture_output=True)
    (out/(name+'.stdout')).write_bytes(result.stdout);(out/(name+'.stderr')).write_bytes(result.stderr)
    records.append(dict(Name=name,Argv=argv,Started=start,Finished=time.time(),ExitCode=result.returncode))
    print(name,result.returncode,result.stdout.decode()[-6000:],result.stderr.decode()[-1000:],flush=True)
(out/'commands.json').write_text(json.dumps(records,indent=2)+'\n')
if any(r['ExitCode'] for r in records):sys.exit(1)
