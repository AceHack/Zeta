import sys,importlib.metadata,json
v={'python':sys.version,'executable':sys.executable,'packages':{}}
for name in ['torch','transformers','chronos-forecasting','timesfm','mlx','numpy','pandas']:
 try:v['packages'][name]=importlib.metadata.version(name)
 except importlib.metadata.PackageNotFoundError:v['packages'][name]=None
print(json.dumps(v,indent=2))
